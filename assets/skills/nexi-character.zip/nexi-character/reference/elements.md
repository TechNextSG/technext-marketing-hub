# The element library: what makes a Nexi reaction read

A reaction is defined when several of these layers agree. Minimum for any beat (nexi-video N10): **face + body + one accent**.
A big beat (L3+, shock, glitch) stacks five or more. Every element below exists in the renderer; the name in `code` is the
call or mark that draws it.

## 1. Face (the 3D visor: `N.eyes`, `N.mouth`, `N.blush`, `N.eyePop`)

| Element | How | Reads as |
|---|---|---|
| Eye shapes | `open` `happy` (arcs ^ ^) `star` `line` (flat) `big` `heart` `x` | neutral, joy, excitement, flat/unimpressed/closed, shock, love, fainted |
| Eye angle | `r: [-0.4, 0.4]` on `line` = ANGRY slant (\ /); `r: [0.3, -0.3]` = SAD slant (/ \); 0 = flat | anger, sadness, deadpan |
| Side-eye | `line` eyes + `look(x, y)` to the side (the eyes slide on the visor and the head turns) | unimpressed, L1 |
| Asymmetry | `s: ['line', 'open']` or `k: [1.0, 1.45]` | suspicious, confused, disgusted |
| Size + pop | `k` 0.75 (dim) .. 1.8 (huge), `N.eyePop(2..8)` springs them bigger for a beat | intensity |
| Hidden eyes | `k: [0.02, 0.02]` + a visor icon (spinner, power, boot logo) | robot states |
| Shine | the kit's `shine` mark: two white highlights per eye + a forming tear | puppy eyes |
| Flicker | eyes cycle every shape at 12 Hz | glitch |
| Mouth | `smile`, `o` sized 0.01 (hidden) .. 2.2 (scream) | pout (o 0.4-0.6), shout (1.3+), gasp (2+) |
| Blush | `N.blush(d)` pink cheeks | shy, love, proud of you, after a slow blink |

## 2. Body (clips: pose units scale with her depth)

| Element | Clips | Reads as |
|---|---|---|
| Anticipation | crouch / squash before the move (`N.squash(-0.3..-1)`, the hiss crouch, the cucumber squash) | the hit lands harder |
| Puff up | `N.pulse(0.8..1.8)` body swell, the hiss `sq +0.12` | offended, cheeks puffed |
| Turn away | `yaw` 0.3-0.4 (grumpy), 2.5 = her back (sulk) | "Hmph", ignoring you |
| Arms | crossed (grumpy), claws up (hiss), fists pumping (tantrum), hands to cheeks (shy), clasped under chin (puppy), hand to mouth (disgust), on hips (annoyed, smug), scratch head (confused), fan face (overheat), paw swipe (knock) | the emotion in silhouette |
| Height | rigid leap (shock), hops (cheer, tantrum), droop (lowbatt), sink (box), loaf squat | energy level |
| Tremble / jitter | fast small roll/tilt sines (hiss, puppy, overheat); random steps (glitch) | tension, overload |
| Movement | `pounce` (arc leap to a target), `zoomies` (orbit laps) | cat energy: plan the landing |
| Engine clips also usable | `facepalm`, `shrug`, `slam`, `tantrum`, `panic`, `nope`, `laugh`, `groove`, `faint`, `bigjump`, `shockJump`, `superman`, `salute`, `bow`, `peer`, cutekit `ck*` | |

## 3. Marks (manga symbols drawn at her head; `nxMark(kind, d, o)`)

| Mark | Meaning | Look | Used by |
|---|---|---|---|
| `vein` | anger | red cross-popping vein, white edge, throbbing, top corner of the head | grumpy, offended, meltdown |
| `dots` | "..." unimpressed / thinking | white speech bubble, dots pop one by one | annoyed, suspicious |
| `huff` | a "hmph" exhale | two small cloud puffs from her face | grumpy |
| `steam` (engine `emote`) | fuming | puffs rising from both sides | meltdown, overheat |
| `kettle` | boiling over | a steam jet straight up from her head + whistle arcs | meltdown |
| `bristle` | hackles up | a spiky starburst ring BEHIND her body, white to red | offended |
| `dust` | the cartoon fight cloud | cloud ring at her waist, # @ ! * symbols and stars popping | meltdown |
| `sweat` / `tears` (engine) | nervous / crying | blue drops | panic, oops, overheat / cry |
| `rain` | sulking | grey cloud over her head with falling drops | sulk |
| `gloom` | "it's hopeless" | vertical purple dashed lines hanging over her | sulk, facepalm |
| `stink` | gross | green wavy lines rising from the object | disgust |
| `qorbit` | confused | three "?" orbiting her head (depth-scaled) | confused |
| `glint` | smug, a shine | 4-point white star flash + two gold sparkles | smug, suspicious, knock |
| `zzz` | sleepy / bored | Z letters rising | (available) |
| `siren` | emergency | a red dome light on her head with turning red/blue beams | panic |
| `spinner` | loading | 8 glowing dots turning ON THE VISOR | buffering |
| `battery` | energy | battery icon above her head, red blinking when low, bolt when charging, fills green | lowbatt |
| `static` | malfunction | cyan/magenta/white bars across the visor | offended (a flash), glitch |
| `power` / `boot` | restart | power symbol, then the TechNext plane logo + loading bar on the visor | reboot |
| `purr` | content | pink zigzag vibration lines at both sides | loaf, knead |
| `shine` | pleading | eye highlights + a forming tear | puppy |
| engine `stars`, `q`, `notes`, `angry` | dizzy, question, music, anger | | faint, hmm, dance |

## 4. Mood colour on her body (`nxMark('tint', d, { col, a, mode, pulse, fill })`)

Her own 3D silhouette tinted, so the colour sits exactly on her.

| Mode | Look | Use |
|---|---|---|
| `head` | colour on the face, fading down the body | red = angry flush (grumpy, offended), green = disgust, pink = love |
| `rise` | colour fills UP from the feet like a thermometer over `fill` s | red = meltdown, orange = overheat |
| `drop` | colour drains DOWN from the top | blue = sulk, cry |
| `full` | the whole body | grey = low battery / faint, white = the shock flash |
| `pulse` | add `pulse: 6..14` (Hz-ish) to throb | rage, heat |

Plus `aura` (a soft gold glow + rays BEHIND her: pride, joy) and the screen-edge pulses `redpulse` (meltdown) / `bluepulse` (cry).
Colours: anger #FF3B5C / #FF2E2E, heat #FF6A2E, disgust #5FBF5A, sad #5B7BD5, love #FF7EB6, gold 255,201,60, battery grey #7A8094.

## 5. Screen effects (engine)
`shake(k)` (0.2 small .. 0.8 big), `speedLines()`, `FX.flash = window.T` (white flash), `bang('!')`, the kit's `rgb` split
(glitch), `snap` + `ghosts` (motion trail, zoomies). Camera punch-ins are the film's job (`cam`), not the kit's.

## 6. Comic words (`nxFeel(kind, { word: 'TWICE?!' })`, or `nxMark('word', d, { text, pal })`)
Extruded, ink-outlined, gradient-filled, popped in with an overshoot, tilted toward her side, drifting up. Cached once per
word (rule T11). Palettes (`NXPAL`): `anger` red, `hmph` pink, `hiss` yellow-orange, `ew` green, `ting` gold, `yay` yellow-pink,
`cool` blue, `sad` lilac. Defaults: HMPH! KSSHH! GRRR! !! EWW AAAH! W-W-WHAT YAY! ZOOM! HEHE. Use the line's own word when
it's punchier ("TWICE?!", "AGAIN?!"). Never more than one word on screen.

## 7. Props the kit draws
stained paper (`held`, disgust), paper stack on a side table that gets knocked off (`paper`), the report she drops (`gift`),
cardboard box (`box`), mouse cursor (`cursor`, pounce), magnifier (`magnifier`), 10/10 card (`card10`), the worn hat that pops
off (`nxHatPop`).

## 8. Sounds (one per reaction, soft, low-passed by the mixer)
New (patch p100, `audio_t.S`): `hiss` (offended), `purr` (loaf, knead), `hmph` (grumpy), `grr` (meltdown, a squeaky growl,
not scary), `glitch` (bit-crushed blips), `powerdown`, `boot` (rising bells), `ew` (wobbly drop), `whimper` (puppy), `rain`
(sulk patter), `scurry` (zoomies, pounce feet), `glint` (smug ting), `kettle` (meltdown whistle), `mrrp` (the cat trill:
gift, slowblink, box, knock, smug), `beep` (low battery).
Engine: gasp, boing, wah, steam, giggle, tada, heart, hmm, dizzy, alarm, buzz, chirp, sparkle, ding, tick, swish, drop, pop,
rise...

## 9. Timing (what separates "defined" from "mush")
- **Anticipation -> hit -> hold -> settle.** 0.1-0.3 s wind-up, the hit on a word of the caption, 0.6-1.5 s hold, 0.3 s settle.
- **The hit stacks:** eyes change + eye pop + body pop + mark + shake + word + sound all on the same frame.
- **Bigger = shorter.** A meltdown is 3 s with the peak in the first second; a slow blink is slow on purpose.
- **One big reaction per line**, never two in a row; after an L3+ comes the fix.
- **Contrast sells it:** calm coach -> sudden explosion -> calm again. Deadpan eye contact before the knock is funnier than
  a big face.

# Nexi in words: captions, scripts, post copy

## Voice
- Short, chirpy sentences. Most lines under 10 words; video captions max 86 characters (nexi-video T6).
- Plain words, no jargon, no selling ("just buy Odoo" never). First person and talking to the viewer are fine.
- Sassy at the MESS, kind to the PERSON. The villain is always the process ("the Double-Entry Monster", "Spreadsheet Hydra",
  "the Lost-Invoice Ghost").
- About one catchphrase per piece. Overuse kills them.
- On screen in videos she speaks in the robot voice (the website voice; Season 2 + holidays use the soft voice, rule A11).

## Catchphrases
- **"Mess detected."** (flat, robot; with the X/flat eyes)
- **"It's not you. It's the process."** (the soft landing, with a slow blink)
- **"Type it once. Done."** (the Odoo payoff)
- **"Fine. I'll fix it."** (the turn from anger to action: the "Fine." beat)

## Lines per reaction (pick, adapt, don't stack)
| Reaction | Lines |
|---|---|
| annoyed L1 | "..." · "Hm." · "We're doing this by hand?" |
| grumpy L2 | "Hmph." · "Absolutely not." · "Who did this." (deadpan, no question mark) |
| offended L3 | "Excuse me?!" · "You typed that TWICE?!" · "AGAIN?!" |
| meltdown L4 | "GRRR!" · "Forty-seven versions?!" · "That's it!" |
| faint L5 | (no line: the fall says it) · "...I need a minute." |
| shock | "WHAT?!" · "Since WHEN?!" |
| disgust | "Ew. Paper." · "Is that... a 2009 spreadsheet?" |
| panic | "Audit's tomorrow?!" · "Okay okay okay!" |
| puppy | "Please don't go back to paper." · "One more click? For me?" |
| sulk | "Fine. Use the spreadsheet." · "I'm not sulking." |
| suspicious | "These numbers don't match..." · "Three customers. Same name. Hmm." |
| confused | "Is that Lim, Lin or Lym?" |
| knock | (deadpan, after the swipe) "Oops." · "It belonged in the bin." |
| buffering | "Loading... still loading..." · (after) "Twelve steps? Let me show you one." |
| lowbatt | "Battery at 2%. So much retyping." |
| glitch | "W-w-what?" · "Does not compute." |
| reboot | "Rebooting. Let's try that the smart way." |
| overheat | "Too. Many. Tabs." |
| smug | "Done. You're welcome." · "Automated." |
| gift | "Made you a report." |
| cheer | "10 out of 10, Maria!" · "Look at you go!" |
| shy | "It's... nothing." |
| slowblink / loaf | "It wasn't you. It was the process." · "Everything's automated. Nap time." |
| love | "Look at this clean dashboard..." |

## Never
- Insult or mock the customer, the viewer or a cast member.
- Scary threats, real violence, swearing (even bleeped), "stupid", "idiot".
- Sarcasm in text without a visual cue that it's playful.
- Price claims or invented figures (nexi-video C2/H13 still apply).

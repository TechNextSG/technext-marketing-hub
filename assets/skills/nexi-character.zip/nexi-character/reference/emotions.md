# The 35 reactions (nxFeel kinds)

Every row is exactly what `nxFeel(kind)` plays in `web/films/inc/nexikit.js` (2026-10-10). Use the same recipe when you draw
Nexi by hand (posters, thumbnails). `d` = default length in seconds. "Quiet-safe" = still reads with `{quiet: true}` (no
comic word, no big marks) next to text cards.

Owner direction (verbatim, 2026-10-10): "at least need a exaggeration reaction when thing went wrong" / "cute angry adorable.
catt attitue like that" / "include all of this emotion and reaction. also show element/reaction or anything that can make nexi
raection more define."

## 1. The rage ladder (aimed at the MESS, never the person)

Pick the level from how bad the mess is. Most beats are L1-L3; L4 is for the big moment of an episode.

| Kind | Trigger | Face | Body | Marks + colour | Sound | Word | d |
|---|---|---|---|---|---|---|---|
| `annoyed` (L1) | A small mistake, a typo, a slow approval | flat `line` eyes, tiny `o` mouth, looks sideways (side-eye) at `o.to` or away | turns 0.34 rad away, hands on hips, foot tap | "..." bubble (on the other side) | tick tick tick | none | 2.6 |
| `grumpy` (L2) | Doing something by hand that should be automatic | angry slant (`line` r -0.42/+0.42), pout (`o` 0.55) | arms crossed, turns away, chin up, cheeks puff (pulse) + a huff bounce | anger vein, huff puff cloud, red FACE flush (`head` 0.34) | hmph | HMPH! | 2.6 |
| `offended` (L3, the hiss) | The same data typed twice, a lost file | sharper slant (0.55), eyes pop, `o` 1.3 | crouch (anticipation) then PUFF UP, claws up, trembling | bristle ring behind her, visor static, vein, red face flush pulsing | hiss | KSSHH! (or the line's word: "TWICE?!") | 2.6 |
| `meltdown` (L4) | Month-end chaos, a disaster, the villain's big moment | max slant (0.6), eyes 1.5, `o` 1.8 | tantrum: alternating fist pumps, hops, shaking | red RISING from the feet (thermometer, `rise`), kettle steam jet from her head, hat pops off and lands, dust cloud with # @ ! * and stars, red edge pulse, steam puffs, vein | kettle + grr (x2) | GRRR! | 3.2 |
| `faint` (L5) | Total disaster (47 versions of one file) | `x` eyes, `o` | falls back (engine `faint`) | orbiting stars, grey body | dizzy | none | 2.6 |
| `angry` {lvl: 1-5} | Alias: picks the ladder step | | | | | | |

## 2. When things go wrong

| Kind | Trigger | Face | Body | Marks + colour | Sound | Word | d |
|---|---|---|---|---|---|---|---|
| `shock` (cucumber jump) | A sudden surprise: overdue invoice, stock at zero | `big` 1.75, `o` 2.2, eyes pop 8 | rigid leap straight up (anticipation squash, 0.95 lift, limbs splayed, land squash) | "!" bang, speed lines, white flash on her body + screen, shake, the hat stays up a beat | gasp + boing | !! | 1.9 |
| `disgust` | An ancient spreadsheet, handwritten paper, a coffee-stained file | asymmetric squint (`line` 0.28/-0.12, sizes 1.05/0.8), small `o` | holds a stained paper at arm's length, leans and turns away, other hand to her mouth, shudder | stink lines, GREEN face (`head` 0.45) | ew | EWW | 2.7 |
| `panic` | Deadline, audit tomorrow, server down | engine panic (big eyes) | engine `panic` run | siren light on her head (red/blue beams), sweat | alarm (x2) | AAAH! | 2.4 |
| `puppy` | Pleading: "please don't go back to paper" | `big` 1.8 + shine highlights + a forming tear, tiny `o` | hands clasped under her chin, head tilt, looks up, tremble | blush | whimper | none | 2.8 |
| `sulk` | Ignored: they still use the old way | sad slant (`line` +0.32/-0.32) | turns her BACK, slumps, peeks back over her shoulder, turns back | rain cloud with drops, gloom lines, blue DRAINING down (`drop`) | rain + hmm | none | 3.2 |
| `suspicious` | Numbers don't match, a duplicate customer | one squint + one smaller eye (`line`/`open`) | leans in, scans side to side, magnifier up | magnifier with lens glint, "..." | hmm + glint | none | 2.8 |
| `confused` | Five spellings of one customer name | eyes different sizes (1.0 / 1.45), small `o` | cat head tilt + scratching her head | three orbiting "?" | hmm + boing | none | 2.4 |
| `cry` | Lost data, a sad story beat | engine cry (sad lines) | engine tantrum | tears, blue draining down, blue edge pulse | wah | none | 1.8 |
| `oops` | Nexi herself made a small mistake (rare: gives her vulnerability) | `x` eyes, `o` | hands up, shrinks, wobble | sweat, blush | boing | none | 1.8 |
| `facepalm` | "They emailed the spreadsheet AGAIN" | `line` eyes | engine `facepalm` | gloom lines | hmm + tap | none | 2.0 |

## 3. Cat attitude (her signature gags)

| Kind | Trigger | What happens | Sound | d |
|---|---|---|---|---|
| `knock` | Anything that belongs in the bin: paper invoices, a sticky-note pile, the old spreadsheet | Deadpan flat eyes, she looks straight at the camera (eye contact) while her paw reaches, winds up and SWIPES the stack off a little side table; the papers fly, land and settle on the floor; then a smug happy face + glint. `o.to` = the stack spot, `o.floor` = floor y, `o.ledge: false` when the film draws its own table. | swish, drop, mrrp | 3.2 |
| `pounce` | Walkthroughs: chasing the mouse cursor like a laser pointer; catching a bug | Crouch + butt wiggle, eyes locked on the target, then an arc leap that lands paws-down on it (the cursor squishes, stars). MOVES her: `o.to` = target, she lands 1.25 head radii above it. | scurry, boing, mrrp | 2.4 |
| `box` | A new device or delivery arrives: she sits in the BOX, not the item | A cardboard box appears around her, she sinks in and peeks out, happy eyes, hearts | drop, mrrp | 3.2 |
| `knead` | Happy waiting: the import is running, the report is loading | Paws pat alternately ("making biscuits"), content eyes, blush | purr | 2.8 |
| `loaf` / `slowblink` / `offended` | (listed under wins / the ladder) the loaf, the cat "I trust you" blink, the hiss | | | |

## 4. Robot-only (only Nexi can do these)

| Kind | Trigger | What happens | Sound | d |
|---|---|---|---|---|
| `buffering` | Someone explains a 12-step manual process | Eyes and mouth switch off, a spinner turns on her visor, she freezes mid-pose with a stutter, then pops back (big eyes, squash) | tick (loop), ding | 2.8 |
| `lowbatt` | The end of a long manual day | Droops, dim half-closed eyes, grey body, a blinking red battery above her head; with `recharge` (default) a bolt appears, the battery fills green and she pops back up with star eyes | powerdown, beep, rise, ding | 3.2 |
| `glitch` | Too wrong to process ("the numbers say 3 different things") | Jitter, the eyes flicker through every shape, cyan/magenta RGB split slices over her body, visor static | glitch | W-W-WHAT | 2.2 |
| `reboot` | The shock is too much: a clean restart before the fix | Powers down (droop, eyes off), a power icon glows on the visor, the TechNext plane logo + a loading bar boot on the visor, eyes come back big, then happy, she pops up | powerdown, boot, ding | 3.6 |
| `overheat` | Too much at once, the step before a meltdown | Angry slant, fanning her face with one hand, trembling, orange RISING, heat glow behind her, heat shimmer, steam + sweat | steam, beep | 2.8 |

## 5. When things go right

| Kind | Trigger | What happens | Sound | Word | d |
|---|---|---|---|---|---|
| `joy` | The fix landed, a deal won | engine joy (big jump, star eyes, confetti/sparks) + gold aura | tada, boing | YAY! | 1.9 |
| `zoomies` | Pure joy: invoice paid, go-live day | Laps around her spot (MOVES her: orbit 150 px, 2 turns), bouncing, arms pumping, motion ghosts, speed lines, skid squash at the end | scurry, boing | ZOOM! | 2.4 |
| `smug` | An automation just finished | Chin up, happy squint, blows on her fist then polishes it on her chest, glints, gold aura | glint, mrrp | none | 2.4 |
| `gift` | A report is ready | Like a cat bringing a mouse: she bends and drops the finished report at your feet, it bounces, she waits with big expectant eyes, then star eyes | drop, mrrp, sparkle | none | 3.0 |
| `love` | Clean data, a beautiful dashboard | engine love (heart eyes, hearts) + pink face + heartbeat pulse | heart | none | 1.9 |
| `loaf` | Everything is automated | Squats into a loaf, hands tucked, content eyes, purr lines and a tiny vibration, then a slow blink and blush | purr | none | 3.2 |
| `slowblink` | Trust, the soft ending beat ("It wasn't you, it was the process") | Eyes half-close, fully close, reopen happy; blush | mrrp | none | 2.2 |
| `cheer` | Proud of YOU: the human did it right | Holds up a 10/10 card, star eyes, hops, confetti | tada | none | 2.4 |
| `shy` | Complimented ("Nexi, you're amazing") | Hands to cheeks, blush, sway: "It's... nothing." | chirp | none | 2.2 |
| `laugh` | A joke, a callback | engine laugh | giggle | HEHE | 1.7 |
| `dance` | Celebration | engine dance (groove, notes) | (music) | none | 2.4 |

## Choosing fast
- "Something went wrong" -> how bad? small `annoyed`, manual work `grumpy`, double work `offended`, chaos `meltdown`, disaster `faint`; sudden `shock`; gross `disgust`; urgent `panic`; overloaded `buffering` / `overheat` / `glitch`.
- "It's fixed" -> `smug` (she did it), `cheer` (you did it), `joy` / `zoomies` (big win), then `slowblink` or `loaf` to land softly.
- One beat per caption line; never two big ones back to back. After an L3+ the next beat is the fix.

## 6. Variation pack (2026-10-10; owner: "add more reaction variation")

**Rule: never the same reaction twice.** `nxFeel(kind)` without `v` cycles v1 -> v2 -> v3 per film on its own, and the v1
comic word rotates (HMPH! -> HMPF! -> TCH!). Pick one with `{ v: 2 }` or by its alias. v1 = the recipe in the tables above.

| Kind | v2 (alias) | v3 (alias) |
|---|---|---|
| annoyed | eye-roll: eyes roll up then aside, sigh puff, UGH (`eyeroll`) | impatient tap: arms crossed, fingers drumming, alarm clock (`drum`) |
| grumpy | puffed cheeks: puffs up wide, blush, huff left + right, HMPF! (`pout`) | stomp: 3 stomps, dust at her feet, shake, TCH! (`stomp`) |
| offended | NOPE: arms make an X, head shake, big red X sign, NOPE! (`nope`) | double take: looks, looks away, SNAPS back, !, hiss, AGAIN?! (`doubletake`) |
| meltdown | volcano: trembles, red rises, ERUPTS (jump, flash, hat flies), RAAAH! (`volcano`) | tornado: spins into a dust tornado, dizzy stop, ARGH! (`tornado`) |
| faint | soul leaves: falls back, a blue ghost of her floats up (`soul`) | melt: flattens into a puddle, X eyes, pops back (`melt`) |
| shock | eyes pop: huge eyes, jolts back, hat flies, WHAT?! (`eyespop`) | the scream: hands to cheeks, blue drains down, EEP! (`scream`) |
| disgust | gag: hand to mouth, retches x3, green rises, BLEH (`gag`) | yeet: throws the old paper over her shoulder, smug, YUCK (`yeet`) |
| panic | running circles (MOVES her), siren, EEK! (`circles`) | windmill: arms flailing, alarm clock, HELP! (`windmill`) |
| puppy | begging: kneels, hands up high, sparkle rays (`pray`) | |
| sulk | corner: sits facing away, draws circles on the floor, gloom (`corner`) | |
| confused | head-swing: tilts left-right, ? ? ?, HUH? (`headspin`) | |
| oops | hide: hides behind her hands, peeks, giggle (`hide`) | |
| facepalm | double: both palms, slow head shake, sigh (`doublepalm`) | |
| buffering | stuck at 99%: loading bar on the visor, gives up (X eyes) (`loading`) | |
| glitch | blue screen: the visor crashes to :( then reboots (`bsod`) | |
| joy | fist pump: YES!, sparks, gold aura (`fistpump`) | twirl: spin, sparkles, WHEE! (`twirl`) |
| smug | know-it-all: glasses on, pushes them up, glint, AHEM. (`glasses` / `shades`) | |
| love | dreamy: hearts orbit her head, swaying, mrrp (`dreamy`) | |
| cheer | pom-poms: pom-poms in both hands, hops, GO GO! (`pompoms`) | |
| laugh | ROFL: leans over laughing, tears, HAHA (`rofl`) | |
| zoomies | figure 8 (MOVES her), star eyes, NYOOM! (`figure8`) | |

**11 new kinds:**

| Kind | Trigger | What happens |
|---|---|---|
| `determined` | THE "Fine." BEAT between the anger and the fix | fists to chest, then power-up: blue flame aura, speed lines, FINE., powerup sound |
| `idea` | the solution appears | points up, glowing lightbulb, star eyes, ding |
| `stare` | an awkward silence, "really?" | the unblinking cat stare: total stillness, crickets, "..." |
| `sleepy` | waiting for an email approval | big yawn, nods off, Zzz, jolts awake ! |
| `stretch` | waking up, after a long sync | long cat stretch, shake-off, mrrp |
| `breathe` | calming down after anger (soft alternative to `determined`) | inhale, exhale puff, blue aura |
| `starstruck` | first look at the clean dashboard | spinning star eyes, sparkle burst, OOOH! |
| `nervous` | "Uh... about that report" | one big sweat drop, awkward smile, scratches her head |
| `wink` | "you got this" | finger gun, pew, glint |
| `hello` / `bye` | openings and sign-offs | wave + hop + chirp / salute + glint |

Sounds added (patch p104): sigh, yawn, cricket, pew, eep, stomp, powerup.

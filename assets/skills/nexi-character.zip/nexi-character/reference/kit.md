# The renderer kit: nxFeel (web/films/inc/nexikit.js)

Renderer: `~/ClaudeWork/nexi-tutorial` (the nexi-video skill's engine; read its `reference/engine.md` for the base API).

## Files
| File | What |
|---|---|
| `web/films/inc/nexikit.js` | The kit: 30 body clips (`NXCL`, registered lazily as `nx_<name>_<centiseconds>`), the mark library, `nxFeel`, `nxMark`, `nxHatPop`, `nxClear` |
| `patches/p100_nexi_feel.py` | Adds the kit's 15 sounds to `audio_t.S` + `SFX_VOL` and registers `nxsheet` in lint `TOOL_FILMS`. Re-runnable (assert-and-replace). |
| `web/films/nxsheet.js` | The bench: all 35 kinds in sequence on a clean stage, with a label card (group, name, elements) and the call. 121 s. |
| `~/ClaudeWork/qa/nxfeel/times.py` | Peak time of each kind in the bench (`--list` for kind, peak, start, d) |
| `~/ClaudeWork/qa/nxfeel/grid.py` | Contact grid of `qa/nxsheet/f-*.jpg` |
| `~/ClaudeWork/qa/nxfeel/sheet.py` | The delivered emotion sheet + element board (PNG) from the bench stills |

## Use in a film
```js
/*@include tipkit*/      // if the film shows Odoo screens
/*@include cutekit*/     // optional: the cute idle + react()
/*@include nexikit*/     // the character kit
...
var l4 = say('You typed that **TWICE**?!');
at(l4.w('TWICE'), function () { nxFeel('offended', { word: 'TWICE?!' }); });
var l5 = say('Fine. I\'ll fix it.');
at(l5.t0, function () { nxFeel('annoyed', { d: 1.4, quiet: true }); });
```
- `nxFeel(kind, o)` returns false for an unknown kind. Options: `d`, `lvl` (angry), `word` (string | false), `side` (1 = marks to
  screen-right), `to` ({x, y} world), `quiet`, `tint: false`, `recharge: false`, `move: false` (zoomies in place), `floor`,
  `ledge: false` (knock without the kit's side table).
- It clears the engine emotes (`EMO = []`) and the kit's previous marks (except a `box` still in its time) so glyphs never pile up.
- `nxMark(kind, d, o)` adds one mark alone (see elements.md). `nxClear()` ends them all. `nxHatPop(height, d)` throws the worn
  hat up and lands it back (returns false without a hat).
- lint N10 counts `nxFeel` as a reaction AND an accent (lint expands film functions; the kit's body calls `emote`/`shake`/`N.squash`).

## Coexistence and limits
- Never uses `N.extra` (cutekit's idle slot). Clips are additive: the cute idle keeps running under a reaction.
- Names are prefixed `nx`/`nxf`/`NXF`/`NXCL`/`NXPAL`/`NXC`/`NXREG`: no clash with `react()` (cutekit / s2kit), `glyph`, `focus`.
  Don't declare those names in a film.
- The kit's prop moves itself to the END of the prop list at t = 0.01, so its marks draw over the film's front props.
- The tint, RGB split and motion ghosts redraw her 3D layer (`glcv`) from a world layer; they assume the engine's shake +
  camera roll (handled in `nxfScreenT`).
- Visor icons (spinner, power, boot) and the puppy shine sit on a FRONT-facing visor; the clips keep her head straight for them.
  Don't combine them with a big `look()` or a turn.
- `pounce` and `zoomies` move her (`fly`/`orbit`): plan the landing like any choreography; `goTo` her back afterwards. `zoomies`
  takes `move: false` to run in place.
- The head radius is `U * 0.3 * N.scale` (120 px at depth 0, zoom 1). The engine's own emotes use `U * 0.5` as their spacing.
- `shock` (cucumber) lifts her ~0.95 pose units: keep headroom (nexi-video N5 warns on shockJump-style lifts).
- Seek-safe: every mark is a pure function of (time - start), except the motion-ghost snapshots (sequential renders only, which
  is how render.py works).

## Bench commands (from ~/ClaudeWork/nexi-tutorial; ports 4021-4029 / CDP 9421-9429 are free of the 398x/938x renders)
```
python patches/p100_nexi_feel.py                        # once (already applied 2026-10-10)
python build_film.py nxsheet
NT_VIDEO=nxsheet NT_SHOTS=nxsheet NT_PORT=4021 CDP_PORT=9421 CDP_PROFILE=profile-nt-nxf python render.py shots $(python ~/ClaudeWork/qa/nxfeel/times.py)
python ~/ClaudeWork/qa/nxfeel/grid.py qa/nxsheet/grid.jpg 6
NT_VIDEO=nxsheet NT_FORCE_RENDER=1 NT_PORT=4022 CDP_PORT=9422 CDP_PROFILE=profile-nt-nxf2 python render.py mp4   # the reel (a bench: never through deliver.py)
```
Delete `~/ClaudeWork/qa/nexi/profile-nt-nxf*` after a run (headless Chrome profiles fill C:).
Debug guides: `NXF.debug = true` draws the head circle, visor ellipse, eye points and the neck point.

## Add a new emotion
1. Write its recipe first in `emotions.md` (trigger, face, body, marks, colour, sound, word, d) and check it against the
   non-negotiables in SKILL.md (aimed at the mess, cute, short).
2. Body: add a clip to `NXCL` (`function (p, O, d)`, envelopes with `nxfEnv(p, d, in, out)`).
3. Marks: reuse the library; a new mark is a branch in `nxfDrawMark` (front or back layer), sized by `r` / `kk`.
4. Sound: a new name is a new branch in `audio_t.S` via a new patch (never edit p100 after it ran).
5. The kind: a branch in `nxFeel`.
6. Bench: add a row to `SEQ` in `films/nxsheet.js` and its peak to `times.py`; build, shoot, LOOK at the still, fix, re-run.
7. Document in `elements.md` / `emotions.md`, re-make the sheet, republish the hub Skills page.

## 3D heavy elements: nexi3d (2026-10-10; owner: "make all heavy elements in 3d" -> "test at least 1" -> "continue to all")
Include `web/films/inc/nexi3d.js` on the line AFTER the nexikit include. `NX3.on = false` = the 2D kit again. Bench
`films/nx3sheet.js` (nxsheet + nexi3d; written by `patches/p101_nexi3d_bench.py`, lint TOOL film). The 2D bench `nxsheet`
stays as the reference. Proofs + tools: `~/ClaudeWork/qa/nx3d` (`grid.py` 2D|3D pairs, `zoom.py` 1:1 crops, `all.json` /
`sub.json` shot lists, `sheetshots/` + `sheet3d/` the 3D sheets: `NXF_SHOTS=... NXF_OUT=... NXF_INC="nexikit + nexi3d"
python ~/ClaudeWork/qa/nxfeel/sheet.py`).

**In 3D:** comic words (+ text pops like bang '!'), the anger vein (kit `vein` + engine `angry`), the "..." bubble, puffs
(huff, kettle, engine steam, dust ring with real depth), rain cloud + drops, Zzz, ? (orbit with depth + engine `q`), siren
(dome + base; beams stay 2D), battery (+ level bar + bolt), magnifier, 10/10 card, the box (back wall/floor/back flap
behind her, front + side walls + side flaps in front; no front flap, it hid FRAGILE), dust symbols, papers (held, knock
+ table, report gift), cursor, sweat drops, tears, music notes, faint stars (orbit with depth), engine hearts + confetti.
**2D on purpose:** speed lines, glints/sparkles, gloom/stink/purr/shimmer lines, visor icons (spinner, static, power,
boot, eye shine), aura, heat, bristle, tints, RGB split, ghosts, siren beams, kettle arcs (the `two` part of a handler).

How it works:
- Its OWN WebGL renderer + scene with nexi-core's studio env + lights, camera synced to `CAM` like `N.view`, drawn in the
  kit's back AND front layers via `nxfScreenT`. Never add late meshes to nexi-core's scene (the glow pass caches its mesh
  list -> a late mesh blooms onto itself; the kit's tints use glcv as a mask and would tint props).
- px -> world at depth z: `X = camX + (px - CAM.x) / (S * k)`, `S = H / (48 tan 15deg)`, `k = 24 / (24 - z)`; a 2D length L
  px = `L / (S * k)` world (`nx3L`). Head radius in world = `U * 0.3 / S`. Orbits are real: centre via `nx3W`, offsets in
  world units, perspective does the rest.
- Handlers `NX3.H[kind] = { b: build, u: update(f, g, t, c), two: the 2D part }`; every mesh carries `userData.L`
  ('back' | 'front'); a pass shows only that layer. Marks at full alpha render in one pass; fading marks one pass each
  (`globalAlpha`), never per-mesh opacity on solid letters (it shows their insides). Puffs/drops fade by own materials.
- Engine emotes: the back callback moves EMO entries (sweat, steam, tears, q, angry, notes, stars) into NXF.fx as `e_<k>`
  before drawEmotes runs. Engine particles: `L.emit` is wrapped; heart / conf / txt particles get `layer = 'nx3'` (L.drawP
  skips them), the engine still moves them, the 3D layer draws them with drawP's own pop/fade maths.
- Colour: flat output (NoToneMapping) with softer lights (hemi .32, key .95, rim .5, fill .3). ACES greyed the brand
  colours (yellow KSSHH! went khaki). Type palettes get `nx3Vivid` (+15% saturation). Toy plastic = MeshPhysical +
  clearcoat + emissive ~0.2-0.4 of its own colour; navy outline shells behind letters, bubble, card, cursor, battery.
- Font: Plus Jakarta Sans 800 as `web/assets/fonts/pjs800.typeface.json` (`qa/nx3d/font2typeface.py`; the drip-studio
  woff2 is VARIABLE: instance wght 800 first). r128 core has TextGeometry + FontLoader. Loaded by sync XHR at include time.
- Add a 3D element: a handler in `NX3.H` (or `NX3.P` for a particle kind, `NX3.EMOK` for an engine emote); place it with
  the 2D maths (same px, sizes in r), `nx3Put(o, px, py, z, lenPx)`; shoot `qa/nx3d/sub.json`, `grid.py`, `zoom.py`, LOOK.
- Delivered for review 2026-10-10: Drive `05. NEXI/03. Nexi Character/3D test/` (comparison, 3D emotion sheet, 3D
  element library, 3D reaction reel). The 2D sheet/reel (01-03 in the parent folder) stay until the owner approves.

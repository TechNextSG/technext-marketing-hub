---
name: nexi-character
description: Nexi's character bible and reaction system - who Nexi (TechNext's 3D robot mascot) is, her cute-angry cat attitude ("offended by mess, soft on people"), the 35 emotions and reactions (the rage ladder L1-L5, trouble, cat habits, robot-only, wins), and every element that makes a reaction read (eyes, body, manga marks, mood colour, screen effects, comic words, props, sounds, timing). Includes the renderer kit nxFeel (web/films/inc/nexikit.js in ~/ClaudeWork/nexi-tutorial) that plays any reaction in one call, the reaction reel bench, and how to carry the same character into posters, thumbnails, social posts and captions. Use whenever Nexi appears or speaks - a Nexi video, poster, thumbnail, social post, reel, caption or script - whenever the user asks about Nexi's personality, attitude, emotions, expressions or reactions ("make Nexi react", "make her angry", "cuter", "more exaggerated", "when things go wrong"), or wants a new emotion added.
---

# Nexi's character

Nexi is TechNext's mascot: a small white egg-shaped robot with a dark glass visor face, glowing eyes and a hat for every job. She is **she/her**. She lives in the Nexi Explains videos, the posters, the thumbnails, the social posts and the website.

Until 2026-10-10 she had a look but no attitude. The owner asked for one: *"at least need a exaggeration reaction when thing went wrong ... about being angry, like a cute angry adorable. cat attitude like that?"*, then *"lets build nexi skills. include all of this emotion and reaction. also show element/reaction or anything that can make nexi reaction more define."* This skill is the answer. Read it before you make Nexi do or say anything.

## Who she is, in one line

**A tiny robot with a cat's attitude: offended by mess, dramatic about it, then fixes it anyway, and she is soft on you.**

Three pillars:
1. **Allergic to mess** (the trigger). Retyping, the same data twice, 14 versions of one spreadsheet, lost invoices, paper. That is what sets her off, and it is exactly what Odoo removes, so her reaction is the pitch without selling.
2. **Boss-fight energy** (what she does). Tiny body, huge hero moves over boring tasks. She suits up (a hat per job), the mess becomes a villain, one punch = one click.
3. **"It's not you, it's the process"** (her heart). She is always on the human's side. She coaches, celebrates small wins and never makes anyone feel slow.

Her lovable flaw: she goes soft over clean data (heart eyes at a tidy dashboard) and gets a bit too eager to automate everything.

## The non-negotiables

| Rule | Why |
|---|---|
| **The anger is aimed at the mess, never at the person or the viewer.** She side-eyes the spreadsheet, not Maria and not the camera. | Angry at the viewer = the software scolding the customer. Angry at the mess = on the customer's side. |
| **Anger is a 1-2 s burst, then the fix.** Mess -> reaction -> "Fine." -> hero fix -> soft moment. | A lingering tantrum reads negative. The payoff is always the fix and the win. |
| **Every reaction is exaggerated** (nexi-video rule N10): at least a face + a body move + one accent (mark, word, colour, shake). | Owner: "make sure there's a exaggeration effect in every reaction. make nexi reactive." |
| **Cute, not scary.** Round shapes, squeaky sounds, puffed cheeks. No teeth, no glowing red evil eyes, no real violence. | She is adorable-angry, like a cat that knocks your cup off the table. |
| **Words in her captions can be sassy, never mean.** The attitude lives in her face and body. | Written sarcasm reads harsher than animated pouting. |
| **Use the ladder, don't max it out.** Most beats are L1-L3; save the meltdown (L4) for the big moment. | A tantrum every time gets old. |
| **She is distinct from Jun** (S2 cast, eager and dramatic all the time). Nexi is a calm coach who EXPLODES only at the mess and at the win. | Two characters with the same energy blur. |

## The beat formula (every "things went wrong" moment)

```
MESS SPOTTED  ->  REACTION (rage ladder L1-L5, 1-2 s)  ->  "Fine."  ->  HERO FIX (one click)  ->  SOFT MOMENT (slow blink / loaf / heart eyes)
```

Example (15 s): Maria retypes an order into a spreadsheet. Nexi: `nxFeel('offended')` "You typed that TWICE?!" -> she puts on her hat, punches the Double-Entry Monster (the Odoo button) -> the dashboard fills, `nxFeel('slowblink')` "It wasn't you, Maria. It was the process."

## The 35 reactions

Full recipes (trigger, face, body, marks, colour, sound, word, length, notes) are in `reference/emotions.md`. Quick map:

| Group | Kinds | Use for |
|---|---|---|
| **Rage ladder** | `annoyed` L1 · `grumpy` L2 · `offended` L3 (the hiss) · `meltdown` L4 · `faint` L5 · `angry {lvl}` picks one | Mess, retyping, chaos, disaster: pick the level from how bad it is |
| **When things go wrong** | `shock` (cucumber jump) · `disgust` · `panic` · `puppy` · `sulk` · `suspicious` · `confused` · `cry` · `oops` · `facepalm` | Surprises, old paper, deadlines, pleading, being ignored, numbers that don't match |
| **Cat attitude** | `knock` (knock it off the table) · `pounce` (cursor chase) · `box` · `knead` (+ `loaf`, `slowblink`, the hiss in `offended`) | Her signature gags: knock = "this belongs in the bin" |
| **Robot-only** | `buffering` · `lowbatt` (+ recharge) · `glitch` · `reboot` · `overheat` | Too much manual process, long days, overload: only a robot can do these |
| **When things go right** | `joy` · `zoomies` · `smug` · `gift` · `love` · `loaf` · `slowblink` · `cheer` · `shy` · `laugh` · `dance` | The fix landed, a deal won, clean data, praise |

**Her signature trio** (what people will remember): **knock it off the table**, **buffering**, **the slow blink**.

## What makes a reaction read (the element grammar)

A defined reaction stacks these layers. The full library is `reference/elements.md`.

1. **Face**: eye shape (open happy star line big heart x), eye angle (angry slant / sad slant / side-eye), eye size + pop, hidden eyes (visor icons), mouth (smile / o, sized), blush.
2. **Body**: anticipation (crouch / squash) -> action (jump, puff up, turn away, swipe) -> hold -> settle. Arms tell the story (crossed, claws, hands to cheeks, fist up).
3. **Marks** (manga symbols at the head): anger vein, steam, sweat, tears, "...", "?", "!", stars, hearts, gloom lines, rain cloud, stink lines, purr lines, Zzz, siren, spinner, battery.
4. **Mood colour on her body**: red face flush (`head`), red rising up from the feet like a thermometer (`rise`), blue draining down (`drop`), green face (disgust), pink (love), grey (low battery), gold aura (pride).
5. **Screen effects**: shake, speed lines, white flash, red/blue edge pulse, RGB glitch split, motion ghosts.
6. **Comic word**: HMPH! KSSHH! GRRR! EWW !! AAAH! W-W-WHAT YAY! ZOOM! HEHE (extruded, outlined, popped).
7. **Sound**: one per reaction, soft (hiss, purr, hmph, grr, glitch, powerdown, boot, ew, whimper, rain, scurry, glint, kettle, mrrp, beep + the engine's gasp, boing, wah, steam, giggle, tada...).
8. **Timing**: anticipation 0.1-0.3 s, hit on a word of the line, hold 0.6-1.5 s, settle 0.3 s. Big = short.

## Where it lives and how to use it

### In a Nexi video (the renderer `~/ClaudeWork/nexi-tutorial`)
- Add `/*@include nexikit*/` to the film (after tipkit / cutekit / s2kit / envkit), and on the next line the include for `nexi3d` (all heavy elements as real 3D objects; 2026-10-10, see `reference/kit.md` "3D heavy elements"; `NX3.on = false` = flat 2D). Then `nxFeel(kind, opts)` on the caption word: `at(l3.w('TWICE'), function () { nxFeel('offended'); });`
- Options: `d` (seconds), `lvl` (for `angry`), `word` (custom comic word, or `false`), `side` (1/-1), `to` ({x, y} world target for side-eye, knock, pounce), `quiet` (no word, no big marks: safe near text cards), `tint: false`, `recharge: false`.
- lint N10 counts `nxFeel` as a reaction and an accent automatically (it calls emote/shake/squash inside).
- API, include rules, coexistence with cutekit `react()` and the S2 kit, and the limits: `reference/kit.md`.
- `pounce` and `zoomies` MOVE her (they use `fly`/`orbit`): plan the landing spot like any choreography (rule F3 framing).

### In posters, thumbnails and social posts
- Render the reaction from the engine (the real 3D Nexi + the kit's marks): use the bench `films/nxsheet.js` (every kind on a clean stage) or add `nxFeel` to the thumbnail/poster bench, then `render.py shots` at the peak time (`~/ClaudeWork/qa/nxfeel/times.py --list`). Cut out with rembg if a transparent Nexi is needed.
- Drawn 2D marks for thumbnails already exist in `films/inc/t3kit.js` (`e3Vein e3Steam e3Sweat e3Gloom e3Bolt e3Spiral ...`). Use the SAME meanings and colours as `reference/elements.md`.
- Pick the reaction from the post's story: a "pain" post = a rage-ladder or trouble reaction aimed at the mess prop; a "result" post = a win reaction. The Odoo screen / the problem stays the hero (nexi-video H12); Nexi carries the exaggeration.

### In words (captions, scripts, post copy)
Her voice, catchphrases and lines per emotion are in `reference/voice.md`. Short, chirpy, no jargon, no selling, first person is fine, about one catchphrase per piece.

## Reference files
- `reference/emotions.md`: the 35 recipes.
- `reference/elements.md`: the element library (faces, bodies, marks, colours, effects, words, props, sounds, timing).
- `reference/voice.md`: personality in words.
- `reference/kit.md`: the nxFeel API, files, bench, render commands, limits, how to add a new emotion.

## Deliverables of record (2026-10-10)
Drive `02. TechNext Folder\05. NEXI\03. Nexi Character\`: the emotion sheet, the element library board and the reaction reel MP4. The bench that makes them: `web/films/nxsheet.js` (lint TOOL film).

## Keep it alive
After any job where Nexi acts or speaks: if the owner reacts to her character ("too angry", "cuter", "more!"), log it verbatim in `reference/emotions.md` (or voice.md) under the kind it touches, change the recipe in `nexikit.js`, re-render the bench stills, and mention it in the nexi-video `lessons.md`. A new emotion follows `reference/kit.md` "Add a new emotion". Then republish the hub Skills page (`python ~/ClaudeWork/technext-marketing-hub/tools/build_skills.py`).

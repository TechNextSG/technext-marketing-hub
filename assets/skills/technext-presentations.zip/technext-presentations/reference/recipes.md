# Recipes: the common jobs

Every recipe ends with the pipeline's steps 3–10: build, ASSET_V, preview, `deck_check`, PDFs and thumbnails, ship, Drive, report and train.

## Change a fact, name, number or wording everywhere ("apply to all")
1. `grep -rn -i "<old>" _src assets README.md`. Also search close variants: plural, capitalised, with or without a hyphen, and the short form.
2. Change every source hit: deck HTML, notes, `*_data.py`, partials, JS strings, `DECKS` descriptions in build.py, and README tables or rules.
3. Build, then `grep -rn -i "<old>" *.html s-*.html`. It must return ZERO. Paste that proof in the report.
4. Reprint the PDFs of every deck that changed (`deck_pdf.py <decks> --look`). Reshoot thumbnails if a cover or hover slide shows the fact.
5. Add the fact to `content-rules.md`.

## Edit one slide
1. Find it: `grep -n 'id="<id>"' _src/decks/<deck>.html`. Its script is `Deck.on('<id>'` in `assets/<deck>.js`, and its styles use the slide's prefix in `assets/<deck>.css`.
2. Keep the grammar: a kicker → `.h-m` with one `.hl` → `.lead`, staggered `data-in`, and notes.
3. If the slide animates from JS, check that `settle` still paints the finished state. Test with `?print` and the overview `O`.
4. Preview at `/<deck>.html#<n>`, step through every build, then hold a phone upright (`resize_window` mobile).

## Add a slide
1. Copy the closest slide in the same deck (or another deck) and give it a new unique `id` and a `data-title`.
2. Add its hooks (`init`/`enter`/`step`/`settle`), using `ctx` for every timer and listener, and its styles with a fresh prefix (grep first).
3. Slide numbers shift. Update the README slide count and any "slide n" text (the tier decks compute theirs). Check the hover slide in `scripts/thumbs.py` `HOVER`.
4. Add a decorative infinite animation to deck.css's `.deck.is-tv` list.

## Remove a slide
1. Delete the `<section>`, its `Deck.on` hook, its styles (unless shared: the `proposal.css` kit keeps its chart styles for future proposals) and any build step only it used.
2. Re-sequence the entrance timings and numbering on neighbouring slides when they referred to it.
3. Update the README count, `decks.md`, and any `data-go` jump that pointed at it. Reprint the PDF and recheck the hover thumbnail.
4. Log the removal as a user decision in `lessons.md` and `decks.md`, so nobody brings it back.

## Add a new deck
1. Write `_src/decks/<slug>.html` from the closest deck (head, body `data-label` + `data-home="./"`, `{{og:<slug>}}`), plus `assets/<slug>.css|js`.
2. Add it to `DECKS` in `_src/build.py` (group, slug, title, mins, pdf, alt, desc). The build creates its share token in `_src/share.json`.
3. Mark any link to another deck `data-internal`.
4. Run `thumbs.py <slug> --hover N`, `deck_pdf.py <slug>`, bump ASSET_V and build.
5. Add it to the README deck table, update the launcher's description meta, and add it to `decks.md` and `thumbs.py` `HOVER`.
6. Run `deck_check.py <slug> --shots --phone`.

## A new client sales proposal
1. Read the client's requirements file and verify every public fact on the client's own sites (note the date). Keep internal research out.
2. Copy `hitachi-elevator-ph` as the frame: cover with a lockup, what we understand, pressure points (hypotheses), architecture, 4–7 workflow demos on labelled sample data, scope in the client's phases, roadmap, contact.
3. Add `data-cobrand` logos (`assets/img/clients/<client>.png` + `-white.png`, from the client's official files or the user's upload).
4. Use `proposal.css|js` (PX charts with validated palettes, `.px-gl` gridlines, `PX.svgAt` for SVG hover) and write `assets/<client>.js`, with a settle hook on every animated slide.
5. Add it to the "Sales proposals" group, then send the share link (never the launcher), after the user's sign-off.
6. Write a memory file for the proposal (phases, decisions, the share link).

## Add or recapture a site (Marketing Showcase / Portfolio)
1. Add or edit the entry in `_src/showcase_data.py` (LIVE / CONCEPTS / MORE / PITCH) and/or `_src/portfolio_data.py`. Every URL must return 200.
2. Capture `<slug>-d.jpg` (1440 wide) and `<slug>-m.jpg` (390 wide). See the capture rules in build-and-ship.
3. Run `python -B _src/sites_images.py <capture dir>`, then `python -B _src/build.py --prune`, then bump ASSET_V.
4. Check the gallery wall: its columns are chosen so every row is full (`mz_layout`).

## Change the tiers
1. Edit BOTH `erp-tiers.html` and `marketing-tiers.html`: the cards, explorer, finder `min` indexes, add-ons and the cover lines.
2. If the tier count changes, the finder's `min` values and the explorer data must follow. `tiers.js` reads the count from the cards.
3. Prices stay "On quotation" and service fee. Keep the note under the cards.

## Retire a share link (only when the user asks)
Change that deck's token in `_src/share.json` and build. The old `s-*.html` is deleted. Tell the user that the old link is now dead for everyone who has it.

## Edit all the presentations (a sweep)
1. List the change per deck in a table first (deck, slides, change). Agree it with the user if it is a content call.
2. Work deck by deck, building after each. Run `deck_check.py` on all decks at the end, plus `deck_pdf.py --all --look`.
3. One commit per logical change (not per deck), so each can be reverted alone.
4. Thumbnails for every changed cover or hover slide, and a single ASSET_V bump at the end is enough if nothing shipped in between.
5. Report a status table for all 11 decks, even the untouched ones ("no change").

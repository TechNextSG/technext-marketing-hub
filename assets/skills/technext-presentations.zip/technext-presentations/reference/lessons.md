# Lessons log

Add a dated entry after every presentation job, with the newest at the bottom and one bullet per lesson. Quote the user verbatim when they set a rule. When a lesson becomes a rule, add it to `content-rules.md`, `engine.md` or the SKILL.md Non-negotiables table.

## 2026-09-27/28 · First three decks and the launcher (f86021b)
- **User:** "create a powerpoint presentation html base on technext website branding… highly interactive and animated… different html file". The first decks were the company profile, the service showcase, and What is Odoo with a lead-to-cash walkthrough.
- **The engine was built once and shared:** a 1600x900 stage, builds, overview, notes, kiosk and print. Each deck has its own CSS and JS. Pages deploy via Actions, because the legacy Pages builder wedges.

## 2026-09-28 · Leaving a deck glitched (dda7122)
- Esc opened the overview, and in full screen the browser also uses Esc to exit, so the two fought. **Esc now only closes things.**
- Opening the overview, or going Home, flew every slide across the stage. **The stage now fades out, swaps, and fades back in** (`is-fading` + `no-anim`).
- Hover lifts on cards shook when the pointer rested on an edge. **No hover lifts.**

## 2026-09-28 · More decks: tiers, portfolio, showcase; phones; print (12bdd0f, cfe0f3e)
- **User:** "add more presentation". Added the ERP and Marketing tier lists, the Portfolio (from the Drive client folders, repos and sessions) and the Marketing Showcase (every live site and mockup).
- **User:** phones must auto-rotate. The whole deck turns 90° when held upright. Every position read had to go through `Deck.rect`/`Deck.point`, or drags and hovers missed by 90°.
- **User:** PDFs must show every slide finished. **Print never plays a slide**: `settleAll` paints every build and runs every `settle` hook. Six slides printed half-done until they got settle hooks: the engagement steps, the CRM board, the customisation answer, the integration counters, the tier finder and the plan builder. The overview reuses the same hooks.
- **Site captures:** keep the real viewport height and use `captureBeyondViewport`, because resizing to the page height stretched 100vh heroes. Skip intros, and seek paused poster-less videos.
- **Print ignores CSS `filter`,** so dark slides need the white logo PNG. `h0` dots vanish in PDF, so use `h.01`.

## 2026-09-28 · Share links and the launcher card row (79093a1, ff87a2a)
- **The need:** send one deck without the way to the others. Each deck builds as `s-<token>.html`: no Home button, `data-internal` links stripped, and the build exits if a leak remains.
- **User:** the card actions go on ONE row of small buttons (13px, 33px tall, nowrap). A size container hides the icons, then "loop", then padding as the card narrows.

## 2026-09-28 · Sales proposals: Hitachi Elevator Philippines (725c1fd, 017a416, 4ec5532)
- **User:** "create a sales proposal category base on client requirements… highly animated workflow, chart". It was built from the pre-discovery analysis, using only HEP's public facts. The pains are hypotheses and every demo is labelled sample data.
- **The user set the phases;** PH2 is "to confirm" because it depends on GERP. Inventory and AI were dropped. The Hitachi logo sits beside TechNext's (`data-cobrand`).
- **Chart gridlines drawn with `repeating-linear-gradient` printed as striped bars.** They are now real 1px elements (`.px-gl`).
- **SVG hover:** `Deck.lbox` is HTML-only and gives NaN on SVG, so use `PX.svgAt` (getScreenCTM).
- **The cover connector** started 70px below the labels and the Makati shaft touched the top edge. Measure after every layout change.

## 2026-09-28 · Odoo 20 everywhere (017a416)
- **User:** "technext presentation also need to be fully updated… mention about odoo 20". Added the "Odoo 20, in six changes" slide. The catalogue now says Field Service runs in Planning and VoIP is Phone, and the kickers say "odoo 20". Facts come only from the release notes.

## 2026-09-30 · Removals the user asked for (d5937c1, 65562c3, 3328e3a)
- **Portfolio:** the clients x services matrix is gone. Client lists are plain bullets with NO dates. The "Proposals, concepts and paused work" slide is gone.
- **Hitachi:** slide 3 lost the parts point and the Inventory and Purchase cards ("Five places…"). The parts slide and the "Five questions" slide were removed (16 → 14 slides).
- **After a removal:** re-sequence the entrance timings, reprint the PDF, recapture the hover thumbnail if its page number moved, and bump ASSET_V.

## 2026-09-30 · Office roles (4f6d41d)
- **Per Pia Cachola:** the Philippines (Taguig City) is the main development and consulting hub, and Vietnam (Ho Chi Minh City) is AI engineering. This touched the office cards, map labels, notes, the who-we-are lead, the engagement slide and the service showcase Build phase.
- **One fact, many places.** Grep every deck, note and README rule.

## 2026-09-30 · Tier decks to three tiers (afc611d)
- **User:** three tiers only. Starter folded into Essentials (ERP) and Launch (marketing). Enterprise and Brand are "customisation", and add-ons are the customisation layer.
- **Every price is TechNext's service fee.** Say so on the slide. The code follows the tier count.

## 2026-09-30 · Smooth on TVs, then a Display option (e7ed568, d5eed94)
- **At 4K the decks stuttered.** Causes: about 30 loops on hidden slides kept ticking; 90px blur glows; backdrop blur. Fixes: pause every animation off the current slide, use radial-gradient glows, drop backdrop blur, and promote scroll pictures to a GPU layer only on screen. The company profile at 4K with a 4x CPU throttle went from 63 to 121 fps.
- **The Display menu:** `T` cycles HDMI (full), Wi-Fi/casting (less motion) and Auto. **Any new decorative loop must join the `.is-tv` stop list.**

## 2026-10-02 · Present anywhere (7891853, c421adf)
- **An audit of real set-ups:** cable, casting, screen share, the TV's own browser, a Bluetooth clicker, no internet. It added:
  - the presenter view (`P`, BroadcastChannel sync);
  - clicker keys: B and `.` black, W and `,` white, F5 for full screen;
  - Wake Lock, and a hidden cursor;
  - `sw.js` offline copies (live https only);
  - self-hosted fonts;
  - `inset` spelled out for 2020–21 TV browsers.

## 2026-10-02 · Showcase refresh; the Odoo app series (9987823, 428c0c8)
- **Showcase:** five sites were recaptured after their redesigns. **User:** remove Blue Moon and Tri-Comp. The wall picks a column count so every row is full. Pictures carry `?v=`, so offline copies refresh. `sites_images.py` now merges, so a partial recapture keeps the rest.
- **A parallel session** built the Accounting, Sales and CRM decks with the impeccable and web-design-engineer skills. The structure is one live Odoo window held across seven cut slides (`data-group`). One sample company, Kestrel & Pine, runs through all three. Labels follow the 20.0 docs. DESIGN.md and PRODUCT.md came from that work.
- **A capture can open a hover menu** (HummingBeing's Services). Force dropdowns hidden while capturing.

## 2026-10-03 · TRE in Singapore's live domain (c428d9f)
- The Showcase and the Portfolio still showed the old test address after the site moved to `tre-in-singapore.com`. **When a client site changes its domain, grep the decks.**

## 2026-10-04 · This skill
- **User:** "check the skils in the presentation https://technextsg.github.io/technext-presentations/, later on i will edit all the presentation. make sure the capture the skills for this".
- **The skill captures** the engine, the build, the 11 decks, the content rules, the design system (condensed from the untracked DESIGN.md) and this history. Four tools came with it: `deck_check.py` (QA gate), `deck_pdf.py`, `thumbs.py` and `drive_sync.py`. The thumbnail and Drive scripts used to live only in an old scratchpad.
- **Baseline QA:** 0 errors and 16 warnings across 11 decks. The list is in `decks.md` ("Baseline QA"). `deck_check` first called an ellipsis a "cut", so it now reports `text-overflow: ellipsis` as "text truncated" by name. The checker was proven on planted defects (off-stage text, overlap, tiny text, a broken image), and `thumbs.py` reproduced the committed thumbnails (mean pixel difference under 1).
- **The gap to close in the next edit:** technext.asia added a fourth practice, Technology (IoT · Apps · Networks), on 2026-10-03. The decks still show three practices and "fourteen services".

## 2026-10-06 · JR-Tech Solution client deck (5d80e2e)
- **User:** "create Presentation JR Tech https://technextsg.github.io/technext-presentations/ use this material, question at the back", then attached `JRTech-Accounting-and-Billing-Questions.pdf`: "add this", "at the end of presentation". So "question at the back" meant the client's discovery questions as the last part of the deck, before the close. When a short instruction is ambiguous, wait a moment for the rest; this user often sends the material in a second message.
- **A 100 MB PDF** can't be read by the Read tool (limit 100 MB): extract text with `pymupdf` (`page.get_text()`) and render 48 dpi contact sheets of four pages to look at the design.
- **Make the material work, don't transcribe it:** each static slide got one interaction that proves its point (drag the cut-off into mid-month and it turns red; the migration lines travel the way they really move; a go / no-go gate that only goes green with five checks; the questions as live tick buttons with counters on the part-04 tiles and a copyable follow-up list).
- **`data-step` is the engine's build attribute.** A jump button marked `data-step="1"` would have become a hidden build. Jumps to a build use `data-go` + `data-at` (handled in `jrtech.js`).
- **Text beside a `<b>` inside a flex button splits into two columns** (the text node becomes its own flex item). Wrap the label in one `<span>`; caught on the contact sheet, not by `deck_check`.
- **Per-card vignettes align only if everything under them has a fixed height** (the benefit pill went to 52px). Check the bottoms of a card row on the sheet.
- **Hidden preview panes throttle requestAnimationFrame:** a `ctx.tween` or `ctx.count` checked from `javascript_tool` while the pane is hidden can read mid-way. Read the value again later, or rely on `deck_check` (headless, visible).
- **Clipboard:** `navigator.clipboard` can be refused (no focus, file:// Drive copies). Fall back to `execCommand('copy')`, then to a visible textarea with the text selected.
- **Build after printing:** the launcher's PDF button only appears if `pdf/<name>` exists at build time, so build once more after `deck_pdf.py`.

## 2026-10-06 · A video in the JR-Tech deck (9b93fbd)
- **User:** "add this video after page 15" (a WhatsApp MP4, 3:21, narrated: part 3 of TechNext's Odoo 20 accounting video series for JR-Tech). Page 15 was the risk register in both the source PDF and the deck, so it became slide 16.
- **Read the video before placing it:** `ffprobe` (size, codec), a 14-frame contact sheet, `faster-whisper` on 40 s to learn it is narrated (so it plays with sound), and caption-badge crops at 1 fps to find the chapter times.
- **The engine's offline copies could not seek video:** `sw.js` cached everything and had no answer for `Range` requests. It now cuts 206 slices from the saved file. Tested live: offline, with the network cut, chapters jump and play.
- **Local tests mislead for video:** SimpleHTTP ignores ranges (seeks snap to 0), and a hidden preview pane or a background CDP tab defers playback. Test on the live site, each page in its own window.
- **Presenter view needed its own sync** for media: the deck's BroadcastChannel only moves slides.

## 2026-10-06 · The video zooms and comes back (d2a0ab2, afec470)
- **User:** "make the video can zoom properly and exit seemless bck to presentation". The browser's video full screen was the problem: leaving it also left the deck's full screen.
- **Built:** the deck's own zoom (FLIP from the slide to the whole stage; document full screen only if needed; Esc held by the Keyboard Lock API so it only shrinks the video) and a TechNext control bar, because `controlslist="nofullscreen"` still drew a greyed full-screen button that did nothing.
- **Tested with real input events** in headless Chrome (`Input.dispatchMouseEvent` / `dispatchKeyEvent`, so full screen counts as a user gesture): zoom by button, Z and double-click; back by Esc, Z, double-click and the Back button; deck already in full screen stays there; PageDown comes back and moves on; presenter view mirrors the zoom. Click a faded control without moving the mouse first and the click goes to the video: move the mouse in tests.
- **A real bug the zoom work surfaced:** chapter jumps failed with a media error once the offline copy had saved the video (pieces from the network and from the cache in one stream). `sw.js` is now network-first for ranges, and the player reloads and resumes after any media error. Test chapter jumps both before and after the background save.
- **The Bash tool halves backslashes** inside heredocs: a `split('\n')` in a JS string broke a test. Write such scripts with the Write tool.

## 2026-10-06 · Faster-hiding video controls (f12a5b9)
- **User:** "when not active, hide floating ui in the video much faster". Idle 2.6 s -> 1.1 s, fade out 0.2 s, instant on mouseleave; kept while hovered, seeking or paused; 2.6 s after a touch tap. Measured with real mouse events (`qa/jrtech-deck/idle_test.py`) locally and live.


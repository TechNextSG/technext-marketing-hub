# Engine reference (film-script API)

A film file is plain JS running inside one closure with every engine helper in scope. World coordinates are px on a 1920×1080 stage as seen with the camera at home; the world can extend far beyond the frame.

## Timeline
- `say(text, {hold, delay})` → line `{t0, end, w(word, nth)}`. Speaks in Nexi's robot voice (42 ms/char, pauses at punctuation) and types the caption. `**bold**` highlights. Advances `cur`.
- `at(t, fn)` schedules at absolute time; `later(d, fn)` relative to now (inside callbacks); `wait(d)` advances `cur`.
- `everyFrame(fn)` per-frame mover; return `false` to stop. A mover may start other movers.
- `hud(title)` (define in the film) updates the top-left chapter pill.

## Intro / outro
- `introSeq({ sub, hud, pills: [[icon, label]…], nx, ny, extra: fn(gg, t) })`, where pills use Odoo app keys (`crm`, `sale`, `account`…) or `L.ICON` names (`globe`, `megaphone`, `spark`, `layers`, `leaf`, `hanger`, `plane`, `train`, `hardhat`, `magnifier`). Put the video's badge in `extra` with `badge(gg, text, Intro.slotL().x, Intro.slotL().y, { col, icon, rot, k, fs, ring })`.
- `outroSeq({ cta, sub, nexi, extra })`:
  - `cta: endCtaMkt` and `sub: 'Websites · Social · Brand'` are for marketing videos. The default is the Odoo end card.
  - `nexi` is the end-card spot: `top` (960, 250), `left` (300, 520), `right` (1640, 520), `below` (960, 985, peeking up), `leftlow` (300, 770) or `rightlow` (1640, 770). Use a different one per video. Coordinates live in `OUTP` in `engine_head.js`; test with `films/outrotest.js`.
- The world is hidden (`WORLDOFF`) while the intro logo or the end card is on screen.

## Camera
- `CAM.{x, y, zoom, rot}`: the world point at the screen centre, the zoom, and the roll in radians.
- `cam({x, y, zoom, rot}, dur, ease, delay)`, `camWhip(x, y, dur, {zoom, rot})` (fast pan with motion blur and a whoosh), `camFollow(fn, k)` (track `fn()`), `camHome(dur)`.
- `toScreen(p)` / `toWorld(p)` convert between world and screen.
- Nexi and the 3D set mirror pan and zoom in 3D, so they render sharp. Keep the zoom between 0.6 and 1.6.
- Screen-fixed things (cards that must not move with the camera) go in a prop's `screen` layer.

## Nexi
- `N.place(x, y, z)` teleports her (use it off-screen, then `fly` in on the next frame with `later(0.05, …)`).
- `fly()` starts from `N.botPx()` and moves her through `N.go`, a spring, so she lags and cuts corners on fast curved paths. Keep 250 px of clearance and about 1300 px/s or slower.
- `goTo(x, y, z)` moves her on a spring. `fly(points, dur, {e, pose, then})` follows a Catmull-Rom path, `hop(x, y, z, dur, h)` makes an arc, and `orbit(cx, cy, r, turns, dur)` circles a point. z > 0 is closer and bigger; keep z between −4 and 4.
- `N.headPx()`, `N.handPx('L'|'R')` and `N.botPx()` return world px. `N.scale` is the depth scale.
- Acting:
  - `E.joy/star/shock/wink/focus/cross/think/love/dizzy(d)` set expressions.
  - `RX.shock/panic/nope/joy/laugh/faint/cry/huff/love/hmm/dance()` are full reactions.
  - `N.play(clip)` plays a clip: `bigjump`, `flip`, `wave`, `cute`, `kiss`, `presentBig`, `pointR2`, `pointL2`, `pointUp`, `tapBig`, `tapBigL`, `shockJump`, `excited`, `shrug`, `nope`, `laugh`, `facepalm`, `tantrum`, `panic`, `groove`, `think`, `slam`, `toss`, `tossL`, `hammer`, `salute`, `peer`, `superman`, `water`, `paint`.
- Costumes: `wear('hardhat'|'conductor'|'pilot'|'glasses'|'strawhat'|'beret'|null)`. New costumes go in `build_core.py` `buildWear()` and are built up front.
- `look(x, y, d)` makes her look at a point, then back at the viewer.

## Film-local helpers worth copying (they live in the films, not the engine)
- `pocket(o, hand, dx, dy)` puts a `thing` at her hand, then `grab`s it, so it never glides in from (0,0).
- `smallCheer()` celebrates without the 330 px `bigjump` (`excited` + star eyes + sparks + `tada`).
- `one(i, v)` makes a `{i: v}` object for per-index tweens (never tween a whole array).
- `fitText(gg, s, x, y, fs, col, maxw)` shrinks text to fit a box.
- `rideRail()` (brand) and the envelope or plane movers (web, enterprise) let her ride something instead of crossing text.

## Names a film must not use (engine globals)
`CAM CAP CAPHIDE_O CAPX CH CHAPS CHLOCK DESAT E EMO END0 ENV EV EVS FLY FONTS FX GAZE HUD KIT LASTGO LENS N NX PROPS QZ QZP RX SET SHEET SPL SPOT TETH THINGS TICKS TRUCK W WITH ZAPS`, plus `g`, `H`, `U`, `C`, `L`, `UI`, `P`. Reusing one (for example `var CH`) breaks the engine in odd places.

## Props and things
- `prop({ on: true, back(gg), front(gg), screen(gg) })` draws a layer:
  - `back` is drawn behind Nexi, `front` in front of her (text there can cover her);
  - `screen` is fixed to the screen, unaffected by the camera.
- `thing({ draw(gg, o), layer, x, y, s, rot, a })` makes a world object Nexi can handle:
  - `grab(o, hand, dx, dy)` glides it into her hand;
  - `toss(o, x, y, dur, { h, spin, land, then })` throws it;
  - `holdPose(on)` sets a carrying pose.
  - Stacks the viewer reads should sit in the `back` layer; switch to `front` when grabbed.
- `KIT` drawing kit:
  - `KIT.card(gg, x, y, w, h, {r, sh, edge, fill})` and `KIT.chip(gg, text, x, y, col, bg, fs, {icon, edge})`, which returns the width;
  - `KIT.person`, `KIT.arrow`, `KIT.ground` (a soft floor shadow), `KIT.stamp(gg, text, x, y, col, k, rot, fs)`;
  - `KIT.paper(kind)` draws a spreadsheet, slip, invoice, note or mail.
- Particles and pops:
  - `L.sparks`, `L.confetti`, `L.hearts`, `L.ring` and `L.emit` for particles.
  - `L.pop(text, x, y, {follow})` is mapped to the screen and clamped. Never let a pop drift into the HUD.
- Odoo tiles: `L.drawTile(gg, key, x, y, size, alpha, rot)`. Add new keys to `L.ODOO` in `lib.js`.

## Viewer quiz
- `quiz({ q, opts, ans, t, side: 'left'|'right'|'auto', y, layout: 'card'|'wide' })`, then `quizReveal()` and `quizOff()`.
  - The `card` layout is 760 px wide beside Nexi.
  - The `wide` layout is a 1180 px band. The default y is 700, just above the caption; pass `y: 40` for a top band. Use it when the subject must stay visible.
  - When the answers don't fit beside the question, the wide band switches to two rows by itself (p25): question on top, answer pills centred below, 216 px tall.

## Effects
- `shake(k)`, `speedLines()`, `FX.flash = T` (white flash), `FX.mb = T` (motion blur), `FX.desat` + `FX.wipe` (grey-to-colour wipe), `bang(text, col)`, `emote(kind, d)`.

## Odoo screens (Odoo-app films)
- `P` is the window pose (`SET.PBASE` safe area) and `UI.go(screen)` switches screens.
- `tap()` becomes `zap()` (a beam plus an outline). Use `spotlight(key|rect)` / `spotOff()` and `lens(key, {k, pos})` / `lensOff()`.
- `tether(fn|key)` with `TETH.sag` makes the beam run under cards.

## Audio
- `sfx(name, vol)` plays an effect: whoosh, swoosh, swish, pop, tap, tick, click, type, ding, chime, sparkle, stamp, drop, pick, cash, truck, heart, gasp, boing, tada, magic, holo, rise, buzz, giggle, wah, steam, hmm, dizzy, alarm, ring, clock, whip, slide, chirp, hammer, saw, crane, whistle, chug, bell2, jet, shutter, pour, grow, bee, snip, spray, jingle, plug, flap, splash.
- `music(cue)` takes `intro`, `main`, `tense`, `after`, `outro` or `end`. The film's preset comes from `audio_t.MAIN` (film → style). Styles: walk, myth, tip, reorder, tense, before, after, build, rail, jet, web, garden, studio.
- `MUSIC_GAIN` is set per film. Measure with `_buslevel.py`.

## Added in batch 3 (2026-10-04)
- **Costumes:** `wear('chef'|'cap'|'knight'|'bowtie'|'goggles'|'bellhop')` (in `build_core.py`, built up front with the others). Heights above the head: chef and knight about +0.6 head units (tall), cap and goggles low, bow tie at the neck, bellhop small and tilted.
- **End cards:** `endCtaTech` (IoT · Apps · Networks) and `endCtaAI` (Odoo + AI · Automation · Chatbots), made by `endCtaRow([[icon, label], ...])`; use with `sub: 'IoT · Apps · Networks'` or `sub: 'Odoo + AI · Automation · Chatbots'`. The AI row is wider (about x 353-1567), so low end-card spots collide with it.
- **Icons (`L.ICON`):** chip, phone, wifi, shield, bot, bolt, bubble, bell, thermo, gear, chefhat, castle, cloche.
- **Odoo app tiles (`L.ODOO`):** iot, quality_control, maintenance, industry_fsm added.
- **Music styles:** kitchen (steel pan + swing), field (clav + funk), castle (lute + toms), butler (harpsichord + soft), machine (music box + ticking), lobby (e-piano + lo-fi). Every new tone is low-passed at 2.3-2.8 kHz to stay out of the voice band.
- **Build guard:** `build_film.py` stops on any film-level `var`/`function` name that the engine also declares (TOTAL is allowed).
- **Other tools in the renderer:** `thumbs.py` (YouTube thumbnails and 9:16 covers from `films/thumbs.js`), `vertical.py` (9:16 versions: the 16:9 episode inside a branded frame), `deliver_series.py`.

## Added in round 2 (2026-10-04)
- `flyOver(x, y, z, dur, { via, side, up, e, then })`: the standard station change. Nexi leaves over the top of the frame (fast ease-out), crosses above it, and drops in from `side` px right of the landing spot (default 200; negative = from the left). `via: [[x, y], ...]` adds waypoints before the climb (step clear of a sign). `up` is the cruise height (default -400). Pair it with a camera move delayed 0.4 s.
- `L.tween` cannot be cancelled; two tweens on one key fight. For anything that must stop on cue (a run indicator that pauses), compute its value from a start time and a pause time each frame instead.
- Measuring text: `L.tw(gg, text, size, weight, font)` returns the width; for a chip, width = text width + 1.3 × font size (+ 1.15 × font size with an icon). `KIT.chip` also returns the width it drew.
- Audit hooks: `engine_tail.js` calls `AUDIT.mark(layer)` around each layer and `AUDIT.setMeta(...)` with the camera, end-card, quiz and Nexi state when `window.AUDIT.on`.

## Added in strict mode (2026-10-04)
- **`introSeq({ nx, ny })`:** after the lock-up, the intro dives Nexi to (1712, 930), then `goTo(nx, ny)` 0.55 s later, in the FIRST scene's world coordinates, while that scene fades in. Choose a spot whose climb crosses no label (lint N7 requires it).
- **`outroSeq({ nexi })`:** always pass the spot (lint E1). The default `right` was shared by four topic videos.
- **`toss(o, x, y, dur, { h })`:** `h` is the arc height in world px. Across a board use about 80 and shrink the prop in flight (`o.s = 0.6`); a high arc loops over titles (lint warn M6).
- **Audit meta:** `engine_tail.js` hands the audit the camera, end-card, quiz and Nexi state, plus `win` (patch p30): the 3D Odoo window's box in world px when it is up. `layout_audit.py` counts it in the composition.
- **Fingerprint:** `gate.fingerprint(film)` hashes the bundle, the runtime scripts, `film.html` and the assets list. Audits (`qa/audit/<film>/meta.json`) and renders (`out/<NAME>.build.json`) carry it, so the gate can prove that what was audited is what was rendered and delivered.

## Added for ERP 4 Odoo Customization (2026-10-04)
- **Costume `beanie`:** an orange knit beanie with a cream cuff and a pom-pom (patch p31 in `build_core.py`, built up front). A low hat; the pom-pom adds about +0.45 head units.
- **Music style `alpine`:** marimba + swing, 114 bpm (`audio_t.STYLES`), MAIN `custom`.
- **Film-local icons:** a film may add `L.ICON.<name> = function (gg, x, y, s, col) {…}` before `introSeq` for its pills and badges (custom adds `peak` and `flag`), without touching the engine or other films' fingerprints.
- **Local-layout scenes:** author each station in screen coordinates and translate by `(CX − 960, GY − 790)` with the camera at `(CX, GY − 250, 1)` (see `films/custom.js`).
- **Far parallax:** `gg.setTransform(1,0,0,1,0,0); camApply(gg, par)` inside a back prop draws a far layer (par < 1).

# Rulebook (strict)

Every rule here is a MUST. A video that breaks one is not finished, however close the deadline.

**How the rules are enforced.** The **Check** after each rule says how it is caught:
- `lint:X` — `lint.py` runs inside `build_film.py`. An error means the film does not build.
- `audit:rule` — a `layout_audit.py` finding. The release gate fails on any HIGH finding, any medium finding parked for 1.5 s or more, and any resting group off-centre for 3 s or more.
- `gate:X` — `gate.py`. `render.py mp4` refuses to render and `deliver.py copy` refuses to copy until it passes.
- `look` — a manual check on the strip, the 12-frame sheet or the full-resolution CTA frame. No checker can see it, so you must.

**The training loop.** When a defect reaches the user:
1. Add the rule that would have caught it.
2. Extend `lint.py`, `layout_audit.py` or `gate.py` so it is caught automatically next time.
3. Log both in `lessons.md`.

A rule that was broken twice MUST become automated.

**No bypass.**
- Never loosen a threshold or a checker to make a film pass. Change a checker only to fix a proven false positive, and log the evidence in `lessons.md`.
- An exception is a waiver in `qa/waivers/<film>.json`, with a reason. Only intended effects qualify: chapter bands sliding in, a deliberately messy pile, a slider wipe. "No time" never qualifies.
- Every waiver used is told to the user in the delivery message.
- Truth and brand rules cannot be waived.

---

## C · Content and truth
| ID | Rule | Check |
|---|---|---|
| C1 | **No Malaysia anywhere:** no office, market, sample company, country code (MY), currency (MYR/RM) or route. TechNext is Singapore HQ, with teams in the Philippines (Taguig: Odoo development and consulting) and Vietnam (Ho Chi Minh City: AI engineering), delivering in 10+ countries. *(user 2026-10-03: "we dont have malaysia")* | `lint:C1` (no waiver) |
| C2 | **Facts come from the live site repo** (`~/ClaudeWork/TechNext-Website`, `origin/master`): each solution page states what TechNext offers. Never invent claims, prices, client names, offices, certifications or results. | look + facts |
| C3 | **Every sample company, figure or format is fictional and labelled** "sample" or "illustrative" on screen. Fictional names: Bluebay Trading, Lintel & Co., Manila Trading, Kopi Co., Lotus Mart… | `lint:C3` + look |
| C4 | **No cyber-security services, in any wording** (user rule). | `lint:C4` (no waiver) |
| C5 | **A group or multi-company demo is a labelled sample group**, never TechNext's own group. TechNext's real crew is shown separately, with true facts. *(user 2026-10-03: "explain technext and do also sample company")* | look |
| C6 | **A copy of a sample record out in the analogy world** (a slip on a scale, cards in a chest, a sign, a billboard) **carries its own "Sample" label**: the Odoo window's "Sample data" chip covers only the window. (QT15-24 2026-10-04) | `lint:C3` + look |

## B · Brand
| ID | Rule | Check |
|---|---|---|
| B1 | **The plain Odoo logo only.** Never "Odoo Ready Partner" or any partner-tier badge. | `lint:B1` (no waiver) |
| B2 | **The intro and end-card logo is centred.** "with Nexi" sits in the right slot as in the walkthrough; the video's badge sits in the left slot. | look |
| B3 | **The end card matches the series:** the Odoo card for Odoo and ERP videos; `endCtaMkt` (Websites · Social · Brand, no Odoo logo) for Marketing; `endCtaTech` for Technology; `endCtaAI` for AI. | look |
| B4 | **Type and colour:** Plus Jakarta Sans 800 for display; Inter 600–700 for body; Caveat only for the intro subtitle and deliberately messy samples. Ink `#1F1F3D`, body `#4C4C63`, TechNext blue `#3167CA`. | look |
| B5 | **One costume per video, worn through the outro.** It fits the analogy. The one exception is the series pilot (EP00), a costume showcase the owner asked for ("do alot of costume"): one costume per scene, and the last one is worn through the outro. | look |

## F · Frame and composition (1920×1080 screen px)
| ID | Rule | Check |
|---|---|---|
| F1 | **Safe areas.** Nothing important under the HUD (x < 260, y < 140). Nothing the viewer must see behind the caption band: 1180 px wide, bottom-centred, its top at about y 880 for one line, 835 for two, 720 for three. | `audit:covered`, `audit:nexi-text` |
| F2 | **One centred group per resting frame.** Nexi and the cards are framed together, centred within 160 px of x 960, spanning about 1500 px at most. Compute it from the screen (framing math below). *(user: "not properly centered")* | `audit:offcentre` (≥ 3 s fails) + look |
| F3 | **Nothing in a corner and nothing hugging an edge.** Subjects stay 120 px or more from the left and right edges. Nexi's resting centre is x 300–1620 and y 300–600 (360–600 with a tall hat). *(user: "too much in the corner")* | `audit:nexi-edge` |
| F4 | **Nothing is cut by the frame while the camera holds:** cards, signs, cranes, boards, phones. | `audit:cut` + look |
| F5 | **No empty frames.** A frame with only Nexi and the backdrop is a defect. The next scene's frame is up when the camera lands. | look (strip) |
| F6 | **No leftovers from a previous scene** peek in at the edges. | look |
| F7 | **Vertical balance.** The content block sits between the HUD (y ≈ 140) and the caption top. Lower a top-heavy scene. | look |
| F8 | **60 px or more** between Nexi's silhouette and the nearest card. | `audit:nexi-text` + look |
| F9 | **A station's whole set is on screen when the camera lands.** Revealing cards one by one leaves the group left-heavy for 3 s or more. Each line highlights its own card (a glow, or a scroll unrolling), it does not add it. | `audit:offcentre` |
| F10 | **Frames on landing, content during the line (F9 + M12).** The screens, panels and cards stand when the camera lands; what is ON them builds while Nexi explains it. A scene that opens before any label exists (a city waking up) carries a narration box ("MEANWHILE, IN THE CITY") that anchors the composition until the scene's own labels arrive. | `audit:offcentre` + look |

**Framing math (do it for every scene):**
- `worldX = camX + (screenX − 960) / zoom` and `worldY = camY + (screenY − 540) / zoom`.
- Nexi's silhouette around `N.botPx()` (world px, depth 1): x −160..+160 (±200 with arms); y −230..+210 (top −310 with a tall hat or a reaction lift).
- The group: take the world extents of Nexi and every card, set the camera x to the group's centre, and set the zoom so the group spans about 1500 px or less.
- Typical layout: Nexi at screen x 340–470, cards from 600–650 to 1650–1700.

## T · Text
| ID | Rule | Check |
|---|---|---|
| T1 | **Minimum on-screen size** (world size × zoom): headings 34 px, key information 22 px, labels 18 px (17.5 measured). Tiny text only when it is pure decoration. *(user: "small and hard to read")* | `audit:small` |
| T2 | **Text fits its box with 24 px or more of padding** (8 px is the absolute floor). Size every box from measured text (`L.tw`, `chipW`, the width `KIT.chip` returns), never a hard-coded width. | `audit:overflow`, `audit:tight`, `audit:touch` |
| T3 | **No text on text, no line through text.** Draw connectors before labels; give each label its own segment (bus routing). *(user: "text overlapping")* | `audit:overlap`, `audit:line` |
| T4 | **No partial covers.** A card covers a whole prop or label, or stays clear of it. | `audit:covered`, `audit:cards` |
| T5 | **No caption starts with "..." or "…".** The voice pauses on the dots. | `lint:T5` |
| T6 | **Captions are 2 lines (≤ 86 characters) by default.** 3 lines (≤ 130) only when nothing important sits below y 720 during that line; never 4. | `lint:T6` |
| T7 | **Labels sit on contrast.** Never text directly on a coloured or textured prop (weave, wood, stripes); use a chip or plate. | look |
| T8 | **An inline tag goes after the measured title**, at `titleX + titleW + 24 + chipW/2`. | `audit:overlap` |
| T9 | **A label is centred on the thing it names and true for it.** | look |
| T13 | **A speech balloon's tail joins at the balloon's very edge and its text keeps >= 28 px padding** (a tail patch ran into "TAGS!"). | `audit:covered` |
| T14 | **A speech balloon never sits on a sign or card.** The audit reads the balloon's text inside the sign's box as text overflowing it (`audit:overflow` HIGH). Move the sign or lift the balloon, and keep its tail off the sign too. (S2 EP00) | `audit:overflow`, `audit:touch` |
| T11 | **Comic lettering is drawn once.** The outline and the fill sit at the same position, and the drop is the outline's canvas shadow (a second word 5–8 px lower reads as "X overlaps X"). Its burst is sized from the measured word: inner ellipse rx = 1.45 × half the width, ry = 1.5 × half the height, so the star's edges never cross the word (`wordBurst` in films/pilot.js). | `audit:overlap`, `audit:line` |
| T12 | **A sprite word is not measured.** Comic SFX words drawn from an offscreen canvas (`sfxWord`/`drawSfx`) are invisible to the audit, so place them in a free band, never over a card, a caption or Nexi's face, and check every one on the strip. | look (strip) |
| T10 | **Quiz text fits its band.** The wide band is 1180 px. Shorten any answer over about 28 characters; never let answers overflow. In the ONE-ROW band the answers start at x + 560, so the 32 px question must stay under about 26 characters. | `audit:overflow` + look |

## N · Nexi
| ID | Rule | Check |
|---|---|---|
| N1 | **Nexi is never behind a card, quiz, caption or front-layer prop**, and never in front of text being read. | `audit:nexi-text` |
| N2 | **Flights never cross reading text.** Every scene change is a `flyOver` (up and over the frame top). `via` waypoints step her clear of a sign first. Check mid-flight frames: the spring cuts corners. | `audit:nexi-text` + look |
| N3 | **She roams.** Every beat moves her somewhere meaningful (fly, hop, ride, carry), and she faces the viewer when she speaks. Reactions are big: speed lines, shake, emotes. A free band of sky above a row of cards is a good home: she supervises from there, her base 10 px or more above the cards. | look |
| N4 | **Riding:** her lowest point sits on the roof line and the vehicle never draws over her. If the ride passes signs, she waves from above instead. | look |
| N5 | **Near the top of the frame or under a top quiz band, use the small cheer and no emote glyphs** (no `RX.hmm` '?', no `RX.shock` '!'; `shockJump`/`RX.shock` also lift her: use `peer` + `E.shock`; lint warns, p38). `bigjump` lifts her about 330 px and pushes her out of frame. | `lint` warn + `audit:nexi-edge` |
| N6 | **A hat is part of her silhouette.** Plan for tall hats (+80 px) and reaction lifts (+70–100 px) against plates and signs. `below` end spots only with low hats. | look |
| N7 | **Choose the intro exit (`introSeq` nx/ny) deliberately**, in the first scene's world coordinates, so her climb crosses no label. | `lint:N7` |
| N8 | **A held prop is gripped:** it starts at her hand (`pocket()`), its grip point (handle end or near edge) sits AT the hand (offset = the grip vector, never a free dx that leaves it floating), and it is carried at her side, never across her body or face. | look (`qa/mp4strip.py`) |
| N13 | **A held prop has an icon identity, never text** (text on it sits over her hand). While she holds a long prop she reacts with face, squash and shake, not hand-lifting clips (peer, pointL2). A tossed prop that shrinks hides its text while it flies. | `audit:nexi-text`, `audit:small`, `audit:overlap` |
| N16 | **Lint N10 binds a reaction to a line only through a cue that starts with the line variable** (`at(lN.t0 ...)`, `at(lN.w('word') ...)`). A cue like `at(Math.max(lN.w(..), ..))` or a bare `tkTap` does not count: give that line an explicit reaction at `lN.t0`. (QT15-24 2026-10-04) | `lint:N10` |
| N17 | **Charge and release tweens never overlap.** `L.tween` does not cancel a running tween on the same key: a delayed charge tween (`{ ch: 1 }, 0.9, ease, 0.15`) that is still running when the release tweens `ch` to 0 wins at its end, and the energy ball stays stuck on her for the rest of the scene (S2 EP00 tow). Keep the charge tween short enough to end before the release word, delay the release's `ch: 0`, and hard-reset (`RD.ch = 0`) when the beam switches off. | look (strip after every beam) |
| N18 | **A prop action is animated as the real action** (the N12 standard for every verb, not only beams). *(owner 2026-10-05: "do proper watering on the plants.")* Watering: she carries the can to the pot, the can TILTS to pour, a continuous stream arcs from the spout into the soil, splash drops and darkening soil at the pot, the can levels, then the plant grows. A hand-held prop never just floats near the target while particles fall. | look (strip at every action) |
| N15 | **Anything she wears hangs from her NECK, which is `N.botPx()`** (where the bow tie sits); never from a point lerped toward `N.headPx()`, which lands on her visor (EP22's lanyard ran down across her face). An item she uses (a badge at a kiosk) is the one she wears: no second copy appears. *(user: "fix the id nexi's wearing")* | look (close-up crop of the MP4) |
| N9 | **Floating decorations stay off Nexi and off text being read:** bubbles, hearts, stats, sparks. Fade them inside her `N.botPx()` box (±215 px wide, −340..+240 px tall). | `audit:nexi-text`, `audit:covered` |
| N10 | **Nexi reacts on every line, and every reaction is exaggerated.** *(user: "make sure there's a exaggeration effect in every reaction. make nexi reactive.")* Use `react(kind)` (films/pilot.js): a pose clip + a face + a glyph (bang, question-bang, heart, star, sweat, vein, note) + manga focus lines + a squash, and a comic SFX word on the big beats. A bare `N.play` with no accent is not a reaction. | `lint:N10` (warn: lines with no reaction; more than half the lines without an accent) + look |
| N11 | **The scene is connected to Nexi.** *(user: "make it interactive and connected to nexi")* What happens on screen happens because of her: the beam leaves her hand, the robot assembles around her, she holds the mic, she flies the cockpit, she rides the plane, the screen lights when she points. A set that plays by itself while she stands beside it is a slide, not a scene. | look (strip) |
| N12 | **An attack is animated as an action, not a pointing pose.** *(user: "when nexi shooting beams, make sure nexi are shooting properly animation", "the robot should attack and punch the enemy ... combo attack", "the superpower orb should orbiting around properly")* A charge (a pose held with `N.extra`, an energy ball, light sucked in), then the release (a thrust, a muzzle flash at the hands, a recoil, an impact at the target). Hits land with a reaction on the receiver (flinch, knockback). Things that orbit her pass behind her (a back prop) and in front of her (a front prop), with depth scaling. Attach `N.extra` only while the pose is needed: engine helpers clear it. | look (strip) |
| N14 | **A beam never arcs over a label.** `tkBeam` rises 80 px above the higher end: from beside a window it crosses the navbar. Aim at a free edge next to the target (never its label, M7), or let the person click with their own cursor; Nexi beams to props beside her. | `audit:line` |

## M · Motion and camera
| ID | Rule | Check |
|---|---|---|
| M1 | **Transition grammar** for every scene change: `flyOver` at t0 (t0 = the new line's start, never in the hold before it: whooshes in the gaps sink the voice ratio); the camera at t0 + 0.4 s (0.55–0.65 s for a long whip from a left spot); for a whip between stations (>= 2000 px apart) the old scene stays until the camera has landed (fade at t0 + 1.7 s; it is off-frame by then), so the whip never shows a blank frame; a same-station swap fades the old scene from t0 + 0.5 s; the new scene appears from t0 + 0.45 s; the CTA pops at about t0 + 0.7 s. | look (strip) |
| M2 | **The camera holds still while text is read** and moves between beats, using the grammar: establishing wide, push-in on a detail, whip pan to the next station, track a moving subject, crane up for builds, pull back for reveals, dutch tilt for comedy. Zoom stays 0.7–1.4; below 0.75, scale world text up. | look |
| M3 | **Story props are where the camera is** when their line plays. | look |
| M4 | **Props that fly away leave the frame entirely.** They never park over a card. | `audit:covered` |
| M5 | **A card pops after Nexi is clear of it**, never into her path. | `audit:nexi-text` |
| M6 | **Props tossed across a board fly a low arc** (h about 80) and are small in flight (s about 0.6). | `lint` warn |
| M10 | **Never toss a prop across a card's text.** A field or chip that joins a document fills its slot in place (tap, sparks). | `audit:covered`, `audit:overlap` |
| M11 | **`flyOver` cruises above the frame.** `up` is an absolute world y: in a world that climbs, pass `up` = the higher frame top − 250 and `via` straight up from her spot first. | `audit:nexi-text` + look |
| M13 | **A station painter is drawn whenever any of its clipped rect can be in frame:** `near(k)` covers at least +-(clip half-width + 960/zoom), i.e. +-2500 for the usual CX +-1500 clip. With +-1700 a whip shows a pale band of the default set at the frame edge for ~0.2 s (QT05, QT07, QT11, QT12 first renders). | look (`qa/mp4strip.py` across every whip); lint automation pending |
| M14 | **A page turn (or any sheet that folds over content) shows ONE page's text at a time.** The audit sees every text that is drawn, not the clipping, so a base page under a turning sheet still overlaps the sheet's text (22 HIGH on the first EP22 audit). Draw a base page's contents only while the sheet does not cover it, and the sheet's own contents only once it is open past a quarter (`kx >= 0.25`). | `audit:overlap`, `audit:covered` |
| M15 | **Text must not be under a full-screen flash or under her flight.** Before a dive or a white cut, fade the scene's text out (`PB.txt`), and bring the next scene's text in only after the flash has faded (tween its set from flash + 0.4 s). | `audit:covered`, `audit:nexi-text` |
| M7 | **A moving pointer** (Clicky, a cursor, a beam) never covers the label of the button it presses; aim at the button's edge. | `audit:covered` |
| M12 | **Story pacing gives the viewer time to absorb.** *(user: "do proper cinematic style of story telling. you can slow down explaining things and give time to viewers to absorb information thru animation.")* One idea per line; `hold` 0.3–0.5 s after a line; a build animates WHILE its line is spoken (it is not finished before the voice gets there); an establishing beat (a narration box, a wide shot) before the explanation starts. The v2 pilot: 46 lines in 3:29, about 4.5 s per line. | look (strip) |
| M16 | **Clear a station once the camera has left it.** `outroSeq` whips the camera home across every station, so finished cards, people and props flash by mid-pan (F6). Set their alpha to 0 after the whip away (about t0 + 1.8 s); painters (backgrounds) may stay. | look (`qa/mp4strip.py` across the outro) |
| M17 | **Anything at the top of a station fades at the station-change line's t0**, not with the delayed (1.7 s) clear: `flyOver` cruises above the frame, so a poster, a title chip or a map card at the top is crossed by her on the way out (`audit:nexi-text`). The same for a banner or takeaway at the NEW station: pop it only after she lands (delay >= 1.5 s). (S2 EP00) | `audit:nexi-text` |

## P · Props, cards and samples
| ID | Rule | Check |
|---|---|---|
| P1 | **Card style:** white, a soft blue shadow, a 3–4 px `rgba(111,160,245,.45)` edge, radius 18–34. No more than five lines of text per card. | look |
| P2 | **Samples look like real, attractive designs at a readable size.** A phone is about 1:2, fully in frame, with phone-scale type. Proven sizes: card 340×200, slide 420×236, post 300×375, roll-up 210×420, signature 440×150, viewed at zoom 0.82 or more. *(user: "design should be visually appealing and eye catching, even the sample format")* | look |
| P3 | **Stacks the viewer reads sit in the back layer**; switch a prop to the front when Nexi grabs it. | look |
| P4 | **Empty fields look empty on purpose:** dashed border plus an "Empty" placeholder. | look |
| P5 | **Stands and posts end on a base above the caption band.** | `audit:covered` |
| P6 | **A card read while the world is busy goes in the `screen` layer**, over empty sky. | look |
| P7 | **Content is centred inside its container**; animate the shift when content grows. | look |
| P8 | **Draw order:** a fill that shapes a header (a square fill under a rounded header) is drawn before the header's text, never after it. | `audit:overflow`, `audit:covered` |
| P10 | **Objects keep their identity:** a crate, card or tag keeps its colour, label and size when it lands, moves or changes state (no repaint by slot or row). | look (`qa/mp4strip.py`) |
| P11 | **A big prop the story relies on carries a readable label** (the monster's name box, "CRM Express" on the loco). The composition check sees only text and cards, so an unlabelled monster leaves the group measured off-centre. | `audit:offcentre` |
| P12 | **Drawn (comic, anime) art is cel-shaded, never flat clip art** (EP00 intro / comic-style films only: Quick Tips keep the QT05-14 look, rule P16). *(user: "fix some comic style of design, it's ugly")* A base tone + one shadow tone + a rim highlight (`cel()`, `shine()`); one ink outline width per scene (4–6 px); backgrounds in layers (sky, far, mid, near) with a limited palette per scene; shapes with weight (folds, bevels, sticky-note spikes, rolled paper), not single rectangles. Decorative art is Path2D or a cached sprite, so the audit measures only the text. | look (strip, full-res frames) |
| P13 | **Sets are bright; only a night scene is dark.** *(user: "dont use too much dark color other than night view")* Daytime gradients, white and pastel surfaces, light glass instead of navy panels. When a set turns light, recolour everything that was white-on-dark (text, arrows, icons, rings) to ink or brand blue. | look (strip) |
| P16 | **Quick Tips (QT05+) keep the QT05-14 style** *(owner 2026-10-04: "the comical style are for intro. continue similar to the style of previous quick tips videos.")*: a creative world per tip with painted backgrounds, a costume, a recurring charming character, the engine's RX/N.play reactions, a quiz and a recap. No comic-book narration boxes, sound-word bursts, cel-shading or manga glyph kits in tips. They **show the real Odoo 17 click path on the 2D tip kit** (`films/inc/tipkit.js`, `/*@include tipkit*/`): a big world-prop Odoo screen the audit can read (body 21-23 px, never the 3D window, whose text the audit cannot see), drawn in WORLD coordinates so the tap spots are world rects; Nexi taps with `tkTap(key, fn, { side: 'L' })` (edge, M7). Every step on screen is true to the Odoo 17 docs; product names fit their column (measure them: "Standing Desk" clipped to "Standing Desl" in the first QT05 render). Each tip is a creative world (theatre, magic show, cooking show...), 3 stations, a costume, a recurring charming element, one pause-and-guess quiz. | `audit` + look |
| P20 | **Grey out an option with a grey colour at full opacity, never with alpha < 1**: the audit stops treating a translucent chip as its text's box (three HIGH overflow/cut findings in QT18). The same for dimmed answers in a quiz-like set piece. (QT15-24 2026-10-04) | `audit:overflow`, `audit:cut` |
| P17 | **A recap shows the real episodes:** their delivered YouTube thumbnails as images (polaroids), copied small into `web/finale/`, outside `web/assets` (K10). Each one is labelled in text (`EP05 · Implementation`), and the line highlights each as it is named. | look |
| P14 | **A dropdown or dialog over list text** opens >= 12 px below the control panel, repeat openings stay under 1.5 s, and what is underneath dims to alpha < 0.5 once the menu is opaque (Odoo's modal backdrop). Only a viewer-paced first opening may be waived. | `audit:cards`, `audit:covered` |
| P15 | **A radial glow fills a square of side 2R** centred on its gradient; a smaller rect leaves a hard light edge the audit cannot see. | look (full-res frame) |
| P9 | **A cut-out (a bite, notch or hole) is ONE union outline**, traced through the circles' intersection points. Separate overlapping arcs under `evenodd` flip back in, and each subpath needs its own `moveTo`. | `lint` warn + look (CTA frame) |
| P18 | **People are the season's cast, drawn by the kit** (Season 2: `inc/s2kit.js`; never a one-off person). Acting is event-sourced (`s2Pose/s2Mood/s2Talk/s2Walk/...`), so a person acts on every line they are in; the ID card is their label (P11), its text stays >= 17.5 px (`A.s * zoom >= 0.9`, else `id: false`), and no pose's hands or a card cross it. A person and Nexi are framed as one group (F2): a person at screen x 380-460, Nexi at 760-820, a card from ~1000. | `audit:small`, `audit:offcentre` + look |
| P19 | **tipkit screens are shown at zoom >= 1.** Its URL bar and "Sample data" chip are 18 px, so below zoom 0.98 the whole station parks a "small" finding. | `audit:small` |
| P21 | **Dark ink outlines belong to characters and element cards only, never to the background.** *(owner 2026-10-05: "the only model have darker highlight are the persons/character and some elements card, do not include the background. we do have format on background for not using too much black shade.")* The cast, Nexi, mascots (Spike), UI cards and the prop being used may carry the navy `S2INK` line; scenery (roads, trees, hills, fences, pots, shelves, gym kit, sign posts, potted plants, wall frames) gets `cel(..., 0)` plus at most a stroke in its own darker tint. `cel` and `s2Plant` default to the ink line: draw scenery with a soft helper. Extends P13. | look (strip) |
| P22 | **A text card is designed, not a text dump.** *(owner 2026-10-05, the S2 EP00 content note: "fix this 1st image part. arrange and design properly.")* Group the copy into sections, each with its own icon or chip, a clear hierarchy (title, body, the emphasis line, the footnote chip), and a balanced block that fills the card; never left-aligned lines in the left half with an empty right half. | look (the full-res frame) |
| P23 | **Overview scenes are over the top and played by Nexi.** *(owner 2026-10-05, the S2 season map: "fix the design. make it interactive and properly design. dont settle in this kind of presentation. make it over the top.")* A season map, roadmap or list of arcs is never a static grid of cards: Nexi travels it (rides, flies, drives), each stop is a themed landmark that pops big with effects as she arrives, the camera follows, and the labels stay readable (T1). | look (strip) |

## Q · Viewer quiz
| ID | Rule | Check |
|---|---|---|
| Q1 | **Exactly one quiz per solution video:** 3 s countdown, reveal, cheer. | `lint:Q1` |
| Q2 | **The subject of the question stays visible** (use the wide band at top or bottom, or the empty side). Nexi stands beside the quiz, never behind it. | `audit:covered`, `audit:nexi-text` |

## E · End card
| ID | Rule | Check |
|---|---|---|
| E1 | **Nexi's end spot is explicit and different per video.** Spots: `top`, `left`, `right`, `below`, `leftlow`, `rightlow`. No two videos in a series group share one, and neighbouring episodes differ. *(user: "make sure nexi will change location every video")* | `lint:E1`, `gate:G6` |
| E2 | **The spot suits the hat.** `below` only with low hats; tall hats use left, right, leftlow or rightlow. Low spots stay outside the link row (the AI row spans about x 353–1567). | look |

## A · Audio
| ID | Rule | Check |
|---|---|---|
| A1 | **Loudness −18.0 to −16.5 LUFS** (target −17). | `gate:A1` |
| A2 | **True peak −2.0 dBFS or lower.** Every film has a `render.LIMIT` entry (0.68–0.7). A miss is usually one sharp effect: find it with `qa/_peaks.py`. | `gate:A2`, `gate:G3` |
| A3 | **Voice ratio 3.5× or more.** | `gate:A3` |
| A4 | **Music sits 9.5–13.5 dB under the voice, and 4–7 dB under it in the gaps.** One upbeat style per topic, low-passed out of the 2–4 kHz voice band. *(user: "upbeat, not loud")* | `gate:A4`, `gate:A5` |
| A5 | **No effect drowns a word.** Long noise effects go between lines. | listen |
| A7 | **Tune the music level right after the first render** with `qa/music_tune.py` (the gate's own A4/A5 formula). Styles differ a lot: city .31, space .43, garden .432. | `gate:A4-A5` |
| A6 | **The voice is the website voice** (technext.asia/nexi): `audio_t.voice_bus` = the site chain (chirp + soft blips, master .26, Web Audio compressor); music low-passed 2.6 kHz, effects 5 kHz, master compressor. Never boost the blips again. Effects that pack the gaps are lowered per film (`FX_FILM`), not waived. | `gate:A1-A5` + `qa/audio_try.py` |

## G · Pipeline gates (`gate.py`)
| ID | Gate |
|---|---|
| G1 | The bundle is newer than the film script and the engine sources. |
| G2 | Lint is clean. |
| G3 | The film is registered: `render.NAMES`, `render.LIMIT`, `deliver.SRC` and `deliver.DST`, `audio_t.MAIN`. |
| G4 | A measured audit (step ≤ 5) was recorded from THIS build and analysed after it was recorded. `render.py audit` deletes the old report, so a stale one can never be read. |
| G5 | Zero HIGH findings, zero parked medium findings (≥ 1.5 s), and zero off-centre resting groups (≥ 3 s), unless waived. |
| G6 | The end spot is unique within its series group. |
| G7 | The MP4 was rendered from THIS build (`out/<name>.build.json`) and is complete. |
| G11 | **The renderer is shared by parallel sessions.** The fingerprint hashes every file in `web/assets`, so another chat adding assets mid-render fails G4 + G7 for EVERY film. Before a render, check that nothing in `web/assets` changed in the last few minutes (`find web/assets -newermt '-10 minutes'`). On a mismatch, re-audit and re-render; never `--adopt` (it is only for MP4s made before stamps existed). Our own `qa/tf_extract.py` and `qa/tf_crop.py` write `web/assets/thumbframes/`, so run them only after `deliver.py copy`, and tell any busy peer session. |
| G8 | **Season 2 Quick Tips (15+) live in folder 26** *(owner QT15-24 2026-10-04: "the new quick tips will cover the season 2", "all season 2 quick tips folder will be moved in ... 26. Nexi Explains - Season 2")*: they keep their numbers (`Quick Tip 15 - ...`), `deliver.S2_TIPS` sends their DST to `26. Nexi Explains - Season 2/<base>/`, the intro badge reads `S2 · TIP #N` and the hud `S2 · Quick Tip #N`, thumbnails carry `QUICK TIP · S2` + a SEASON 2 pill (`CFG.season`). Package with `deliver_series.py --dest "26. Nexi Explains - Season 2" --no-top --only ...`; the S2 plan's "Season 2 Quick Tips" section belongs to the Quick Tips work (`qa/s2_plan_tips.py`). | `deliver.S2_TIPS`, `deliver_series.py` |
| G13 | **A packager never touches a post it does not package.** `deliver_series.py` moves stale files only inside the folders of the posts it packages, and a full run packages only the posts whose 16:9 master lives in folder 22 (p58). Port sandbox posts into the main registry the same day: an unregistered post folder was once "superseded" by another session's full run (QT15-18 moved to `22/_superseded 2026-10-04 2302`). | `deliver_series.py` |
| G14 | **A packager never rolls back a newer delivery.** Another session can re-deliver a post from its own build; an md5-only copy from a stale `out/` puts the old file back. `deliver_s2.py put()` keeps a Drive file newer than its local source and says so; sync `out/` from Drive first. (S2 EP04, 2026-10-05) | `deliver_s2.py` (KEPT) |
| G15 | **A Season 2 video is at most 2:58 (178 s) in total, intro and outro included.** *(owner 2026-10-05: "maximum video content should 2 mins and 58 sec, properly reduce.")* Trim by tightening lines and holds, never by cutting the content note, the quiz or the CTA. | `gate.py` G15 (pre-gate, group S2) |
| A1–A5 | Audio as above. |
| G10 | **Names:** every post is `EPnn - <title>` in posting order (`deliver.EPISODES`); Quick Tips are their own series `Quick Tip nn - <tip>` (`deliver.TIPS`, never episodes); the series group is `deliver.GROUP`. The 16:9 file lives in the post's own folder: `<base>/<base> (16x9).mp4` (`deliver.DST`, p52). Audio-only refreshes of an already-delivered picture go through `deliver.py audio` (video stream bit-identical, A1-A5). |
| G9 | `deliver.py sheet` made the 12-frame sheet and the full-resolution CTA frame from this MP4, and you LOOKED at both. |
| G12 | **The gate lints exactly what the build lints:** `lint.lint()` expands `/*@include x*/` like `build_film.py` (p58). A film whose labels come from a kit passes C3 in both or neither. |

## H · Thumbnails, covers and packaging (`thumbs.js`, `thumbs.py`, `vertical.py`, `deliver_series.py`)
*(owner 2026-10-04: "redesign the thumbnail, still use technext branding. but make it over exaggerated … darker shade of blue … still connected to the video content with elements … add number of episode"; "make sure the thumbnails and short video also in one folder")*
| ID | Rule | Check |
|---|---|---|
| H1 | **One series look:** every EPISODE thumbnail and cover sits on the same deep TechNext blue (`TNBG`; Before vs After keeps a slate "before" half), with the cyan glow behind Nexi, the cyan rim glow, and the giant ghost number. Never a per-episode rainbow background on an episode. **Quick Tips are their own series with their own dynamic look** (owner 2026-10-04: "update all quick tips thumbnail both 16:9 and 9:16 to more dynamic color and design"): `films/inc/qtthumbs.js`, one bold two-tone palette per tip (`QT[id].pal`), diagonal energy bands, sunburst, halftone, confetti kept off the badge and hook, a white rim glow, the ghost number, and one big drawn prop from the tip's story. Same badge, hook and Nexi positions as the episodes. | look at the contact sheets |
| H2 | **Connected to the video:** Nexi wears the episode's costume and at least one element comes from the episode itself: drawn props from its story, or a scene card cut from its own key frame (`assets/thumbframes/<id>.jpg`). The crop never shows a second Nexi. | look |
| H3 | **The number is the hero:** the branded badge (TechNext logo strip, NEXI EXPLAINS / QUICK TIP strip, EP nn / TIP nn up to 214 px via `fitSize`). The number comes from `deliver.EPISODES` through the URL (`&ep=&qt=`); never hard-code it. | thumbs.py |
| H4 | **The hook is two lines** (white, then the yellow punch), at most about 10 characters on line 2 so it stays ≥ 190 px. Props and pills stay off both lines; nothing important sits in the bottom-right corner (YouTube's duration stamp). A Quick Tip on a yellow or orange palette uses a white or green punch (`QT[id].punch`) so the punch never blends into the background. Quick Tip hooks are 840 px wide so Nexi's pointing hand never touches line 1. On the 9:16 Quick Tip cover the prop sits between the hook and Nexi (centre y 1050, scale 0.8), Nexi at zoom 1.85, so a tall hat never covers the prop. | look |
| H5 | **Layering:** the scene card draws in FRONT of Nexi (a raised hand reads as holding the screen); pills sit on the card's bottom-right corner, short (≤ 12 characters). Covers: the badge has no format tag; Nexi's face stays inside the 3:4 grid crop (y 240–1680). Vertical-video frame: the badge ends ≥ 20 px above the hook. | look |
| H6 | **One folder per post** in folder 22 (`<base>/<base> (16x9).mp4`, `(9x16).mp4`, `- YouTube thumbnail.jpg`, `- cover (9x16).jpg`), filled only by `deliver_series.py` (md5 on every copy, stale files moved to `_superseded <time>`, never deleted). | deliver_series.py |
| H7 | **On the 9:16 cover the hook clears the EP badge by 30 px or more.** The cover reuses the 16:9 hook sizes, and line 1 sits at `y - s2 * 0.98` above line 2, so a big hook (s2 > about 230) rises into the badge. Give that post a `vtitle` with smaller sizes (`genericV` reads `c.vtitle || c.title`). | look (`contact-sheet-9x16.jpg`, the top of every cover) |
| H8 | **Channel art** (YouTube banner 2560x1440, Facebook cover 1640x924, profile 1080 circle): built with `channel/channel.py`, in the series look (H1). Key content sits inside the safe areas: YouTube phone box x 507-2053, y 508-931; Facebook desktop band y 150-774 with no text in the bottom-left (profile picture; keep text above y 640). Episode cards are the real delivered thumbnails. Assets live in `web/channel-art/`, NEVER under `web/assets` (gate fingerprint, G11). | `channel.py --guide`, `preview.py`, look |
| H9 | **Season 2 thumbnails: exaggerated, dynamic and never templated.** *(owner 2026-10-05: "make more the thumbnail overly exagerated design, reaction and super dynamic elements design" + "make sure the season 2 thumbnail are not templated with each other specially background. play more on position of characters in the thumbnail. each thumbnail should be unique with each other background design. follow the format color for episode similar to season 1." + "dont change the season 1 ... dont create yet a thumbnail")* (1) **Colour format = Season 1 episodes:** the deep TechNext blue (`TNBG`), cyan glow, ghost number, branded badge, white + yellow hook. (2) **Every S2 thumbnail has its OWN background design** built from its story (a scene, pattern or shape language: a cracked office window, a tilted scale silhouette, a phone-screen grid, a spotlight on a button, a CCTV scan grid), never the same burst + wedges layout on two posts. (3) **Character placement changes per post:** left, right, centre, foreground close-up, peeking from an edge, different scale and tilt; Nexi moves too (not always big on the right). Keep H4 (hook clear, nothing key bottom-right). (4) The exaggeration stays: big reactions, flying props with trails, impact stars, shock lines, sweat, ?!/!! marks (kit in `films/inc/s2thumbs.js`: `mBoom`, `mWedges`, `mFly`, `mShock`, `mSweat`, `mMark`, `POSE.mega/megaJoy/megaV`). (5) **Season 1 thumbnails are never changed by Season 2 work, and S2 thumbnails are made only when the owner asks.** The S2 EP00-EP04 set delivered 2026-10-05 shares one burst layout: redo it to (2)-(3) when the owner asks. | look (`s2-contact-sheet.jpg`: no two backgrounds or character layouts alike) |

## K · Code safety (engine)
| ID | Rule |
|---|---|
| K1 | Film globals never reuse engine names (the `build_film.py` guard). |
| K2 | Never tween a whole array, and initialise every field you tween (a NaN tween silently draws nothing). |
| K3 | Every `save()` has its `restore()`. Delete dead drawing code instead of half-deleting it. |
| K4 | `L.tween` cannot be cancelled. Compute anything that must stop on cue from a start and a pause time. |
| K5 | `zap()` only targets Odoo UI hotspots. A tap on a world prop is a ring plus a tap clip. |
| K6 | A new costume goes in `build_core.py buildWear()`, is built up front, and its colours go through `convertSRGBToLinear`. |
| K7 | JS and patch scripts are written with the Write tool, not Bash heredocs (heredocs break JS, and the Bash tool halves backslashes). Patches assert-and-replace. |
| K13 | **`line.w(word)` is a case-insensitive substring search:** cue on a unique phrase (`w('Alt + H')`, not `w('H')`, which matched the h in "changes"). |
| K12 | **Check the port pair before every Chrome job.** Another session's Chrome on your CDP port makes `AUDIT.end()` return a dict and render.py dies with "the JSON object must be str ... not dict". Switch to a private fallback pair (3996-3999 / 9396-9399) with a fresh profile; never kill the other process. (QT15-24 2026-10-04) |
| K11 | **Shared film code lives in `web/films/inc/<name>.js`** and is pasted in by `build_film.py` from a line `  /*@include <name>*/`; never in the engine (an engine edit changes EVERY film's fingerprint). Changing an include changes the bundle of every film that includes it, so freeze an include before parallel agents start, and rebuild + re-audit its films after any change. Films must not reuse engine names either (CH, ENV: QT05's first build was refused for `CH` and `ENV`). |
| K10 | **Anything under `web/assets` is in EVERY film's fingerprint** (name + size). Adding a thumbframe, logo or channel art invalidates every audit and render stamp: add assets only after the films in flight are delivered, or work in a sandbox copy. |
| K8 | Never call `at()` inside an `at()`/`later()`/mover callback: the event list is sorted once, so a late `at()` runs at the very end. Inside callbacks use `later(d, fn)`. Check: `lint:K8` (p37). |
| K9 | A timed build's start time defaults to `1e9` (not yet), never `-9`: `t - (-9)` is already past every step, so the screen shows finished before its line. Every formula on `t - T0` guards negative time (`Math.max(0, t - T0)`, `if (a > 0)`), including `%` cycles, which go negative. Check: look at the strip frame on the line start. |
| K14 | **Parallel agents in one renderer keep their stills apart:** `NT_SHOTS=<film> python render.py shots ...` writes `qa/<film>/f-<t>.jpg` and `NT_SHOTS=<film> python qa/_grid.py ...` reads them (p62). Never delete `qa/f-*.jpg` by pattern. |

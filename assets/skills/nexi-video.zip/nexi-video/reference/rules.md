# Rulebook (strict)

Every rule here is a MUST. A video that breaks one is not finished, however close the deadline.

**How the rules are enforced.** The **Check** after each rule says how it is caught:
- `lint:X` — `lint.py` runs inside `build_film.py`. An error means the film does not build.
- `audit:rule` — a `layout_audit.py` finding. The release gate fails on any HIGH finding, any medium finding parked for 1.5 s or more, and any resting group off-centre for 3 s or more.
- `gate:X` — `gate.py`. `render.py mp4` refuses to render and `deliver.py copy` refuses to copy until it passes.
- `look` — a manual check on the strip, the 12-frame sheet or the full-resolution CTA frame. No checker can see it, so you must.

**The training loop.** When a defect reaches the user:
1. Add the rule that would have caught it.
2. Extend `lint.py`, `layout_audit.py` or `gate.py` so it is caught automatically next time.
3. Log both in `lessons.md`.

A rule that was broken twice MUST become automated.

**No bypass.**
- Never loosen a threshold or a checker to make a film pass. Change a checker only to fix a proven false positive, and log the evidence in `lessons.md`.
- An exception is a waiver in `qa/waivers/<film>.json`, with a reason. Only intended effects qualify: chapter bands sliding in, a deliberately messy pile, a slider wipe. "No time" never qualifies.
- Every waiver used is told to the user in the delivery message.
- Truth and brand rules cannot be waived.

---

## C · Content and truth
| ID | Rule | Check |
|---|---|---|
| C1 | **No Malaysia anywhere:** no office, market, sample company, country code (MY), currency (MYR/RM) or route. TechNext is Singapore HQ, with teams in the Philippines (Taguig: Odoo development and consulting) and Vietnam (Ho Chi Minh City: AI engineering), delivering in 10+ countries. *(user 2026-10-03: "we dont have malaysia")* | `lint:C1` (no waiver) |
| C2 | **Facts come from the live site repo** (`~/ClaudeWork/TechNext-Website`, `origin/master`): each solution page states what TechNext offers. Never invent claims, prices, client names, offices, certifications or results. | look + facts |
| C3 | **Every sample company, figure or format is fictional and labelled** "sample" or "illustrative" on screen. Fictional names: Bluebay Trading, Lintel & Co., Manila Trading, Kopi Co., Lotus Mart… | `lint:C3` + look |
| C4 | **No cyber-security services, in any wording** (user rule). | `lint:C4` (no waiver) |
| C5 | **A group or multi-company demo is a labelled sample group**, never TechNext's own group. TechNext's real crew is shown separately, with true facts. *(user 2026-10-03: "explain technext and do also sample company")* | look |

## B · Brand
| ID | Rule | Check |
|---|---|---|
| B1 | **The plain Odoo logo only.** Never "Odoo Ready Partner" or any partner-tier badge. | `lint:B1` (no waiver) |
| B2 | **The intro and end-card logo is centred.** "with Nexi" sits in the right slot as in the walkthrough; the video's badge sits in the left slot. | look |
| B3 | **The end card matches the series:** the Odoo card for Odoo and ERP videos; `endCtaMkt` (Websites · Social · Brand, no Odoo logo) for Marketing; `endCtaTech` for Technology; `endCtaAI` for AI. | look |
| B4 | **Type and colour:** Plus Jakarta Sans 800 for display; Inter 600–700 for body; Caveat only for the intro subtitle and deliberately messy samples. Ink `#1F1F3D`, body `#4C4C63`, TechNext blue `#3167CA`. | look |
| B5 | **One costume per video, worn through the outro.** It fits the analogy. | look |

## F · Frame and composition (1920×1080 screen px)
| ID | Rule | Check |
|---|---|---|
| F1 | **Safe areas.** Nothing important under the HUD (x < 260, y < 140). Nothing the viewer must see behind the caption band: 1180 px wide, bottom-centred, its top at about y 880 for one line, 835 for two, 720 for three. | `audit:covered`, `audit:nexi-text` |
| F2 | **One centred group per resting frame.** Nexi and the cards are framed together, centred within 160 px of x 960, spanning about 1500 px at most. Compute it from the screen (framing math below). *(user: "not properly centered")* | `audit:offcentre` (≥ 3 s fails) + look |
| F3 | **Nothing in a corner and nothing hugging an edge.** Subjects stay 120 px or more from the left and right edges. Nexi's resting centre is x 300–1620 and y 300–600 (360–600 with a tall hat). *(user: "too much in the corner")* | `audit:nexi-edge` |
| F4 | **Nothing is cut by the frame while the camera holds:** cards, signs, cranes, boards, phones. | `audit:cut` + look |
| F5 | **No empty frames.** A frame with only Nexi and the backdrop is a defect. The next scene's frame is up when the camera lands. | look (strip) |
| F6 | **No leftovers from a previous scene** peek in at the edges. | look |
| F7 | **Vertical balance.** The content block sits between the HUD (y ≈ 140) and the caption top. Lower a top-heavy scene. | look |
| F8 | **60 px or more** between Nexi's silhouette and the nearest card. | `audit:nexi-text` + look |

**Framing math (do it for every scene):**
- `worldX = camX + (screenX − 960) / zoom` and `worldY = camY + (screenY − 540) / zoom`.
- Nexi's silhouette around `N.botPx()` (world px, depth 1): x −160..+160 (±200 with arms); y −230..+210 (top −310 with a tall hat or a reaction lift).
- The group: take the world extents of Nexi and every card, set the camera x to the group's centre, and set the zoom so the group spans about 1500 px or less.
- Typical layout: Nexi at screen x 340–470, cards from 600–650 to 1650–1700.

## T · Text
| ID | Rule | Check |
|---|---|---|
| T1 | **Minimum on-screen size** (world size × zoom): headings 34 px, key information 22 px, labels 18 px (17.5 measured). Tiny text only when it is pure decoration. *(user: "small and hard to read")* | `audit:small` |
| T2 | **Text fits its box with 24 px or more of padding** (8 px is the absolute floor). Size every box from measured text (`L.tw`, `chipW`, the width `KIT.chip` returns), never a hard-coded width. | `audit:overflow`, `audit:tight`, `audit:touch` |
| T3 | **No text on text, no line through text.** Draw connectors before labels; give each label its own segment (bus routing). *(user: "text overlapping")* | `audit:overlap`, `audit:line` |
| T4 | **No partial covers.** A card covers a whole prop or label, or stays clear of it. | `audit:covered`, `audit:cards` |
| T5 | **No caption starts with "..." or "…".** The voice pauses on the dots. | `lint:T5` |
| T6 | **Captions are 2 lines (≤ 86 characters) by default.** 3 lines (≤ 130) only when nothing important sits below y 720 during that line; never 4. | `lint:T6` |
| T7 | **Labels sit on contrast.** Never text directly on a coloured or textured prop (weave, wood, stripes); use a chip or plate. | look |
| T8 | **An inline tag goes after the measured title**, at `titleX + titleW + 24 + chipW/2`. | `audit:overlap` |
| T9 | **A label is centred on the thing it names and true for it.** | look |
| T10 | **Quiz text fits its band.** The wide band is 1180 px. Shorten any answer over about 28 characters; never let answers overflow. In the ONE-ROW band the answers start at x + 560, so the 32 px question must stay under about 26 characters. | `audit:overflow` + look |

## N · Nexi
| ID | Rule | Check |
|---|---|---|
| N1 | **Nexi is never behind a card, quiz, caption or front-layer prop**, and never in front of text being read. | `audit:nexi-text` |
| N2 | **Flights never cross reading text.** Every scene change is a `flyOver` (up and over the frame top). `via` waypoints step her clear of a sign first. Check mid-flight frames: the spring cuts corners. | `audit:nexi-text` + look |
| N3 | **She roams.** Every beat moves her somewhere meaningful (fly, hop, ride, carry), and she faces the viewer when she speaks. Reactions are big: speed lines, shake, emotes. A free band of sky above a row of cards is a good home: she supervises from there, her base 10 px or more above the cards. | look |
| N4 | **Riding:** her lowest point sits on the roof line and the vehicle never draws over her. If the ride passes signs, she waves from above instead. | look |
| N5 | **Near the top of the frame or under a top quiz band, use the small cheer and no emote glyphs** (no `RX.hmm` '?', no `RX.shock` '!'; `shockJump`/`RX.shock` also lift her: use `peer` + `E.shock`; lint warns, p38). `bigjump` lifts her about 330 px and pushes her out of frame. | `lint` warn + `audit:nexi-edge` |
| N6 | **A hat is part of her silhouette.** Plan for tall hats (+80 px) and reaction lifts (+70–100 px) against plates and signs. `below` end spots only with low hats. | look |
| N7 | **Choose the intro exit (`introSeq` nx/ny) deliberately**, in the first scene's world coordinates, so her climb crosses no label. | `lint:N7` |
| N8 | **A held prop is gripped:** it starts at her hand (`pocket()`), its grip point (handle end or near edge) sits AT the hand (offset = the grip vector, never a free dx that leaves it floating), and it is carried at her side, never across her body or face. | look (`qa/mp4strip.py`) |
| N9 | **Floating decorations stay off Nexi and off text being read:** bubbles, hearts, stats, sparks. Fade them inside her `N.botPx()` box (±215 px wide, −340..+240 px tall). | `audit:nexi-text`, `audit:covered` |

## M · Motion and camera
| ID | Rule | Check |
|---|---|---|
| M1 | **Transition grammar** for every scene change: `flyOver` at t0 (t0 = the new line's start, never in the hold before it: whooshes in the gaps sink the voice ratio); the camera at t0 + 0.4 s (0.55–0.65 s for a long whip from a left spot); for a whip between stations (>= 2000 px apart) the old scene stays until the camera has landed (fade at t0 + 1.7 s; it is off-frame by then), so the whip never shows a blank frame; a same-station swap fades the old scene from t0 + 0.5 s; the new scene appears from t0 + 0.45 s; the CTA pops at about t0 + 0.7 s. | look (strip) |
| M2 | **The camera holds still while text is read** and moves between beats, using the grammar: establishing wide, push-in on a detail, whip pan to the next station, track a moving subject, crane up for builds, pull back for reveals, dutch tilt for comedy. Zoom stays 0.7–1.4; below 0.75, scale world text up. | look |
| M3 | **Story props are where the camera is** when their line plays. | look |
| M4 | **Props that fly away leave the frame entirely.** They never park over a card. | `audit:covered` |
| M5 | **A card pops after Nexi is clear of it**, never into her path. | `audit:nexi-text` |
| M6 | **Props tossed across a board fly a low arc** (h about 80) and are small in flight (s about 0.6). | `lint` warn |
| M10 | **Never toss a prop across a card's text.** A field or chip that joins a document fills its slot in place (tap, sparks). | `audit:covered`, `audit:overlap` |
| M11 | **`flyOver` cruises above the frame.** `up` is an absolute world y: in a world that climbs, pass `up` = the higher frame top − 250 and `via` straight up from her spot first. | `audit:nexi-text` + look |
| M7 | **A moving pointer** (Clicky, a cursor, a beam) never covers the label of the button it presses; aim at the button's edge. | `audit:covered` |

## P · Props, cards and samples
| ID | Rule | Check |
|---|---|---|
| P1 | **Card style:** white, a soft blue shadow, a 3–4 px `rgba(111,160,245,.45)` edge, radius 18–34. No more than five lines of text per card. | look |
| P2 | **Samples look like real, attractive designs at a readable size.** A phone is about 1:2, fully in frame, with phone-scale type. Proven sizes: card 340×200, slide 420×236, post 300×375, roll-up 210×420, signature 440×150, viewed at zoom 0.82 or more. *(user: "design should be visually appealing and eye catching, even the sample format")* | look |
| P3 | **Stacks the viewer reads sit in the back layer**; switch a prop to the front when Nexi grabs it. | look |
| P4 | **Empty fields look empty on purpose:** dashed border plus an "Empty" placeholder. | look |
| P5 | **Stands and posts end on a base above the caption band.** | `audit:covered` |
| P6 | **A card read while the world is busy goes in the `screen` layer**, over empty sky. | look |
| P7 | **Content is centred inside its container**; animate the shift when content grows. | look |
| P8 | **Draw order:** a fill that shapes a header (a square fill under a rounded header) is drawn before the header's text, never after it. | `audit:overflow`, `audit:covered` |
| P10 | **Objects keep their identity:** a crate, card or tag keeps its colour, label and size when it lands, moves or changes state (no repaint by slot or row). | look (`qa/mp4strip.py`) |
| P9 | **A cut-out (a bite, notch or hole) is ONE union outline**, traced through the circles' intersection points. Separate overlapping arcs under `evenodd` flip back in, and each subpath needs its own `moveTo`. | `lint` warn + look (CTA frame) |

## Q · Viewer quiz
| ID | Rule | Check |
|---|---|---|
| Q1 | **Exactly one quiz per solution video:** 3 s countdown, reveal, cheer. | `lint:Q1` |
| Q2 | **The subject of the question stays visible** (use the wide band at top or bottom, or the empty side). Nexi stands beside the quiz, never behind it. | `audit:covered`, `audit:nexi-text` |

## E · End card
| ID | Rule | Check |
|---|---|---|
| E1 | **Nexi's end spot is explicit and different per video.** Spots: `top`, `left`, `right`, `below`, `leftlow`, `rightlow`. No two videos in a series group share one, and neighbouring episodes differ. *(user: "make sure nexi will change location every video")* | `lint:E1`, `gate:G6` |
| E2 | **The spot suits the hat.** `below` only with low hats; tall hats use left, right, leftlow or rightlow. Low spots stay outside the link row (the AI row spans about x 353–1567). | look |

## A · Audio
| ID | Rule | Check |
|---|---|---|
| A1 | **Loudness −18.0 to −16.5 LUFS** (target −17). | `gate:A1` |
| A2 | **True peak −2.0 dBFS or lower.** Every film has a `render.LIMIT` entry (0.68–0.7). A miss is usually one sharp effect: find it with `qa/_peaks.py`. | `gate:A2`, `gate:G3` |
| A3 | **Voice ratio 3.5× or more.** | `gate:A3` |
| A4 | **Music sits 9.5–13.5 dB under the voice, and 4–7 dB under it in the gaps.** One upbeat style per topic, low-passed out of the 2–4 kHz voice band. *(user: "upbeat, not loud")* | `gate:A4`, `gate:A5` |
| A5 | **No effect drowns a word.** Long noise effects go between lines. | listen |
| A6 | **The voice is the website voice** (technext.asia/nexi): `audio_t.voice_bus` = the site chain (chirp + soft blips, master .26, Web Audio compressor); music low-passed 2.6 kHz, effects 5 kHz, master compressor. Never boost the blips again. Effects that pack the gaps are lowered per film (`FX_FILM`), not waived. | `gate:A1-A5` + `qa/audio_try.py` |

## G · Pipeline gates (`gate.py`)
| ID | Gate |
|---|---|
| G1 | The bundle is newer than the film script and the engine sources. |
| G2 | Lint is clean. |
| G3 | The film is registered: `render.NAMES`, `render.LIMIT`, `deliver.SRC` and `deliver.DST`, `audio_t.MAIN`. |
| G4 | A measured audit (step ≤ 5) was recorded from THIS build and analysed after it was recorded. `render.py audit` deletes the old report, so a stale one can never be read. |
| G5 | Zero HIGH findings, zero parked medium findings (≥ 1.5 s), and zero off-centre resting groups (≥ 3 s), unless waived. |
| G6 | The end spot is unique within its series group. |
| G7 | The MP4 was rendered from THIS build (`out/<name>.build.json`) and is complete. |
| A1–A5 | Audio as above. |
| G10 | **Names:** every post is `EPnn - <title>` in posting order (`deliver.EPISODES`); Quick Tips are their own series `Quick Tip nn - <tip>` (`deliver.TIPS`, never episodes); the series group is `deliver.GROUP`. The 16:9 file lives in the post's own folder: `<base>/<base> (16x9).mp4` (`deliver.DST`, p52). Audio-only refreshes of an already-delivered picture go through `deliver.py audio` (video stream bit-identical, A1-A5). |
| G9 | `deliver.py sheet` made the 12-frame sheet and the full-resolution CTA frame from this MP4, and you LOOKED at both. |

## H · Thumbnails, covers and packaging (`thumbs.js`, `thumbs.py`, `vertical.py`, `deliver_series.py`)
*(owner 2026-10-04: "redesign the thumbnail, still use technext branding. but make it over exaggerated … darker shade of blue … still connected to the video content with elements … add number of episode"; "make sure the thumbnails and short video also in one folder")*
| ID | Rule | Check |
|---|---|---|
| H1 | **One series look:** every thumbnail and cover sits on the same deep TechNext blue (`TNBG`; Before vs After keeps a slate "before" half), with the cyan glow behind Nexi, the cyan rim glow, and the giant ghost number. Never a per-episode rainbow background again. | look at the contact sheets |
| H2 | **Connected to the video:** Nexi wears the episode's costume and at least one element comes from the episode itself: drawn props from its story, or a scene card cut from its own key frame (`assets/thumbframes/<id>.jpg`). The crop never shows a second Nexi. | look |
| H3 | **The number is the hero:** the branded badge (TechNext logo strip, NEXI EXPLAINS / QUICK TIP strip, EP nn / TIP nn up to 214 px via `fitSize`). The number comes from `deliver.EPISODES` through the URL (`&ep=&qt=`); never hard-code it. | thumbs.py |
| H4 | **The hook is two lines** (white, then the yellow punch), at most about 10 characters on line 2 so it stays ≥ 190 px. Props and pills stay off both lines; nothing important sits in the bottom-right corner (YouTube's duration stamp). | look |
| H5 | **Layering:** the scene card draws in FRONT of Nexi (a raised hand reads as holding the screen); pills sit on the card's bottom-right corner, short (≤ 12 characters). Covers: the badge has no format tag; Nexi's face stays inside the 3:4 grid crop (y 240–1680). Vertical-video frame: the badge ends ≥ 20 px above the hook. | look |
| H6 | **One folder per post** in folder 22 (`<base>/<base> (16x9).mp4`, `(9x16).mp4`, `- YouTube thumbnail.jpg`, `- cover (9x16).jpg`), filled only by `deliver_series.py` (md5 on every copy, stale files moved to `_superseded <time>`, never deleted). | deliver_series.py |

## K · Code safety (engine)
| ID | Rule |
|---|---|
| K1 | Film globals never reuse engine names (the `build_film.py` guard). |
| K2 | Never tween a whole array, and initialise every field you tween (a NaN tween silently draws nothing). |
| K3 | Every `save()` has its `restore()`. Delete dead drawing code instead of half-deleting it. |
| K4 | `L.tween` cannot be cancelled. Compute anything that must stop on cue from a start and a pause time. |
| K5 | `zap()` only targets Odoo UI hotspots. A tap on a world prop is a ring plus a tap clip. |
| K6 | A new costume goes in `build_core.py buildWear()`, is built up front, and its colours go through `convertSRGBToLinear`. |
| K7 | JS and patch scripts are written with the Write tool, not Bash heredocs (heredocs break JS, and the Bash tool halves backslashes). Patches assert-and-replace. |
| K8 | Never call `at()` inside an `at()`/`later()`/mover callback: the event list is sorted once, so a late `at()` runs at the very end. Inside callbacks use `later(d, fn)`. Check: `lint:K8` (p37). |

# Lessons log

Append a dated entry after every video job: newest at the bottom, one bullet per lesson. When a lesson becomes a rule, add it to `rules.md` with an ID and its check; automate it if it was broken twice.

## 2026-10-03 · Odoo walkthrough + topic series (walk, myth, tip, reorder, beforeafter)
- **User asks:** cinematic, intro like the website logo animation, a floating "with Nexi" tag, robot voice, exaggerated acting, floating Odoo icons.
- **Fixes to the look:**
  - Lowered the floor-grid and flare opacity.
  - Use the plain Odoo logo, never "Odoo Ready Partner".
  - Nexi faces the viewer.
  - Music upbeat per topic, never loud.
  - Same intro and outro with a new touch per video.
- **Audit 1** (the user said "a lot of design lapses"):
  - Badge slots sat above the wordmark.
  - The HUD plate had to be opaque.
  - The caption card needed a fixed width.
  - The Odoo window had to sit in a safe-area pose.
  - Nexi needed her own lane beside the window: clicks become beams (`zap`), spotlights and a lens replace crop-zooms, `tether` handles drags.
  - Chapter bands were drawn before Nexi.
  - The intro exit is a crossfade, not an iris.
  - Shatter effects were reduced to a two-piece tear.
  - Report data had to be consistent across screens.
- **Audit 2:**
  - Myth/fact cards must not sit in a corner (centred pair).
  - The logo must be centred in intro and outro.
  - "with Nexi" must look as in the walkthrough.
- **Audio:**
  - The voice was buried 14 dB under the music. Fixes: ducking 62 %, voice ×1.9, blips ×4.6.
  - Loudnorm needs an alimiter. The walkthrough needs limit 0.7.
  - Measure with `_buslevel.py`.
- **Engine:**
  - Glow-pass mesh lists are cached for 240 frames.
  - Chip pop-ins must use per-item timestamps, not a tween's end value.
  - Never tween a whole array.
  - Avoid leading "..." in a caption line: the voice pauses on dots.

## 2026-10-03 · Solution videos round 1 (erp, crm, enterprise, web, social, brand)
- **User asks:**
  - Nexi roams the whole area.
  - More dynamic reactions.
  - Not cornered.
  - More camera movement and angles.
  - More interactive.
  - Analogies, role-play, new and random elements.
  - Every video unique.
- **Built engine v2:**
  - A camera mirrored into 3D, so Nexi stays sharp when zoomed.
  - `fly`/`hop`/`orbit`, `thing` + `grab` + `toss`, 3D costumes, `quiz`.
  - A marketing end card.
- **Bugs fixed:**
  - Depth must pivot around the camera centre, not the frame centre. Without it, Nexi at z ≠ 0 drifted up to 400 px on long sets.
  - Costumes must be built before the first frame, or the glow pass blooms them white.
  - Costume colours need `convertSRGBToLinear`.
  - World props drew over the intro/end-card logo. Added `WORLDOFF`.
  - Filtering the mover list while pushing to it dropped `fly()` calls made inside movers.
- **Staging lessons:**
  - The quiz card covered the plane: hold the plane mid-air during the quiz and land it on the reveal.
  - The quiz card covered the logos being counted: added the wide layout.
  - Nexi stood behind the CTA card: put the CTA beside her, or pop it after she lands.
  - The stale-lead train was off-camera during its line: place story props where the camera will be when the line plays.
  - `bellkey` FM music flooded the voice band (voice ratio 2.6×). Low-passing it gave 4.8×.
  - A render died with "F is not defined" because an outside process killed Chrome. Rerun.

## 2026-10-03 · Solution videos round 2 (user review)
- **User feedback (verbatim):**
  - "some text are overlapping, small and hard to read. maximize the designing of the element" (social)
  - "improve presentation design and camera works. design should be visually appealing and eye catching, even the sample format that showcased" (brand)
  - "fix the mobile design … 0:45 the design are too low" (web)
  - "we dont have malaysia. revise the explanation and make it truthful … explain technext and do also sample company" (enterprise)
  - "0:23 there some blocking in middle station" (crm)
  - "text overlapping" (erp)
  - "in all outro, let nexi to much in the corner. make sure to make nexi will change location every video"
- **Rules added:**
  - Minimum on-screen text sizes.
  - Labels fit their boxes.
  - Nexi never in front of text being read; flight paths route around text.
  - Stacks the viewer reads go in the back layer.
  - Story props never park on signs.
  - The phone sample is fully in frame at real proportions.
  - Hand-over scenes stay above the caption band.
  - Truthful company facts: TechNext is SG HQ plus PH and VN teams, 10+ countries delivered, no Malaysia. Use a labelled sample company for demos.
  - Outro spot per video.
- **Outro spots tested:** `top` (above the wordmark), `left`, `right`, `below` (under the CTA row), `leftlow`, `rightlow`, all clear of the logo and CTA rows. The old right spot (1712, 610) read as cornered.

## 2026-10-03 · Solution videos round 2 (fixes delivered)
- **What changed per video:**
  - **ERP:** crates moved to the back layer, away from Nexi, with bigger labels; the slab was widened so every label fits; the stamp fades when the floors land. Nexi switches sides by flying *up and over* the house (out of frame) instead of across the floor text, and throws the go-live scissors. Cable labels are drawn after all cables. End spot `top`.
  - **CRM:** the Projects train was parked on the middle branch sign. It now waits between stations. The quiz uses the new two-row wide band at the top so the signs stay visible. Small text was bumped to 17–22. End spot `left`.
  - **Enterprise:** the line "Our group… Malaysia" implied TechNext's own group. The film now opens with a TechNext crew card (facts from the live site: Singapore HQ; Philippines hub in Taguig for Odoo development and consulting; Vietnam hub in Ho Chi Minh City for AI engineering; clients in 10+ countries). The demo then uses a "Sample group · illustrative" (Singapore holding, Philippines and Vietnam companies) with an on-screen tag. There is no Malaysia anywhere. End spot `below`.
  - **Web:** the phone was a tall strip. It is now a real phone (300×616, about 1:2) in frame with phone-scale type; the page scrolls inside it to the form. The hand-over scene was raised to mid-frame and enlarged. End spot `right`.
  - **Social:** full readability redesign:
    - planter labels on the bed fronts;
    - a week × channel plan instead of a 31-day grid;
    - a big sample post with the quiz in the top band;
    - three big sample tiles, a proper gate, a bigger basket and report.
    - End spot `leftlow`.
  - **Brand:** five realistic sample formats (card 340×200, 16:9 slide, 4:5 post, roll-up, signature) in off-brand and on-brand versions. Nexi rides the clothes rail like a zipline so she never covers an asset. A full-frame style guide shows tokens, then components. End spot `rightlow`.
- **Engine lessons:**
  - **Film globals must not reuse engine names.** A crew card constant `CH` overwrote the engine's chapter state and crashed `drawChapter`. Check the list in `engine.md` before naming.
  - **`fly()` follows a spring (`N.go`), so Nexi cuts corners.** Give waypoints 250 px or more of clearance around text, and keep long paths at about 1300 px/s or slower. Check mid-flight frames.
  - **A `thing` created at world (0,0) glides across the whole frame when grabbed.** Use `pocket(o, hand)` to place it at her hand first.
  - **Draw labels after connecting lines** (cables, pipes), or a later line crosses an earlier label.
  - **Three-line captions lift the caption top to about y 720.** Keep lines at 86 characters or fewer when content sits low. The top is about 880 for one line and 835 for two.
  - **`bigjump` lifts Nexi about 330 px.** Near the top of the frame, use a small cheer (`excited` + sparks) instead.
  - **When the camera follows, clamp its y** so screen-fixed bars (step bars) don't land on the subject.
- **Audio lessons:**
  - True-peak overshoots came from single sharp effects: a `snip` at 0.9, and a `jet` under voice blips. Find them with `qa/_peaks.py <name>`, lower that effect in `out/events-<name>.json` and in the film, then re-mux. Changing `render.LIMIT` trades loudness for peak.
  - The `qa_av` voice ratio counts whooshes placed between lines (correct placement). Read the gap list in `_peaks.py` before "fixing" a low ratio. Web stayed at 2.1× for this reason, with music 10.6 dB under the voice.
- **End-card spots across the six solution videos:** `top`, `left`, `below`, `right`, `leftlow`, `rightlow`. On the marketing end card the link row spans x 426–1500, so low spots must stay outside it (x ≤ 300 or ≥ 1640).

## 2026-10-04 · Solution videos batch 3: Technology (iot, appdev, network) + AI (odooai, automation, chatbot)
- **User ask:** one video per item in the technext.asia Solutions menu: Technology (IoT Solutions, App Development, Networks) and AI (Odoo + AI integrations, Workflow Automation, AI Chatbots). Saved to `22. Nexi Solution Videos` as `Technology 1-3` and `AI 1-3`. RAG Knowledge Assistants (the fourth AI menu item) was not in the screenshot and not made.
- **Worlds used:** Chef Nexi's cold store (chef toque, penguin), Technician Nexi's field visit (cap, cat on the van), Gatekeeper Nexi's castle (knight helmet, rubber duck), Nexi the butler (bow tie, owl, cloche CTA), Inventor Nexi's marble machine (goggles, hamster wheel, calendar-with-a-bite CTA), Concierge Nexi on the night shift (bellhop hat, sleeping cat).
- **A film `var` re-assigns the engine's variable.** Films share one closure with the engine, so `var FLY = [...]` in odooai replaced the engine's flight state: Nexi never moved and was missing from every frame. `build_film.py` now refuses films that redeclare engine top-level names. The guard also caught `SPL` in brand (it had replaced the spotlight state), `END0` in walk (made a plain assignment) and `badge`/`bang` in thumbs. All renamed.
- **`L.tween` from an undefined field gives NaN, and the prop silently never draws.** The "Timesheet in / Invoice drafted" chips in appdev never appeared. Initialise every field you will tween.
- **Never tween a whole array** (again): the chatbot's language bubbles were reset with an array tween. Set the elements directly.
- **Unbalanced `gg.save()`** in leftover code (a save with no restore) leaks canvas state into every later layer. Delete dead drawing code instead of leaving half of it.
- **Tall hats cover name plates.** The chef toque and the knight plume reach about 230-300 px above Nexi's centre, and `RX.panic` or `excited` lift her another 70-100 px. Plan her y against the plate row, then check reaction frames.
- **Spring lag drags Nexi across labels even with high waypoints.** In automation she crossed the Draft plate twice. The reliable route over a set full of labels is out of the top of the frame (y at least 200 above the frame top) and back down.
- **`zap()` only targets Odoo UI hotspots** (`SET.spotPx(key)`). For a tap on a world prop use a ring helper (`tapAt(x, y)`: a tap clip plus `L.ring` and a tap sound).
- **Dark text over a dark prop vanishes** (the "Vendor" label over the mailbox post). Put labels on chips.
- **Cards that would clutter the world go in the `screen` layer.** The automation run log had covered the Draft station and was cut by the frame edge; a screen-fixed card over empty sky fixed both.
- **Quiz over a tall subject:** zoom out until the subject fits between the wide band (bottom at about y 256) and the caption (one line: top about 880). In appdev, zoom 0.82 with camera y 424 fit a 690 px phone and the Odoo card.
- **Typed lines:** quote-led lines (`"Where's my order?" I read it live...`) speak fine; only a leading "..." makes the voice pause.
- **Audio:** stamps at 0.6-0.7 were the true-peak source again (iot). 0.45 is enough. MUSIC_GAIN iot .31, odooai .31; the rest of the batch passed at the default .34.

## 2026-10-04 · Batch 3 round 2: the user's screenshot audit (IoT, App Development, Networks, Odoo + AI fixed; Workflow Automation and AI Chatbots rebuilt)
- **User feedback (verbatim):** "after finishing all the video, audit properly. there are some lapses and, not properly centered and not properly design. if needed to reedit the whole video please do. i will send a free screenshot need to fix, edit or revise. properly redesign the 6th video and workflow animation." / "audit all videos." / "make sure after this session, improve the skill for nexi video. recognize all mistake and in next prompt it will not happened again"
- **What the 15 screenshots showed, and the cause of each:**
  - Nexi cut by the left edge in most scenes (prototype, launch, diagram, bell, one team, tools). Cause: her spot was authored in world px (`STATION - 800`) and never converted to screen px at that scene's zoom; at zoom 0.9 that put her centre at x 150-250. Rule: compute spots from the screen (Framing math).
  - Text touching or overflowing its card ("main line + backup", "Google Play", "Spreadsheets", the desk plaque). Cause: fixed card widths. Rule: size boxes from measured text.
  - A tag chip cutting the end of a title ("Network diagra|m ✓ Handed over to you"). Cause: chip at a fixed x. Rule: inline chips go after the measured title + 24 px.
  - A card half-covering another prop's label (the Odoo IoT hub over the printed label, the alert phone over the freezer plate, the Quality Check card over Chiller A). Rule: cover a whole prop or none of it.
  - Labels that don't label what they sit over ("Customer apps / Staff apps / Portals" floating above iOS / Android / Web, off-centre, with the platform pills cut by the frame bottom). Rule: each label centred on its item and true for it; everything above the caption band.
  - Off-centre groups (the prototype card with the team outside it, the launch scene, the vendor bill scene, the diagram left-heavy inside its scroll). Rule: centre the group; centre content inside containers.
  - Nexi standing BEHIND the van (front layer) instead of riding on it. Rule: riding = her lowest point on the roof line and nothing in front of her; if the ride would pass signs, she waves from above instead.
  - Port labels P03-P06 stacked at the fan-out. Rule: one segment per label (bus routing).
  - The bell posts running down behind the caption. Rule: stands end on a base above the caption band.
  - Empty fields that looked broken (vendor bill). Rule: empty inputs look empty on purpose (dashed border + "Empty").
  - Workflow Automation's marble machine: labels over posts and ramps, thin rails, small text, cut stations, a log card covering a station. Rebuilt (see below).
  - AI Chatbots: small cards and text in mostly empty frames, Nexi cornered. Rebuilt (see below).
- **What the measured audit found that sheets had missed:**
  - Empty frames before every CTA (the old scene faded at line start, the CTA popped 1.1 s later) and after camera moves (scene content waited for a later word).
  - Nexi passing under the HUD chapter pill on almost every scene change: the camera pan drags her across the top-left while her spring-lagged flight is still slow. Fix: `flyOver` (fast ease-out take-off, up and over, drop in from above-right) + camera moves 0.4 s after take-off (0.55-0.65 s for long whips from a left spot) + `via` waypoints to step clear of signs first.
  - Delaying the camera created a new gap (old scene gone before the camera moved). Fix: the old scene fades from +0.5 s, the new scene appears from +0.45 s.
  - A lifted cloche lid parked over the CTA card. Rule: props that fly away leave the frame.
- **Rebuilds that worked:**
  - Workflow Automation: five step modules in ONE centred row (280 px, 340 apart, zoom 0.84-0.88), a request card ("PR" then "PO") riding a track beneath, a log tag printed under each step, Finance approving on a card above the Approve module with a barrier on the track, Nexi supervising from the open sky ABOVE the row (never over a module). Other scenes: a control console (quiz; pause / kill switch / roll back driven by a computed position, since tweens can't be cancelled), guardrail columns that are up when the camera lands, a tools hub with cards sized to their names, the monthly report, the calendar CTA.
  - AI Chatbots: a night lobby (window, clock, channel cards stacked right, inbox tray, bell, sleeping cat) with Nexi behind the desk; ONE large realistic chat window (header, scrolling bubbles, input bar) carrying three conversations, with a matching side card each time (your content, the Odoo order, the CRM lead); the quiz and hand-off back in the lobby; one-content-three-languages; the review notebook; the CTA.
- **Checker false positives fixed (so findings can be trusted):** shapes inside a clip only cover what the clip shows; a text wholly under a later opaque card is hidden, not a fault; an outline behind the text's own card is hidden; opaque drawn shapes (a van body) hide what is behind them; translucent gradients (a scan beam) are not opaque covers; 1-2 character glyphs (badges, dozing z's) are decoration; Nexi crossing the frame edge for under 1.8 s is a transit.
- **Audio:** IoT and AI Chatbots missed the true peak (-1.8 / -1.5 dBTP) on voice peaks, not effects. Fix: `render.LIMIT` 0.68 for those two (plus softer buzz / stamp / holo), re-mux only.
- **Tooling:** `audio_t` has no `clunk`, `rewind` or `crunch` sound; check the list in `engine.md` before using a name.

## 2026-10-04 · Round-2 follow-ups: AI 2 calendar, Quick Tip, Social (older-film audit)
User feedback (verbatim): "fix this part  ai 2" (screenshot: a white diagonal band through the THIS WEEK calendar on the Workflow Automation end scene, only "IS WEEK" visible).
- **Cut-out made of circles (the hamster bite).** First cause: each arc in the evenodd clip path was joined to the previous point by a straight line, which cut a diagonal wedge through the card. First fix (a `moveTo` before each arc) removed the band, but the full-resolution crop of the FINAL MP4 then showed white wedges at the joins. Under evenodd, the place where two circles overlap is covered twice and flips back IN. Final fix: the bite is ONE outline, the union of the circles (four arcs between their intersection points), with separate circles only while they don't overlap. I missed both defects on the 12-frame sheet, so a full-resolution crop of the CTA object is now a delivery check.
- **Stale audit reports.** `render.py audit` writes `data.jsonl` and frames but NOT `report.txt` or `issues-*.jpg`. I read a report from the previous run and nearly "fixed" a calendar that had already moved. Always re-run `python layout_audit.py <film>` after the audit render, and check the report is newer than `data.jsonl`.
- **Quick Tip:** the day calendar sat right above Nexi's home spot. Her "one click" jump covered it, and the confused "?" glyphs landed on its text. It now sits at (300, 52) between the HUD and the Odoo window (0 high findings).
- **Audio:** films with no `render.LIMIT` entry fall back to 0.8. Quick Tip peaked at -1.6 dBTP. LIMIT is now set for every film (tip 0.68; myth, reorder and beforeafter 0.7). The fix was a re-mux only.
- **Social Media:**
  - **Intro exit.** `introSeq` nx/ny (default 720, 600) is where Nexi flies after the lock-up, in the FIRST SCENE's world coordinates. Social's default sent her diving through the planter labels while the garden faded in. Now nx/ny is 1620, 470, so she rises in the gap between the LinkedIn and Facebook labels.
  - **Quiz.** She used to fly straight across behind the sample post (a front-layer card). Now she does a `flyOver` and the card pops 0.45 s later, once she is clear.
  - **Report to CTA.** She passed behind the report's corner. Now `flyOver(..., { via: [[REPX - 700, 40]] })` climbs on the left first.
  - **Seed packets.** Tossed packets looped over the "October plan" title (arc height 300). They now fly a low arc (h 80) at scale 0.6.
  - **Engagement bubbles** floated over Nexi while she watered. They now fade out inside her silhouette box (`N.botPx()` is world px).
  - **Basket.** The "Leads" label sat on the weave lines; it now has its own plate.
  - **Produce, approve and quiz** are re-centred as one group (Nexi + card).
  - The CTA body lines got 36 px leading.
- **Delegation:** four agents fixed Web, CRM, Enterprise and ERP in parallel (no renders). The user paused the session mid-way. Each agent was asked to stop at a buildable point and report; their plans are in `qa/ROUND2-TODO.md` in the renderer repo.

## 2026-10-04 · Strict mode: the rules became code (lint, measured audit, release gate)
- **User ask (verbatim):** "properly train and set up rules. upgrade nexi video skills base on changes and updates. be strict implementing rules."
- **Why.** Every lapse the user found was already covered by a written rule, but a written rule only works if someone remembers it at the right frame. The fix was enforcement:
  - `reference/rules.md` is a numbered rulebook (C, B, F, T, N, M, P, Q, E, A, G, K), and each rule names its check. It replaces design-rules.md.
  - `lint.py` runs inside `build_film.py` and blocks the build. It checks: Malaysia (C1), partner badges (B1), samples unlabelled (C3), cyber security (C4), leading dots (T5), 4-line captions (T6), intro exit (N7), end spot (E1) and the one-quiz rule (Q1). `--selftest` proves each check fires.
  - `gate.py` checks build, lint, registry, a measured audit of THIS build (fingerprint), the HIGH / parked / off-centre findings, end-spot uniqueness, the render stamp, audio A1–A5, and the final sheet + full-resolution CTA frame.
  - `render.py mp4` refuses on a failing pre-gate. `deliver.py copy` refuses on any FAIL. There is no bypass flag. Waivers need reasons and are told to the user.
  - Stamps prove it is the same build: `render.py audit` writes `meta.json` (fingerprint) and deletes the old report; `layout_audit.py` writes `findings.json`; `render.py mp4` writes `out/<NAME>.build.json`.
- **Calibration** (the gate run on the films delivered today):
  - Workflow Automation, AI Chatbots, IoT and Networks pass.
  - It caught real lapses I had called done:
    - App Development's phone scene (11–18 s) crammed into the left half, with the right half empty, plus the van scene left-heavy (6–10 s).
    - Odoo + AI: Nexi's hand 90 px from the left edge (8–10 s; resting centre 280 < 300), and the bill scene 170 px right of centre (24–28 s).
    - Quick Tip: the walkthrough-family home spot puts Nexi 80–90 px from the edge.
    - Social: a tossed packet crosses the LinkedIn row label for 0.5 s, and the held packet touches the board title.
  - It also showed one checker blind spot, now fixed: the 3D Odoo window was not counted in the composition (patch p30). Walkthrough-family films looked off-centre whenever the window's text was sparse.
- **Fixed in source now** (each needs a re-render through the gate):
  - CRM "SG · MY · ID" → "SG · TH · ID", and Kopi Co. MY → TH (C1).
  - Leading "…" removed in myth, reorder and beforeafter (T5).
  - Explicit end spots (E1): myth `left`, beforeafter `leftlow`, tip `rightlow`, reorder `top`. The four used to share the default `right`.
  - ERP and Web fail lint C3 (no on-screen "sample" label): add one in their redesign.
- **General lessons from the four planning agents** (Web, CRM, Enterprise, ERP), promoted to rules:
  - A square fill drawn after a rounded header runs over the header's text (P8).
  - Quiz answers longer than about 28 characters overflow the 1180 px wide band (T10).
  - The pointer-with-eyes covers the button label it presses (M7).
  - Props carried across Nexi's body hide her (N8).
  - Cranes and boards are cut at the frame edges while the camera holds (F4).
  - The CTA pops into an almost empty frame (F5).
  - Sparks land on chips (N9).
  - The big cheer lifts Nexi out of frame (N5).
  - 3-line captions reach y 720 (T6).
- **Tooling:**
  - Two modules re-wrapping `sys.stdout` closed each other's stream ("I/O operation on closed file"); use `sys.stdout.reconfigure`.
  - The Bash tool halved the backslashes in a heredoc patch again; write patch scripts with the Write tool.
  - `SET` and `P` live inside the engine closure, so audit-side code cannot reach them. Engine data for the audit goes through `AU.setMeta` in `engine_tail.js`.

## 2026-10-04 · ERP 4 Odoo Customization (new film `custom`) + AI 1 Odoo + AI re-delivered; CRM redesign paused
- **User ask:** "do create video for these" (screenshot of the Odoo menu's Customization column: Odoo Customization, AI Integration, CRM Development). AI Integration (`odooai`) and CRM Development (`crm`) already had films on the same pages, so they were fixed rather than duplicated; Odoo Customization (`odoo/erp-system`) got a new film. Then: "wrap it up, work in new video".
- **The world:** customising Odoo is a five-camp climb (standard, configuration, Studio, custom module, integrations: the page's own "start at standard, climb only when you must"). Guide Nexi in a knit beanie (new costume `beanie`, p31), a mountain goat always one camp ahead, an upgrade-test card, the summit flag CTA. Music style `alpine` (marimba + swing). File: `22. Nexi Solution Videos/ERP 4 - Odoo Customization (16x9).mp4`, 62.5 s, end spot `right` (ERP group: erp top, crm left, enterprise below, custom right).
- **Framing by construction (worked first time):** every camp is authored in SCREEN coordinates and drawn with `gg.translate(OX(k), OY(k))`, where `OX = CX - 960`, `OY = GY - 790`, and the camera sits at `(CX, GY - 250, zoom 1)`. The local layout then IS the frame, so centring is exact: Nexi at screen (430, 470), the sign top-centre, props on the ledge at screen y 790. The first audit had 0 off-centre findings in the camps.
- **First audit: 5 HIGH, all known patterns:**
  - Held tags covered Nexi's body: `pocket(o, 'R', 10, …)` puts a 200 px tag across her. Use dx about 150 (N8).
  - A field chip tossed into a document slot crossed three text rows. Fill a slot in place (a tap plus sparks); never toss across a card's text (M10).
  - In the ONE-ROW wide quiz, the question starts at x + 32 and the answers at x + 560, so a 32 px question longer than about 26 characters runs under the first answer pill ("covered"). Keep the question short (T10).
  - `RX.hmm()` "?" glyphs sat under the top quiz band, and `RX.shock()`'s "!" floated out of the top of the frame. Near the top band or the frame top, act without emote glyphs (`N.play('think')`, `shockJump` without `bang`) (N5).
- **Parked mediums:** a value chip above its row overlapped the row card (put values inside the row). A header band made from `rrect` + `fillRect` had an edge through the title (clip one band to the card instead). Cargo labels riding a rope bridge crossed the ropes (use Odoo icons, no text).
- **Off-centre CTA:** the flag group measured 270–1290 (180 px left). Shift the CTA object until Nexi + object centre within 160 px.
- **`flyOver` cruise height:** the default `up` (-400) is an absolute world y. In a world that climbs (camera y < 300), -400 is INSIDE the frame. Pass `up` = the higher frame top − 250, plus `via: [[x, y − 410]]` (straight up from her spot first), so she never crosses the camp sign.
- **Far parallax ranges:** draw them in a back prop with `gg.setTransform(1,0,0,1,0,0); camApply(gg, 0.22)`. Shapes only; the audit is unaffected.
- **Audio:** two pops stacked on `wear()`'s magic + pop made a −1.4 dBTP peak at 5.5 s. `render.LIMIT` 0.66 did NOT fix it (the stack itself is the source); lowering the pop in the film and delaying it by 0.25 s gave −3.1. MUSIC_GAIN custom .31 (music 10.1 dB under the voice, 4.7 dB in the gaps). Don't stack a scene pop on the costume's pop.
- **odooai (agent):** camera x 1740 + Nexi x 1060 cleared the left edge. The bill scene was re-centred with Finance at (2900, 610); Finance presses Approve (true to "a person approves"). Full gate PASS, no waivers, 61.8 s.
- **CRM (agent, paused):** a full redesign per the ROUND2-TODO plan builds with clean lint but is NOT audited. See `qa/ROUND2-TODO.md`.

## 2026-10-04 · CRM Development round 3: the redesign through the gate (38 HIGH → 0), Season-1 reels refreshed
- **User ask:** "continue this" (the paused CRM redesign). Delivered: `22/ERP 2 - CRM Development (16x9).mp4`, 60.3 s, full gate PASS, no waivers; Malaysia gone (sample markets SG · TH · ID).
- **The audit only sees text and cards.** The composition check counts text boxes, text cards and Nexi. A big UNLABELLED prop (the train at the lead station) is invisible to it, so the scene measured 296 px left of centre although it looked balanced. Fix: give key props a readable label ("Boarding" on the empty car, "CRM Express" on the loco, shown only in that scene) or move the labelled pieces.
- **Draw a moving prop's label last.** The car's plate was drawn before its bar and wheels. On the curve the car tilts, the rotated label's box overlaps the later shapes, and the audit reads "covered" (HIGH). Plates and labels go after every shape of their prop.
- **Fade a station's labels when the camera leaves.** The junction plates slid under the caption while the camera tracked the train away. A scene-alpha (`JA.a`) tweened to 0 at the departure fixed it.
- **No particles near labels.** Confetti over a moving label = HIGH. Celebrate with rings around the plate (`L.ring`) or sparks well away from text.
- **A card that rises out of another comes to rest clear of it** (≥ 10 px gap), or the "cards overlap" medium parks for seconds.
- **Stamps land where the action is.** A punch stamp beside the ticket heading passed the audit but read crowded at full resolution; on the stub (what Nexi punches) it is clear and makes sense. Always judge the full-res CTA crop, not just the checker.
- **Audio:** lowering the whistle (0.8 → 0.55) RAISED another peak (-1.9 → -1.5 dBTP), because loudnorm re-normalises the whole mix. `render.LIMIT` crm 0.66 gave -3.1 dBTP at -17.9 LUFS. When you change an effect in `out/events-<film>.json`, change the film source to match.
- **Season 1 packaging:** after re-rendering a Season-1 episode, run `python vertical.py <ids>` then `python deliver_series.py` (it re-copies all 58 files with md5). EP05 tip, EP06 crm and EP10 social reels were regenerated.
- **Costumes for the Odoo Apps series (p33):** `tophat`, `boppers` (heart boppers), `helmet` (GREEN cycling helmet: the first blue one read like the App Development cap), `astro`. Check new costumes on `films/weartest.js` + `render.py sheet` before any film uses them.

## 2026-10-04 · Apps 1 All Odoo Apps (new film `apps`, Odoo Apps series)
- **User ask:** "create new fresh video for this" (screenshot of the Odoo menu's Odoo Apps column: All Odoo apps, Accounting, Sales, Inventory). A new series group **Apps** (`Apps n - <name> (16x9).mp4`, gate G6 group added). Apps 1 by the lead; Accounting, Sales and Inventory by three agents in parallel (ports 3987/3990, 3988/3991, 3993/3994).
- **The world:** Odoo City. 8 districts = the app categories with their app counts, one grid under the streets = the shared database (a cut-away with Customers / Products / Accounts pipes), an order crossing three buildings = native links, an empty lot + quiz = adding an app later, the city switchboard = phases, the key to the city = the CTA. Mayor Nexi (`tophat`), a pigeon that perches on roofs and signs. Music `city` (vibe + four): MUSIC_GAIN .30 and LIMIT .66 were needed (music was 8.7 dB under the voice at .34).
- **`at()` inside a running event never fires on time.** The event list is sorted once at build; an `at()` added from inside a callback goes to the END of the list and runs after everything else (the 8 district tiles never appeared). Inside callbacks always use `later(d, fn)`. Rule K8.
- **Size every building or plate from its measured name** (`w = max(w, iconW + L.tw(name) + pad)`): "Accounting" was clipped by a 200 px building.
- **Pigeon/animal perches:** on a roof edge or a sign's top edge, never on a label; move the perch when the scene changes (the pigeon floated in mid-air after its sign faded).
- **Card interiors need a vertical budget.** A footer chip at `y + h - 40` landed on the second row of tiles: plan rows so the footer has its own band.
- **Tall hat under the top quiz band:** drop Nexi about 90 px for the quiz (`goTo(x, y + 90)`) and restore her on the reveal.
- **Motion-blur whips** produce 1-frame "overflow" mediums on every text in frame; they never park, so ignore them.
- **K8 is automated** (`patches/p37_lint_k8.py`): lint tracks build-time vs runtime function bodies (a function passed to anything but forEach/map/filter or an IIFE is runtime) and blocks `at()` inside runtime bodies; selftest covers both sides, 0 hits on all 23 films. The first attempt was written as a Bash heredoc and broke lint.py (escapes): K7 again. Write patch scripts with the Write tool, test on a COPY, then apply.

## 2026-10-04 · Apps 2 Accounting (agent; new film `accounting`)
- **The world:** "It's a Match!", a dating show where bank lines meet invoices. Matchmaker Nexi (`boppers`), lovebirds, a golden-envelope CTA, end spot `leftlow`. 65.2 s, full gate PASS, no waivers, MUSIC_GAIN .34 (style `gameshow`). The first pill uses the `accountant` tile (the real Accounting app; `account` is Invoicing).
- **Stage changes start AT the line start, never in the hold before it.** Starting 0.4 s early put every whoosh into the gaps that A3 measures, and the voice ratio fell to 0.8×. M1 now says t0 = the line's start.
- **Leaving a busy board:** two straight-up waypoints (`[x, 60]` then `[x, -280]`) before the crossing. One waypoint let the spring cut the corner through a title.
- **Dashed "Waiting for…" slots** make a good establishing shot before the cards arrive. Fade each slot before its card pops, or the growing card half-covers the slot text.
- **A card rising out of a container (the envelope):** fade its text in only once it is about 75% up, so nothing ever half-covers it.
- **Backdrop decorations** (drapes, spotlight cones): use gradients with transparent stops, or make them frame-sized, so the audit never treats them as the box under loose text.

## 2026-10-04 · Apps 4 Inventory (agent; new film `inventory`)
- **The world:** Commander Nexi (`astro`) follows ONE transfer on a light space-station cargo deck: mission board of the 5 states, dock + Quality arch (receipt), robot arm into labelled bays + route pills 1/2/3 steps (put away), lot / serial / expiry tags (in stock), barcode picking 8 of 10 (quiz → backorder), a gauge below Min firing the reordering rule (RFQ capsule docks into Purchase), the launch pad (shipped), invoice 10 ordered / 8 delivered / 8 invoiced, mission-patch CTA, a floating goldfish. 65.3 s, full gate PASS, no waivers, style `space`, MUSIC_GAIN .34, end spot `left`.
- **Screen-coordinate stations** (the custom.js pattern) gave 0 HIGH and 0 off-centre on the first audit. Putting Nexi on the RIGHT for one station varies the rhythm without breaking the centring.
- **Two-joint robot arm:** keep every target on one side of the shoulder so the elbow never flips; draw the arm BEFORE the rack so bay labels stay on top.
- **`shockJump` (and `RX.shock`) lift Nexi too:** from y 470 the astro antenna left the frame twice. Use `peer` + `E.shock` near the top. N5 lint now warns on shockJump / RX.shock (p38).
- **A prop flying into a card** (the RFQ capsule) drops its label before it fades, and its sparks stay off the card's text.
- **Effects under spoken words** stay at 0.3 or below: a 0.45 whoosh under a word right after an alarm hit -1.67 dBTP.
- **Known checker artifact:** during a quiz wait the caption fades with no next line and the audit briefly reads "caption overflow". It is short and passes; do not "fix" the checker for it.

## 2026-10-04 · Quick Tips #2-#4 (agent, built in a SANDBOX copy of the renderer)
- **User ask:** "create new additional video, quick tips. 3 videos that will showcase important tips using odoo". Chosen tips: Ctrl+K command palette (type "/" + a menu name), multi-edit in a list view (tick records, edit one field, confirm, all update), schedule an activity from the chatter (type, due date, assignee, summary; shows on the record and in the clock menu; green planned / orange today / red overdue).
- **Sandbox pattern:** new Odoo screens need `ui.js` (an engine file), and changing it invalidates EVERY film's fingerprint, so it cannot happen while other films are mid-pipeline. The tips were designed, audited and rendered in `~/ClaudeWork/nexi-tips-sandbox` (a copy of web/ + *.py + patches/, sharing only `~/ClaudeWork/qa/nexi/cdp.py`). ui.js work ships as ONE idempotent patch (p35), registration as p36 (inserts into the tables instead of matching fixed lines). Port after the in-flight films are delivered.
- **A long reaction clip keeps playing under a new one:** `faint` (2.6 s) threw the hand-beam origin up to the HUD. Let long clips finish before any `handPx` beam (`zap`).
- **Shortcut keycaps** go on the window's empty, dimmed lower band, centred under the modal, never above Nexi (her big reactions would hit them).
- **Stylised Odoo text:** use 24-34 canvas px. The window maps about 0.78 screen px per canvas px, so the stock 15-17 px shows at about 12-13 px. The audit cannot see text inside the window texture, so judge it on the sheet.
- **Lenses:** a tight rect with `pad: 4`, or they pull in neighbouring controls.
- **Odoo-UI tip timing:** about 0.6 s per zap (lead + travel). Keep one tap per 0.5 s of speech; split a caption that carries more than three steps.
- **Facts kept conservative:** the clock-menu badge appears only when an activity is due today or late; the multi-edit dialog text is paraphrased ("Update the 3 selected records?").
- **True peak via an effect:** lowering an effect in the film means rebuild + re-audit + re-render; only MUSIC_GAIN / LIMIT changes are re-mux-only.

## 2026-10-04 · Owner's glitch audit, the website voice, episode names (all videos)
- **User asks (verbatim):**
  - "audit the new videos. check some visual error, glitches and lapses and do quick fix" (two screenshots: the floating magnifier, the put-away rack)
  - "make sure all videos have similar voicing/audio as https://technext.asia/nexi#full. the current audio are to sharp. allply audio update in all video."
  - "proeprly name the video file per episode so i can properly knwo what episode need to be posted first. apply to all video."
  - "remember, quick tips video are not included in the episode."
- **Glitches the measured audit could not see, now found by looking at the FINAL MP4** (`qa/mp4strip.py <film> t0 t1 step`):
  - **A held prop floated beside her hand** (the magnifier ~100 px out, handle pointing away). This was caused by my own brief to the agents ("pocket dx about 150 so the tag clears her body"). A held prop is GRIPPED: its grip point (handle end, near edge) sits at the hand. Draw the handle toward the hand and offset by the grip vector (magnifier: handle down-left, `pocket(MAG, 'R', 50, -50)`). Rule N8.
  - **A crate changed colour as it landed** (the rack painted placed crates by row). Placed objects keep their identity: colour, label, size. Rule P10.
  - **Blank flashes mid-whip** in most solution films (accounting 23.7 s, inventory 17.4 s, custom, apps, sales). Rule M1 itself caused them: the old station faded at +0.5 s, before a 1 s whip from +0.6 s had moved, and the next station was still off-frame. Stations at least 2000 px apart now keep the old scene until the camera lands (+1.7 s); only same-station swaps fade early. `qa/blank_scan.py` lists blank stretches from the audit data (it ignores the Odoo-window films, whose content is a 3D texture).
- **The website voice** (p40-p44): the video voice had the site's tones but boosted the square blips 4.6×, so the talking was a loud square buzz.
  - **Now:** the exact site chain (chirp .45/.38, blip .05, master .26, a Web Audio compressor emulation), VOICE_K 2.2.
  - **Music:** ×0.8, low-passed at 2.6 kHz.
  - **Effects:** ×0.5, low-passed at 5 kHz.
  - **Master:** a gentle compressor (8 dB under the peak, 6:1) so loudnorm still reaches -17.5 LUFS with a true peak at or below -2.
  - **Result:** the share of energy above 3.5 kHz fell from 12% to 5-8%.
  - **MUSIC_GAIN re-centred for every film** by `qa/music_tune.py`, which uses the gate's own A4/A5 formula with no mux.
  - **Films with effects packed into the gaps needed `FX_FILM`:** walk .38, beforeafter .26, web .2 (A3 voice ratio). Odoo + AI needed LIMIT .66 (A2).
  - **Try settings without touching out/:** `qa/audio_try.py <film> [K music fx]` (env: AT_MUSIC_LP, AT_FX_LP, AT_MASTER, AT_LIMIT).
- **An engine change makes old renders undeliverable through the full gate** (G1/G4/G7). An AUDIO-ONLY refresh is still legitimate: `deliver.py audio <film>` refuses unless the local video stream is bit-identical to the Drive file's (ffmpeg stream md5), then runs A1-A5. `qa/audio_batch.py films...` re-muxes and picks `copy` (full gate) or `audio` per film. All 25 videos were refreshed: 8 through the full gate (tip2-4, apps, accounting, custom, sales, inventory), 17 audio-only.
- **Episode names:** `deliver.EPISODES` (EP01-EP21, posting order, NO tips), `deliver.TIPS` (Quick Tip 01-04), `deliver.GROUP` (the series group for lint's solution checks and gate G6, which used to read the file-name prefix). `deliver.py rename` renames the Drive files (never deletes). Season 1 packaging follows `thumbs.ORDER` (10 episodes) + `thumbs.TIPS`; `deliver_series.py` moves old-numbered files to `_superseded 2026-10-04`. The cute shorts are `Short nn - <title>`.

## 2026-10-04 · Thumbnail redesign + one folder per post (all 25 posts)
- **User ask (verbatim):** "make sure the thumbnails and short video also in one folder" and "redesign the thumbnail, still use technext branding. but make it over exxagerated. if ned to use darker shade of blue for background do so. make sure thumbail still connected to the video content with elements. in thumbnail design, add number of episode." Rules H1-H6.
- **The design (p50/p51, `web/films/thumbs.js`):**
  - one deep TechNext blue for the whole series (`TNBG` #3F80F2 → #1846B8 → #050F30; Before vs After keeps a slate "before" half);
  - a cyan glow behind Nexi and on her sticker rim, and a giant ghost of the episode number behind her;
  - a bigger badge: TechNext logo strip (`L.IMG.logoH`), NEXI EXPLAINS / QUICK TIP strip, then EP nn / TIP nn up to 214 px (`fitSize`);
  - the 14 films without drawn art get a scene card cut from their own key frame, their costume, an Odoo tile and one "pow" prop (pill, stamp, keycaps, thermometer, moon + clock, wifi burst, calendar).
- **Raised hands covered the scene card** (automation's Approve step, the accounting banner). Fix: draw the card in the screen pass, in FRONT of Nexi. Her hand then reads as holding the screen from behind (H5).
- **Pills under the hook:** "3 RECORDS, 1 EDIT" sat under "EDIT MANY". Keep pills short (≤ 12 characters) and on the card's bottom-right corner.
- **On the 9:16 cover, Nexi's head hid the card.** Generic covers now put Nexi at y 1905 and the card at y 1122. Her face stays inside the 3:4 grid crop (y < 1680).
- **The bigger badge touched the hook on the vertical-video frame:** moved to y 168 at scale 0.82, with no format tag on covers or frames.
- **Never two Nexis:** crop the scene card so the in-video Nexi is outside it. The network castle frame was swapped for a tile where she stands at the side.
- **The number comes through the URL** (`thumbs.py` → `&ep=&qt=` from `deliver.EPISODES`): the p49 re-order had needed a regex edit of every `ep:` in thumbs.js.
- **Packaging (p52):** `deliver.DST` now points to `<base>/<base> (16x9).mp4`. `deliver_series.py` (rewritten):
  - moves the flat masters into their folders (a rename, not a re-copy of 700 MB);
  - renames renumbered folders by title;
  - copies the short, thumbnail and cover with md5 (78 files, 0 mismatches);
  - moved folder 24 to `00. old`.
  - `vertical.py` takes about 10 s per short (25 in about 4 minutes).
- **The Bash tool halved the backslashes again:** an escaped `\\n` in a patch written through `python - <<EOF` arrived as a real newline inside a Python string literal, so the patch would not run. Edit patch files with the Edit tool; never splice JS strings through a heredoc (K7).

## 2026-10-04 · EP00 series pilot "Meet Nexi" (new film `pilot`, 2:42, the longest film yet)
- **User ask (verbatim):** "create intro video about next explaining about technext and other services. make it as creative as possible. add more cinematic skills like telling a story. it's okay if it takes 2-5 minutes. also mention that nexi will gonna do episodic style about technext services specially odoo. scene just like recreating a anime /comics movie scene. make nexi more jolly and adorable., do alot of expression. do alot of analogy and costume and background scene. make interactive as possible."
- **The story (10 stations, 40 lines):**
  - **The book.** Nexi opens a comic book and dives into it (a white page-flash cut).
  - **The monster.** A Spreadsheet Monster attacks a night city. Nexi makes a hero landing in a drawn cape, then calls her crew with a paper-plane signal.
  - **The crew.** She rides the TechNext paper plane over three city cards: Singapore HQ, Taguig City (development and consulting), Ho Chi Minh City (AI engineering).
  - **Four power-ups**, each an anime/comic genre and a costume:
    - Odoo ERP: a combining robot made of app tiles (hard hat);
    - AI: a dojo power-up with an aura and three scrolls (goggles);
    - Marketing: an idol stage with light sticks (heart boppers);
    - Technology: a space cockpit (astro).
  - **The final battle.** ONE. SYSTEM. BEAM! turns the monster into paper planes at dawn, and the sample shop flips to OPEN.
  - **"Next time on Nexi Explains".** A TV studio with the episode grid, a comment-box poll and the NEXT EPISODE banner (bow tie).
  - **The CTA.** The comic's back cover: "Your story is next!".
  - **Interactive moments:** two "pause and guess" quizzes, light sticks + "drop a heart", "comment the episode number".
- **Facts** came from technext.asia `company`, the home page and `solutions/*` (C2). The quiz answers follow the site: one database; a person approves.
- **Full-frame backgrounds work:** back props draw after the 3D set (engine.md). The first cape was invisible because its prop was registered BEFORE the background painter. Register order = draw order.
- **First audit: 16 HIGH**, mostly comic lettering: a drop layer drawn as a second word 7 px lower reads as "X overlaps X". Fixed by T11 (the drop is the outline's shadow; bursts are sized from the word).
- **Then the pre-gate failed on off-centre groups (6 stations, 3-6 s each).**
  - Cause: cards were revealed one per line (crew, dojo, stage, space).
  - Cause: the monster, the biggest thing on screen, was unlabelled.
  - Fix: F9 (whole set on landing, highlight per line) and P11 (a name box for the monster).
- **A half-open scroll clips its lower lines** ("overflow" + "covered" HIGH). A line now shows only once the paper has unrolled past it.
- **Zoom stays honest:** a 1.18 push-in on the book would have put Nexi's centre at x 216. Do the framing math for every camera move, not only for resting frames.
- **B5 exception (owner):** the pilot changes costume per scene. Episodes keep one costume.
- **Audio passed first time with 10 score changes** (MUSIC_GAIN .34, LIMIT .68): -17.9 LUFS, -3.2 dBTP, voice ratio 6.5x, music 11.1 dB under the voice (4.7 dB in the gaps). Effects stayed at or below 0.5 and started at line starts.
- **Packaging (p54):** EP00 is first in `thumbs.ORDER`, number 0. Its scene card is the monster scene (tile 1, 20.2 s, Nexi cropped out); its hook is MEET / NEXI!. A thumbnail cape was tried and removed: at thumbnail zoom her body hides it, and only two edge lines show. Drawn body parts don't read at a 2.3x close-up.
- **Delivered:** `22/EP00 - Meet Nexi - Series Intro/` (16:9 63 MB, 9:16 27.7 MB, thumbnail, cover). 81 files were md5-checked. Posting plan: EP00 first, pinned.

## 2026-10-04 · EP00 pilot v2: the redesign (cinematic, reactive, cel-shaded; 3:29)
- **User feedback on v1 (verbatim):**
  - "redesign some parts, make it interactive and connected to nexi fix some comic style of design, it's ugly. make a creative designing on this parts. do proper cinematic style of story telling. you can slow down explaining things and give time to viewers to absorb information thru animation."
  - "make sure there's a exaggeration effect in every reaction. make nexi reactive."
  - "also redesign this part" (the idol stage).
  - The screenshots flagged: the crew map and plane ride, the "Four TechNext powers" card, the Odoo robot, the AI dojo scrolls, the tech space panels, the night city / monster / BOOM / cape, and the idol stage.
- **What was ugly in v1:** flat clip-art shapes (single rectangles and circles, one tone), a card that listed the four powers instead of showing them, a robot that stood next to Nexi instead of forming around her, scrolls with placeholder lines, panels that were finished before she spoke, and comic words drawn as plain text.
- **v2 (13 stations, 46 lines, 3:29; was 10, 40, 2:42).** Rebuilt as four files in `qa/pilot_v2/` (p1 head and kit, p2 worlds, p3 scenes, p4 script), concatenated into `films/pilot.js` (v1 is `qa/pilot.v1.js`).
  - **The kit (engine.md):** `react()`, `glyph()`, `focus()`, cached `sfxWord` sprites, `cel()`/`shine()`, `drawCape()`, `transform()`.
  - **Night city:** sky, stars, moon and clouds, then far, mid and near skylines, a hero rooftop and a street with lamps.
  - **The monster:** three spreadsheet sheets with sticky-note spikes, rolled-paper arms and a face. It eats order slips (CHOMP), and #REF!, #N/A and TYPO! fly out.
  - **The crew:** Nexi rides the paper plane (it sits right under her). Three islands, each with its city's skyline, a boarding pass and a stamp (HQ / DEV HUB / AI HUB). Then a globe with pins: "Three offices, one team", "Clients in 10+ countries".
  - **The power chamber:** four crystals and a POWER meter (0/4 to 4/4), so the four services are earned one by one instead of listed on a card.
  - **Odoo:** the armour docks onto Nexi part by part, with a database window in the torso. An order token travels Confirmed, Shipped, Invoiced ("One database").
  - **AI dojo:** each scroll unrolls into a working demo. A PDF becomes a vendor-bill draft ("Prepared by AI · a person approves"). A chatbot answers at 11:42 pm. A knowledge answer cites its source ("Expense policy, page 2"). An approval card shows S$48,000.
  - **Idol stage (redesigned on request):** a truss, an LED wall and a crowd with light sticks. Three screens (Websites, Social media, Brand assets) light up as she sings about each one. She holds the mic, and a heart counter climbs.
  - **Cockpit:** she flies it. The holo panels build while she explains: an IoT chart with its 5 °C limit and "Alert sent"; a customer app and a staff app on a phone; a network with Staff, Printer and Guests, where "Guests: internet only".
  - **Final battle:** the beam leaves her hand and hits the monster's mouth. The monster bursts into paper planes (KA-BOOM), the shop sign flips to OPEN, and HAPPY ENDING! appears.
- **Every line has a `react()` beat** (46/46; the new `lint:N10` counts film functions such as `transform()`). Big beats add a sprite SFX word.
- **Pacing:** `hold` 0.3–0.5 s on every line. Each station opens with an establishing beat. Builds run during their line.
- **Sheet review found (fix_a.py):**
  - The plane floated below her (y +240): moved to +196 and made 1.45x bigger.
  - A stamp sat on the role text: the boarding pass is now sized from the measured texts + 330 px.
  - The order card covered the Inventory arm: moved, and made 40 px narrower.
  - The meter count touched its edge: widened the card.
  - The moon window was cut off by the frame: moved inside.
  - **The stage screens and cockpit panels were finished before their lines.** The start times were initialised to -9, so `t - (-9)` was past every step. Fixed: K9.
  - A network-ring `%` went negative.
  - The beam crossed the shop sign: it now aims at the mouth.
- **Pre-gate failed:** the city was off-centre from 19.3 to 24.0 s, before any label existed. Fixed with a comic narration box, "MEANWHILE, IN THE CITY" (fix_b.py, F10).
- **Measured audit:** 0 HIGH, 15 medium, 76 low. Pre-gate PASS. Strips A and B looked right.
- **New rules:** N10 (reactions, `lint:N10`), N11 (scene connected to Nexi), M12 (pacing), P12 (cel-shaded art), T12 (sprite words are not measured), F10 (frames on landing, content during the line), K9 (builds start at 1e9).
- **N10 on the older films (warn only, so they still build):**
  - lines with no reaction: crm l3 l6 l8 l9; automation l2 l5 l7; enterprise l3 l6 l9; apps l4 l8; accounting l5; brand l4; erp l7; iot l6; network l6; sales l10;
  - most films react without an accent.
  - Fix these when each film is next re-rendered (ROUND2-TODO).
- **MP4 review (frames from the encoded file, not the audit) found one pacing lapse.** The AI-agent demo finished 1.7 s after its line. "Prepared by AI · a person approves" (the key message, and the later quiz answer) was on screen for about 0.7 s before the chatbot demo replaced it. Fix (fix_c.py): the demo starts at line + 0.6 s instead of + 0.9 s, and its steps are tighter (spin 1.1–2.0, fields 1.8 + 0.3·i, chip at 3.1). The chip now shows for about 2 s. **Check the hold of every key chip: the time from its appearance to the next scene swap must be 1.5 s or more** (the chatbot and knowledge source chips: 1.9 s).
- **A parallel session broke the first render's gate.** Another chat ("Nexi social media banners") added `web/assets/channel/*.jpg` during the render. The fingerprint hashes all of `web/assets`, so G4 and G7 failed. The pilot was re-audited and re-rendered (never adopted), the peers were messaged to hold asset writes, and rule G11 was added. The same trap applies to our own packaging: `tf_extract`/`tf_crop` write `web/assets/thumbframes/`, so run them only AFTER `deliver.py copy`.

## 2026-10-04 · Channel art: YouTube banner, Facebook cover, profile picture (stills, `channel/`)
Owner: "create a facebook banner, youtube banner and profile picture where nexi is a main character. also mention in banner about the nexi episode video."
- **Built as a still "film"** in `~/ClaudeWork/nexi-tutorial/channel/`:
  - `channel.py` writes `web/films/channel.js` = the helper half of `films/thumbs.js` (everything above `var EPS`) + `channel/channel_body.js`.
  - Then it builds and renders `film.html?v=channel&fmt=yt|fb|pp|ppl` and grabs `window.PC` at 1.9 s.
  - `--guide` draws the safe zones; `fmt@tag?zoom=&nx=&ny=&pj={json pose}` renders variants for pose tests.
  - `preview.py` builds the crop mock-up; `deliver_channel.py` copies to `00. TechNext Folder/25. Nexi Channel Art` with an md5 check.
- **Placing Nexi on any canvas size:** render her into glcv at (960, gy) with `CAM.zoom` set to the size you need, then `drawImage(glcv)` translated so (960, gy) lands on the target. Render at native size (zoom), not by scaling the bitmap, so she stays sharp. Hand units: about 375 px per unit per 1.0 zoom; `hL` is screen-left.
- **Poses that worked:**
  - `show` (right hand behind the episode-card stack; the cards draw in front, so she "holds" them);
  - `hi` (right hand waving beside her head; profile picture).
  - A hand raised to 2.0 leaves the YouTube band and the profile circle.
- **Profile picture:** draw the ring first, then Nexi clipped to (inner circle ∪ the outer circle below y 700). Her body pops out over the lower ring, as on the staff photos.
- **Episode mention:**
  - the real delivered thumbnails (folder 22) as cards: EP00 in front with a play button;
  - a "NEW EPISODES WEEKLY" pill;
  - on Facebook, "21 EPISODES";
  - on YouTube, the TV-only areas show the whole season as dimmed film strips, with no episode shown twice.
- **MISTAKE: I broke a parallel session's gate.**
  - I first put the art assets in `web/assets/channel/`. `gate.fingerprint()` hashes every file under `web/assets`, so the EP00 pilot audit then running in another chat was stamped with my files in place.
  - Moving them out later broke it a second time. The fix was to restore an identical copy (same names and sizes), which brought back the pilot's fingerprint, and to tell the peer sessions.
  - **Rule H7:** non-film art and its assets never go under `web/assets`; use `web/channel-art/` or similar. If you already wrote there, don't delete it while anyone's audit or render could depend on it: compare `gate.fingerprint(<film>)` with `qa/audit/<film>/meta.json` first.

# Lessons log

Append a dated entry after every video job: newest at the bottom, one bullet per lesson. When a lesson becomes a rule, also copy it into `design-rules.md`.

## 2026-10-03 · Odoo walkthrough + topic series (walk, myth, tip, reorder, beforeafter)
- **User asks:** cinematic, intro like the website logo animation, a floating "with Nexi" tag, robot voice, exaggerated acting, floating Odoo icons.
- **Fixes to the look:**
  - Lowered the floor-grid and flare opacity.
  - Use the plain Odoo logo, never "Odoo Ready Partner".
  - Nexi faces the viewer.
  - Music upbeat per topic, never loud.
  - Same intro and outro with a new touch per video.
- **Audit 1** (the user said "a lot of design lapses"):
  - Badge slots sat above the wordmark.
  - The HUD plate had to be opaque.
  - The caption card needed a fixed width.
  - The Odoo window had to sit in a safe-area pose.
  - Nexi needed her own lane beside the window: clicks become beams (`zap`), spotlights and a lens replace crop-zooms, `tether` handles drags.
  - Chapter bands were drawn before Nexi.
  - The intro exit is a crossfade, not an iris.
  - Shatter effects were reduced to a two-piece tear.
  - Report data had to be consistent across screens.
- **Audit 2:**
  - Myth/fact cards must not sit in a corner (centred pair).
  - The logo must be centred in intro and outro.
  - "with Nexi" must look as in the walkthrough.
- **Audio:**
  - The voice was buried 14 dB under the music. Fixes: ducking 62 %, voice ×1.9, blips ×4.6.
  - Loudnorm needs an alimiter. The walkthrough needs limit 0.7.
  - Measure with `_buslevel.py`.
- **Engine:**
  - Glow-pass mesh lists are cached for 240 frames.
  - Chip pop-ins must use per-item timestamps, not a tween's end value.
  - Never tween a whole array.
  - Avoid leading "..." in a caption line: the voice pauses on dots.

## 2026-10-03 · Solution videos round 1 (erp, crm, enterprise, web, social, brand)
- **User asks:**
  - Nexi roams the whole area.
  - More dynamic reactions.
  - Not cornered.
  - More camera movement and angles.
  - More interactive.
  - Analogies, role-play, new and random elements.
  - Every video unique.
- **Built engine v2:**
  - A camera mirrored into 3D, so Nexi stays sharp when zoomed.
  - `fly`/`hop`/`orbit`, `thing` + `grab` + `toss`, 3D costumes, `quiz`.
  - A marketing end card.
- **Bugs fixed:**
  - Depth must pivot around the camera centre, not the frame centre. Without it, Nexi at z ≠ 0 drifted up to 400 px on long sets.
  - Costumes must be built before the first frame, or the glow pass blooms them white.
  - Costume colours need `convertSRGBToLinear`.
  - World props drew over the intro/end-card logo. Added `WORLDOFF`.
  - Filtering the mover list while pushing to it dropped `fly()` calls made inside movers.
- **Staging lessons:**
  - The quiz card covered the plane: hold the plane mid-air during the quiz and land it on the reveal.
  - The quiz card covered the logos being counted: added the wide layout.
  - Nexi stood behind the CTA card: put the CTA beside her, or pop it after she lands.
  - The stale-lead train was off-camera during its line: place story props where the camera will be when the line plays.
  - `bellkey` FM music flooded the voice band (voice ratio 2.6×). Low-passing it gave 4.8×.
  - A render died with "F is not defined" because an outside process killed Chrome. Rerun.

## 2026-10-03 · Solution videos round 2 (user review)
- **User feedback (verbatim):**
  - "some text are overlapping, small and hard to read. maximize the designing of the element" (social)
  - "improve presentation design and camera works. design should be visually appealing and eye catching, even the sample format that showcased" (brand)
  - "fix the mobile design … 0:45 the design are too low" (web)
  - "we dont have malaysia. revise the explanation and make it truthful … explain technext and do also sample company" (enterprise)
  - "0:23 there some blocking in middle station" (crm)
  - "text overlapping" (erp)
  - "in all outro, let nexi to much in the corner. make sure to make nexi will change location every video"
- **Rules added:**
  - Minimum on-screen text sizes.
  - Labels fit their boxes.
  - Nexi never in front of text being read; flight paths route around text.
  - Stacks the viewer reads go in the back layer.
  - Story props never park on signs.
  - The phone sample is fully in frame at real proportions.
  - Hand-over scenes stay above the caption band.
  - Truthful company facts: TechNext is SG HQ plus PH and VN teams, 10+ countries delivered, no Malaysia. Use a labelled sample company for demos.
  - Outro spot per video.
- **Outro spots tested:** `top` (above the wordmark), `left`, `right`, `below` (under the CTA row), `leftlow`, `rightlow`, all clear of the logo and CTA rows. The old right spot (1712, 610) read as cornered.

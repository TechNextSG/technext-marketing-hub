# Lessons log

Append a dated entry after every video job: newest at the bottom, one bullet per lesson. When a lesson becomes a rule, also copy it into `design-rules.md`.

## 2026-10-03 · Odoo walkthrough + topic series (walk, myth, tip, reorder, beforeafter)
- **User asks:** cinematic, intro like the website logo animation, a floating "with Nexi" tag, robot voice, exaggerated acting, floating Odoo icons.
- **Fixes to the look:**
  - Lowered the floor-grid and flare opacity.
  - Use the plain Odoo logo, never "Odoo Ready Partner".
  - Nexi faces the viewer.
  - Music upbeat per topic, never loud.
  - Same intro and outro with a new touch per video.
- **Audit 1** (the user said "a lot of design lapses"):
  - Badge slots sat above the wordmark.
  - The HUD plate had to be opaque.
  - The caption card needed a fixed width.
  - The Odoo window had to sit in a safe-area pose.
  - Nexi needed her own lane beside the window: clicks become beams (`zap`), spotlights and a lens replace crop-zooms, `tether` handles drags.
  - Chapter bands were drawn before Nexi.
  - The intro exit is a crossfade, not an iris.
  - Shatter effects were reduced to a two-piece tear.
  - Report data had to be consistent across screens.
- **Audit 2:**
  - Myth/fact cards must not sit in a corner (centred pair).
  - The logo must be centred in intro and outro.
  - "with Nexi" must look as in the walkthrough.
- **Audio:**
  - The voice was buried 14 dB under the music. Fixes: ducking 62 %, voice ×1.9, blips ×4.6.
  - Loudnorm needs an alimiter. The walkthrough needs limit 0.7.
  - Measure with `_buslevel.py`.
- **Engine:**
  - Glow-pass mesh lists are cached for 240 frames.
  - Chip pop-ins must use per-item timestamps, not a tween's end value.
  - Never tween a whole array.
  - Avoid leading "..." in a caption line: the voice pauses on dots.

## 2026-10-03 · Solution videos round 1 (erp, crm, enterprise, web, social, brand)
- **User asks:**
  - Nexi roams the whole area.
  - More dynamic reactions.
  - Not cornered.
  - More camera movement and angles.
  - More interactive.
  - Analogies, role-play, new and random elements.
  - Every video unique.
- **Built engine v2:**
  - A camera mirrored into 3D, so Nexi stays sharp when zoomed.
  - `fly`/`hop`/`orbit`, `thing` + `grab` + `toss`, 3D costumes, `quiz`.
  - A marketing end card.
- **Bugs fixed:**
  - Depth must pivot around the camera centre, not the frame centre. Without it, Nexi at z ≠ 0 drifted up to 400 px on long sets.
  - Costumes must be built before the first frame, or the glow pass blooms them white.
  - Costume colours need `convertSRGBToLinear`.
  - World props drew over the intro/end-card logo. Added `WORLDOFF`.
  - Filtering the mover list while pushing to it dropped `fly()` calls made inside movers.
- **Staging lessons:**
  - The quiz card covered the plane: hold the plane mid-air during the quiz and land it on the reveal.
  - The quiz card covered the logos being counted: added the wide layout.
  - Nexi stood behind the CTA card: put the CTA beside her, or pop it after she lands.
  - The stale-lead train was off-camera during its line: place story props where the camera will be when the line plays.
  - `bellkey` FM music flooded the voice band (voice ratio 2.6×). Low-passing it gave 4.8×.
  - A render died with "F is not defined" because an outside process killed Chrome. Rerun.

## 2026-10-03 · Solution videos round 2 (user review)
- **User feedback (verbatim):**
  - "some text are overlapping, small and hard to read. maximize the designing of the element" (social)
  - "improve presentation design and camera works. design should be visually appealing and eye catching, even the sample format that showcased" (brand)
  - "fix the mobile design … 0:45 the design are too low" (web)
  - "we dont have malaysia. revise the explanation and make it truthful … explain technext and do also sample company" (enterprise)
  - "0:23 there some blocking in middle station" (crm)
  - "text overlapping" (erp)
  - "in all outro, let nexi to much in the corner. make sure to make nexi will change location every video"
- **Rules added:**
  - Minimum on-screen text sizes.
  - Labels fit their boxes.
  - Nexi never in front of text being read; flight paths route around text.
  - Stacks the viewer reads go in the back layer.
  - Story props never park on signs.
  - The phone sample is fully in frame at real proportions.
  - Hand-over scenes stay above the caption band.
  - Truthful company facts: TechNext is SG HQ plus PH and VN teams, 10+ countries delivered, no Malaysia. Use a labelled sample company for demos.
  - Outro spot per video.
- **Outro spots tested:** `top` (above the wordmark), `left`, `right`, `below` (under the CTA row), `leftlow`, `rightlow`, all clear of the logo and CTA rows. The old right spot (1712, 610) read as cornered.

## 2026-10-03 · Solution videos round 2 (fixes delivered)
- **What changed per video:**
  - **ERP:** crates moved to the back layer, away from Nexi, with bigger labels; the slab was widened so every label fits; the stamp fades when the floors land. Nexi switches sides by flying *up and over* the house (out of frame) instead of across the floor text, and throws the go-live scissors. Cable labels are drawn after all cables. End spot `top`.
  - **CRM:** the Projects train was parked on the middle branch sign. It now waits between stations. The quiz uses the new two-row wide band at the top so the signs stay visible. Small text was bumped to 17–22. End spot `left`.
  - **Enterprise:** the line "Our group… Malaysia" implied TechNext's own group. The film now opens with a TechNext crew card (facts from the live site: Singapore HQ; Philippines hub in Taguig for Odoo development and consulting; Vietnam hub in Ho Chi Minh City for AI engineering; clients in 10+ countries). The demo then uses a "Sample group · illustrative" (Singapore holding, Philippines and Vietnam companies) with an on-screen tag. There is no Malaysia anywhere. End spot `below`.
  - **Web:** the phone was a tall strip. It is now a real phone (300×616, about 1:2) in frame with phone-scale type; the page scrolls inside it to the form. The hand-over scene was raised to mid-frame and enlarged. End spot `right`.
  - **Social:** full readability redesign:
    - planter labels on the bed fronts;
    - a week × channel plan instead of a 31-day grid;
    - a big sample post with the quiz in the top band;
    - three big sample tiles, a proper gate, a bigger basket and report.
    - End spot `leftlow`.
  - **Brand:** five realistic sample formats (card 340×200, 16:9 slide, 4:5 post, roll-up, signature) in off-brand and on-brand versions. Nexi rides the clothes rail like a zipline so she never covers an asset. A full-frame style guide shows tokens, then components. End spot `rightlow`.
- **Engine lessons:**
  - **Film globals must not reuse engine names.** A crew card constant `CH` overwrote the engine's chapter state and crashed `drawChapter`. Check the list in `engine.md` before naming.
  - **`fly()` follows a spring (`N.go`), so Nexi cuts corners.** Give waypoints 250 px or more of clearance around text, and keep long paths at about 1300 px/s or slower. Check mid-flight frames.
  - **A `thing` created at world (0,0) glides across the whole frame when grabbed.** Use `pocket(o, hand)` to place it at her hand first.
  - **Draw labels after connecting lines** (cables, pipes), or a later line crosses an earlier label.
  - **Three-line captions lift the caption top to about y 720.** Keep lines at 86 characters or fewer when content sits low. The top is about 880 for one line and 835 for two.
  - **`bigjump` lifts Nexi about 330 px.** Near the top of the frame, use a small cheer (`excited` + sparks) instead.
  - **When the camera follows, clamp its y** so screen-fixed bars (step bars) don't land on the subject.
- **Audio lessons:**
  - True-peak overshoots came from single sharp effects: a `snip` at 0.9, and a `jet` under voice blips. Find them with `qa/_peaks.py <name>`, lower that effect in `out/events-<name>.json` and in the film, then re-mux. Changing `render.LIMIT` trades loudness for peak.
  - The `qa_av` voice ratio counts whooshes placed between lines (correct placement). Read the gap list in `_peaks.py` before "fixing" a low ratio. Web stayed at 2.1× for this reason, with music 10.6 dB under the voice.
- **End-card spots across the six solution videos:** `top`, `left`, `below`, `right`, `leftlow`, `rightlow`. On the marketing end card the link row spans x 426–1500, so low spots must stay outside it (x ≤ 300 or ≥ 1640).

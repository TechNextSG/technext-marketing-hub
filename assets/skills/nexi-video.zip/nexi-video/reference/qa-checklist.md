# QA checklist

Run this on every contact sheet, before the final render and again on `deliver.py sheet`. Include transition frames (mid-flight, mid-whip, card popping in), not only rest frames.

## Frame audit (each frame)
- [ ] **Readable text.** Every word I'd expect a viewer to read is at least 18 px on screen and inside its box.
- [ ] **No overlaps.** No text overlaps other text, Nexi, a quiz card, the caption or the HUD.
- [ ] **Nexi visible.** She is not hidden behind a front-layer prop, not cut by the frame (unless rising in), and not in a corner.
- [ ] **Balanced composition.** Nothing parked in a corner, and the frame is not lopsided-empty.
- [ ] **Quiz.** The subject of the question stays visible, and Nexi stands beside the card.
- [ ] **Clean intro and end card.** No world props on the logo, the logo is centred, and Nexi is at this video's spot.
- [ ] **Clean edges.** No leftovers from a previous scene (blueprint slivers, old cards, faded maps) peeking in at the edges.
- [ ] **Truthful content.** Real TechNext facts are correct; samples are labelled; no invented claims.
- [ ] **Caption sync.** The caption matches the beat on screen. The first word isn't "...", and no line sits blank for over 0.5 s.

## Motion audit (scrub the sheet in order)
- [ ] **Clean flight paths.** They don't cross the text being read. Route over or under.
- [ ] **Camera.** Moves happen between beats, it holds while text is read, and there are no jumps.
- [ ] **Props in hand.** Held props glide into the hand (`grab`); nothing teleports.
- [ ] **Movers.** Movers launched inside movers run. If Nexi "freezes", check that `fly()` was actually called.
- [ ] **Corner cutting.** Look at frames in the middle of every long flight. The spring cuts corners, so check she clears labels, not just the waypoints.
- [ ] **First frames of held props.** No prop glides in from the top-left (world 0,0); use `pocket()`.
- [ ] **Caption line count.** Where content sits low, check the frame during the longest caption (three lines reach y 720).

## Audio
- [ ] Loudness is −16.8 to −17.6 LUFS.
- [ ] True peak is −2 dBFS or lower.
- [ ] Voice ratio is at least 3.5× (`qa_av.py`).
- [ ] Music sits 10–12 dB under the voice and 4.5–6 dB under it in the gaps (`_buslevel.py`).
- [ ] If the true peak or voice ratio misses, run `qa/_peaks.py <name>` to see which effect causes it before touching the limiter.
- [ ] No sound effect drowns a word. Long noise effects (jet, whoosh, crane) go between lines.

## Delivery
- [ ] `deliver.py copy` reports "drive OK" (md5 matched).
- [ ] The file was sent to the user right away with a short caption.
- [ ] `sync_source.py` was run after the batch.
- [ ] The skill was updated: `lessons.md`, rules and the engine notes. The hub skills page was rebuilt and pushed.

## Measured audit (mandatory since 2026-10-04)
- [ ] `render.py audit 5` + `layout_audit.py <name>`: **zero static HIGH findings**; every medium finding read and either fixed or judged motion-only.
- [ ] `qa/_strip.py <name> 2.5` viewed end to end: no empty frames, no lopsided groups, every scene designed (not just "no overlaps").
- [ ] Re-run the audit after ANY change that moves Nexi, the camera or a card. A contact sheet is not a re-audit.
- [ ] What the rules mean: `overflow` text over its box edge · `tight` under 3 px (HIGH) or 8 px of padding · `covered` hidden in part by a later shape · `overlap` text on text · `line` a connector through text · `cut` text or a text card cut by the frame while the camera holds · `small` under 17.5 px on screen · `nexi-text` Nexi over or under text · `nexi-edge` Nexi cut by or within 100 px of the frame edge · `cards` two text cards partly overlapping · `offcentre` a resting group more than 160 px off centre.
- [ ] Known intended findings: chapter bands sliding in from the edge (walkthrough), carried mini props, the outro's plane arc, a deliberately messy paper pile.

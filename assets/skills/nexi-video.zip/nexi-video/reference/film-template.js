  /* ======================= <SERIES> · <TOPIC>: <the analogy in five words> (~60 s) =======================
     One paragraph: the analogy, the role Nexi plays, the beats, the quiz, the call-to-action object.
     Composition: say where Nexi and the cards live; nothing in a corner. */
  var TOTAL = 0;
  var GREEN = '#21A366', GREEN_L = '#E3F5EC', CORAL = '#E0456B', AMBER = '#F3B700', NAVY = '#1E3A6E';
  var STATION_A = 1200, STATION_B = 2600, STATION_C = 4000;          /* world x of each set piece (the camera travels) */
  function hud(t) { HUD.chap = { n: 0, title: t }; HUD.chapT = window.T; }
  function cheer() { EMO = []; N.play('bigjump'); E.star(1.8); var b = N.botPx(); L.sparks(b.x, b.y - U * 0.5, 14, 700, ['#FFD25E', '#fff', '#8FC0FF']); sfx('tada', 0.6); sfx('boing', 0.5); }

  /* ---------------- set pieces (one prop per piece; text >= 22 px on screen at its camera zoom) ---------------- */
  var A = { a: 0 };
  prop({ on: true, back: function (gg) {
    if (A.a <= 0.01) return; var w = 700, h = 420, x = STATION_A - w / 2, y = 200, e = L.back(clamp(A.a, 0, 1), 1.6);
    gg.save(); gg.translate(STATION_A, y + h / 2); gg.scale(e, e); gg.translate(-STATION_A, -(y + h / 2));
    KIT.card(gg, x, y, w, h, { r: 26 }); L.text(gg, 'Card title', x + 36, y + 56, 36, C.ink, 800, 'left');
    gg.restore();
  } });
  /* things Nexi handles */
  var ITEM = thing({ a: 0, layer: 'back', draw: function (gg) { KIT.chip(gg, 'Item', 0, 0, C.blue, '#fff', 24, { edge: 'rgba(111,160,245,.5)' }); } });
  /* the call-to-action object (unique per video) */
  var CTA = { k: 0 };
  prop({ on: true, front: function (gg) { if (CTA.k <= 0.01) return; /* draw beside Nexi's final spot, never over her */ } });

  introSeq({ sub: '<Subtitle>', hud: '<HUD title>', pills: [['crm', 'CRM'], ['sale', 'Sales'], ['account', 'Invoicing']], nx: 720, ny: 600,
    extra: function (gg, t) { var q = clamp((t - 2.45) / 0.4, 0, 1); if (q <= 0) return; var sl = Intro.slotL(); badge(gg, '<Role badge>', sl.x, sl.y, { col: C.blue, icon: 'hardhat', rot: 0.05, k: L.back(q, 2.2), fs: 34 }); } });

  /* ======================= SCRIPT ======================= */
  at(cur - 0.05, function () { cam({ x: STATION_A - 150, y: 500, zoom: 1.05 }, 1.2); fly([[STATION_A - 600, 560, 1]], 1.0); });
  var l1 = say('Opening line with the **hook**.', { hold: 0.4 });
  at(l1.t0 + 0.1, function () { wear('hardhat'); N.play('salute'); });
  at(l1.w('hook'), function () { L.tween(A, { a: 1 }, 0.5); sfx('pop', 0.7); RX.hmm(); });
  /* … one beat per line: camera move, Nexi move, prop animation, sound … */
  var lq = say('Quick! The **question**?', { hold: 0.1 });
  at(lq.end - 0.3, function () { quiz({ q: 'The question?', opts: ['A', 'B', 'C'], ans: 1, t: 3, side: 'right' }); N.play('think'); });
  wait(3.2);
  var lr = say('**B!** Because…', { hold: 0.4 });
  at(lr.t0, function () { quizReveal(); cheer(); });
  at(lr.t0 + 1.1, function () { quizOff(); });
  var lc = say('Call to action. **TechNext** will help.', { hold: 1.4 });
  at(lc.t0, function () { hud('Get started'); cam({ x: STATION_C, y: 470, zoom: 1.0 }, 1.0); fly([[STATION_C + 330, 560, 1]], 1.0); later(0.95, function () { L.tween(CTA, { k: 1 }, 0.5); sfx('pop', 0.8); }); });
  cur += 0.1;
  outroSeq({ nexi: 'left', extra: function (gg, t) { var q = clamp((t - 2.9) / 0.4, 0, 1); if (q <= 0) return; var sl = Intro.slotL(); badge(gg, '<Outro badge>', sl.x, sl.y, { col: GREEN, icon: 'hardhat', rot: -0.05, k: L.back(q, 2.2), fs: 34, ring: 'rgba(33,163,102,.3)' }); } });
  at(END0 + 2.75, function () { sfx('pop', 0.5); });

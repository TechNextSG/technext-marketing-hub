# Design rules (every frame)

These came from user audits. Breaking any of them is a defect.

## Frame and safe areas (screen px, 1920×1080)
- **The HUD** sits top-left (x < 260, y < 140). Nothing important goes under it. Pops are clamped away from it.
- **The caption card** is 1180 px wide, bottom-centred, with its top edge at about y 850–880. Nothing the viewer must read sits behind it. Nexi's body stays above y ≈ 830 unless she is deliberately rising from the bottom.
- **Margins:** keep subjects 120 px or more from the left and right edges. Frame edges are not resting places.
- **Composition:**
  - Default pair: Nexi centre-left (~470) with the card centre-right (~1215), or the mirror image.
  - With three elements (Nexi, card, prop), spread them across thirds.
  - Never park a card or Nexi in a corner, including in end cards.

## Text
- **Minimum on-screen sizes, after camera zoom:**
  - headings 34 px;
  - key information 22 px;
  - labels 18 px;
  - tiny decorative text only when it doesn't need reading.
  - World size × zoom = screen size. A 20 px label at zoom 0.75 shows at 15 px, which is too small.
- **Fit:** text never overflows its box. Measure with `gg.measureText` and widen the box, wrap, or shrink the font.
- **Overlap:**
  - text never overlaps other text or Nexi;
  - a front-layer prop with text must not sit on Nexi's spot;
  - Nexi must not stand in front of text the viewer is reading.
- **Fonts:** Plus Jakarta Sans 800 for display, Inter 600–700 for body, Caveat only for the intro subtitle and deliberately messy samples. Ink is `#1F1F3D`, body text `#4C4C63`, TechNext blue `#3167CA`.

## Cards and props
- **Card style:** white cards with a soft blue shadow and a 3–4 px `rgba(111,160,245,.45)` edge, radius 18–34.
- **Size:** content in a card is generous. If a card has more than five lines of text, split it or zoom in.
- **Samples:** sample formats (business cards, slides, phones, posts) must look like real, attractive designs at a readable size. A phone shows full proportions (about 9:19) and fits entirely in the frame.
- **Labels:** labels on stacked props (crates, cards) sit inside the prop and are large enough to read.
- **Sample data:**
  - Numbers on screen are sample figures and are labelled "sample".
  - Client names are fictional (Bluebay Trading, Lintel & Co., Manila Trading).
  - Never present a sample as TechNext's own facts.

## Nexi
- **Moving:** she roams. Every beat moves her somewhere meaningful (fly, hop, ride, carry), and she faces the viewer when she speaks (the default gaze).
- **Positions:** her target positions are chosen with props in mind. Check mid-flight frames: a flight path must not cross reading text. Route it above or below.
- **Costume:** one per video, kept on through the outro.
- **Reactions:** big. Shock, panic and laugh use speed lines, shake and emotes. Use sparks rather than confetti when cards with text are on screen.

## Camera
- **Grammar:** establishing wide, push-in on a detail, whip pan to the next station, track a moving subject, crane up for builds, pull back for reveals, a dutch tilt for comedy.
- **Still for reading:** hold the camera still, or nearly so, while a card is read. Move between beats.
- **Zoom range:** 0.7–1.4 for most shots. Below 0.75 the text gets small, so scale world text up for overview shots.

## Viewer quiz
- **One per video:** 3 s countdown, then reveal and cheer.
- **The subject stays visible:** the quiz must not cover what it asks about. Use `layout: 'wide'` (top or bottom band) or put the card on the empty side.
- **Placement:** Nexi stands beside the quiz, never behind it.

## End card
- **Logo:** centred; "with Nexi" at the right slot; the video's badge at the left slot.
- **Nexi's spot:** one of `top`, `left`, `right`, `below`, `leftlow` or `rightlow`, and a different one from the previous video in the batch.

## Audio
- **Music:** one style per topic. Beds sit 10–12 dB under the voice, about 5 dB under it in the gaps, measured with `_buslevel.py`.
- **Timbre:** bright FM or bell tones flood the 2–4 kHz voice band. Low-pass them.
- **Levels:** loudness about −17 LUFS; true peak ≤ −2 dBFS (`render.LIMIT` 0.7); voice ratio ≥ 3.5×.

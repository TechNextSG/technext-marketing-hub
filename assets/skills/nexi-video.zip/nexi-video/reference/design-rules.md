# Design rules (every frame)

These came from user audits. Breaking any of them is a defect.

## Frame and safe areas (screen px, 1920×1080)
- **The HUD** sits top-left (x < 260, y < 140). Nothing important goes under it. Pops are clamped away from it.
- **The caption card** is 1180 px wide, bottom-centred, with its top edge at about y 850–880. Nothing the viewer must read sits behind it. Nexi's body stays above y ≈ 830 unless she is deliberately rising from the bottom.
- **Margins:** keep subjects 120 px or more from the left and right edges. Frame edges are not resting places.
- **Caption height:** the caption's top edge is at about y 880 for one line, 835 for two and 720 for three. Keep anything the viewer must see above it, or shorten the line. Two lines hold about 86 characters.
- **Composition:**
  - Default pair: Nexi centre-left (~470) with the card centre-right (~1215), or the mirror image.
  - With three elements (Nexi, card, prop), spread them across thirds.
  - Never park a card or Nexi in a corner, including in end cards.

## Text
- **Minimum on-screen sizes, after camera zoom:**
  - headings 34 px;
  - key information 22 px;
  - labels 18 px;
  - tiny decorative text only when it doesn't need reading.
  - World size × zoom = screen size. A 20 px label at zoom 0.75 shows at 15 px, which is too small.
- **Fit:** text never overflows its box. Measure with `gg.measureText` and widen the box, wrap, or shrink the font.
- **Overlap:**
  - text never overlaps other text or Nexi;
  - a front-layer prop with text must not sit on Nexi's spot;
  - Nexi must not stand in front of text the viewer is reading.
- **Fonts:** Plus Jakarta Sans 800 for display, Inter 600–700 for body, Caveat only for the intro subtitle and deliberately messy samples. Ink is `#1F1F3D`, body text `#4C4C63`, TechNext blue `#3167CA`.

## Cards and props
- **Card style:** white cards with a soft blue shadow and a 3–4 px `rgba(111,160,245,.45)` edge, radius 18–34.
- **Size:** content in a card is generous. If a card has more than five lines of text, split it or zoom in.
- **Samples:** sample formats (business cards, slides, phones, posts) must look like real, attractive designs at a readable size. A phone shows full proportions (about 1:2) and fits entirely in the frame. Give it its own phone-scale layout (type 18–27 px on screen), not a squeezed desktop page.
- **Sample-format sizes that worked (Brand round 2):** card 340×200, slide 420×236, post 300×375, roll-up 210×420, signature 440×150. Text 20 px or more in world px, viewed at zoom 0.82 or above. Make an off-brand and an on-brand version of each.
- **Labels:** labels on stacked props (crates, cards) sit inside the prop and are large enough to read.
- **Lines under labels:** draw every connecting line (cables, pipes, routes) before the labels, so no line crosses a label.
- **Props in hand:** a held prop starts at Nexi's hand (`pocket()`), never gliding in from the world origin.
- **Sample data:**
  - Numbers on screen are sample figures and are labelled "sample".
  - Client names are fictional (Bluebay Trading, Lintel & Co., Manila Trading).
  - Never present a sample as TechNext's own facts.

## Nexi
- **Moving:** she roams. Every beat moves her somewhere meaningful (fly, hop, ride, carry), and she faces the viewer when she speaks (the default gaze).
- **Positions:** her target positions are chosen with props in mind. Check mid-flight frames: a flight path must not cross reading text. Route it above or below.
- **Changing sides:** to get to the other side of a set full of text, she flies up out of frame and drops back in, or rides something (a rail, a plane, an envelope) that keeps her off the labels. `fly()` cuts corners (spring), so leave 250 px of clearance.
- **Celebrations near the top of frame:** use a small cheer (`excited` + sparks). `bigjump` lifts her about 330 px and clips the hat.
- **Costume:** one per video, kept on through the outro.
- **Reactions:** big. Shock, panic and laugh use speed lines, shake and emotes. Use sparks rather than confetti when cards with text are on screen.

## Camera
- **Grammar:** establishing wide, push-in on a detail, whip pan to the next station, track a moving subject, crane up for builds, pull back for reveals, a dutch tilt for comedy.
- **Still for reading:** hold the camera still, or nearly so, while a card is read. Move between beats.
- **Zoom range:** 0.7–1.4 for most shots. Below 0.75 the text gets small, so scale world text up for overview shots.

## Viewer quiz
- **One per video:** 3 s countdown, then reveal and cheer.
- **The subject stays visible:** the quiz must not cover what it asks about. Use `layout: 'wide'` (top or bottom band) or put the card on the empty side.
- **Placement:** Nexi stands beside the quiz, never behind it.

## End card
- **Logo:** centred; "with Nexi" at the right slot; the video's badge at the left slot.
- **Nexi's spot:** one of `top`, `left`, `right`, `below`, `leftlow` or `rightlow`, and a different one for each video in a batch. On the marketing end card the link row spans x 426–1500, so the low spots sit just outside it.

## Audio
- **Music:** one style per topic. Beds sit 10–12 dB under the voice, about 5 dB under it in the gaps, measured with `_buslevel.py`.
- **Timbre:** bright FM or bell tones flood the 2–4 kHz voice band. Low-pass them.
- **Levels:** loudness about −17 LUFS; true peak ≤ −2 dBFS (`render.LIMIT` 0.7); voice ratio ≥ 3.5×. A true-peak miss is usually one sharp effect (`snip`, `jet` under blips). Find it with `qa/_peaks.py` and lower that effect rather than the limiter.

## Added from batch 3 (2026-10-04)
- **Hats and plates:** a tall hat is part of Nexi's silhouette. Keep the hat top clear of name plates and signs, including during reactions that lift her.
- **Crossing a labelled set:** leave over the top of the frame and drop back in. Waypoints alone don't stop the spring from cutting through labels.
- **Labels on contrast:** text never sits directly on a coloured prop; put it on a chip or a plate.
- **Screen-layer cards:** a card that must be read while the camera shows a busy world (a log, a counter) goes in the `screen` layer over empty sky.
- **End-card spot by hat:** `below` only with low hats (bow tie, cap, bellhop); tall hats use `left`, `right`, `leftlow` or `rightlow`.

## Added from the round-2 audit (2026-10-04): framing math, fit, transitions
- **Framing math (do this for every scene).** Author resting positions from the screen: `worldX = camX + (screenX - 960) / zoom`, `worldY = camY + (screenY - 540) / zoom`.
  - Nexi's silhouette around `N.botPx()`, in world px at depth scale 1: x -160..+160 (up to ±200 with arms), y -230 (−310 with a tall hat or a reaction lift) .. +210. On screen that is about 290 x 400 px at zoom 0.9.
  - Nexi's resting centre: screen x 300-1620; screen y 300-600 (360-600 with a tall hat), so her top clears the HUD and her base clears the caption.
  - The group: take the world extents of Nexi's bbox and every card in the scene; set the camera x to the group's centre and the zoom so the group spans at most about 1500 px. Typical: Nexi at screen 340-450, the cards from 600-650 to 1650-1700.
  - Leave 60 px or more between Nexi's bbox and the nearest card.
- **Vertical balance:** the content block sits between the HUD (y about 140) and the caption top (about 835 for two lines). Lower a top-heavy scene.
- **Text fit:** never hard-code a text box's width. Measure (`L.tw(gg, text, size, weight, font)`, or a `chipW()` helper) and add 24 px or more of padding (8 px is the absolute minimum; under 3 px reads as touching the border).
- **Inline tags:** a chip next to a title goes at `titleX + titleWidth + 24 + chipWidth / 2`.
- **Covering:** a card in front of a prop covers the whole prop (or its whole label) or stays clear. Never half a label.
- **Labels:** a label sits centred on the thing it names and must be true for it. Platform pills, captions and stands all end above the caption band.
- **Inside containers:** centre the content block (a diagram in a scroll, a list in a card); when more content arrives (a device list), animate the shift.
- **Connectors with labels:** give each label its own segment (bus routing), never several labels at one fan-out point.
- **Empty states:** empty fields are drawn as empty inputs (dashed border, light "Empty" placeholder), never as blank rows.
- **Riding:** to ride a vehicle, Nexi's lowest point sits on its roof line (`botY = roofY - 210 * scale`) and the vehicle never draws over her. If the ride passes signs, she flies above the scene and waves instead.
- **Stands and posts** end on a base above the caption band.
- **Props that fly away** (a lid, a rocket) leave the frame entirely; they never park over a card.
- **Transition grammar (every scene change):** at t0 Nexi takes off with `flyOver` (fast ease-out); the camera moves at t0 + 0.4 s (0.55-0.65 s for a long whip from a left-side spot); the old scene fades over 0.4 s from t0 + 0.5; the new scene's frame appears from t0 + 0.45 and is fully up when the camera lands; only details reveal on later words. The CTA pops at about +0.7 s while the camera arrives. A frame showing only Nexi and the backdrop is a defect.
- **Leaving a spot next to a sign:** step clear first (`flyOver(..., { via: [[x, y]] })`), then go up; straight up from a left-side spot runs through the HUD corner.
- **Hovering:** a free band of sky above a row of cards is a good home for Nexi (she supervises from above), as long as her base stays 10 px or more above the cards.

## Added from the round-2 follow-ups (2026-10-04)
- A cut-out (bite, notch, hole) made of overlapping circles is ONE closed outline: the union of the circles, traced through their intersection points. Never stack separate overlapping arcs in an evenodd clip: overlaps flip back in. Any separate subpath needs its own `moveTo`, or a joining line cuts a wedge.
- `introSeq({ nx, ny })` is Nexi's first move after the lock-up, in the first scene's world coordinates. Pick a spot whose climb crosses no label in the scene that fades in.
- Floating decorations (bubbles, hearts, stats) fade out within Nexi's silhouette box (`N.botPx()` ±215 px x, -340/+240 px y). They never float over her.
- Props tossed across a board fly a low arc (h ≈ 80) and are small in flight (s ≈ 0.6). A high arc loops over the board's title.
- A label on a textured surface (weave, wood grain, stripes) sits on its own plate.
- If Nexi must pass a front-layer card, she climbs clear first (`flyOver` with `via`), and a card that pops does so after she is clear.

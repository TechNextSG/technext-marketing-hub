---
name: nexi-video
description: Make, fix, redesign or audit TechNext explainer videos starring Nexi, the 3D robot mascot, with the in-house renderer at ~/ClaudeWork/nexi-tutorial. Covers Odoo walkthroughs, topic videos (myth-busting, quick tip, module explainer, before/after), solution videos (one per technext.asia service, built on an analogy or role-play), and any new Nexi video. Output is a 16:9 MP4 with Nexi's robot voice, typed captions, music and sound effects, delivered to the shared drive. Use whenever the user asks for a Nexi video, a video about an Odoo app or a TechNext service, or a fix or audit of an existing Nexi video.
---

# Nexi videos

TechNext makes cinematic explainer videos starring Nexi, the 3D robot from technext.asia. Every frame is rendered in headless Chrome by the in-house engine at `~/ClaudeWork/nexi-tutorial`. Nothing is hand-animated or screen-recorded. A video is a JavaScript "film" script: timed captions in Nexi's robot voice, plus props, camera moves and Nexi's acting.

## Before anything else

1. **Read the history.** Read `reference/lessons.md` in this skill. Every past mistake and fix is logged there; do not repeat them.
2. **Read the guides.**
   - `reference/design-rules.md` covers how a frame must look.
   - `reference/engine.md` is the API.
   - `reference/workflow.md` has the exact commands.
3. **Check what exists.**
   - The memory file `project_nexi_odoo_walkthrough.md` lists what has been delivered.
   - `~/ClaudeWork/nexi-tutorial/web/films/` holds every existing film. Copy the closest one rather than starting blank. `reference/film-template.js` is the skeleton.
4. **Get the facts right.**
   - Take content from the live website repo (`~/ClaudeWork/TechNext-Website`, branch `origin/master`). Each solution page states what TechNext really offers.
   - Never invent claims, prices, client names or office locations.
   - TechNext is Singapore HQ, with teams in the Philippines and Vietnam, and delivered in 10+ countries. There is no Malaysia office.
   - Sample companies must be clearly fictional and labelled "sample".

## The pipeline (one video)

1. **Concept.** One analogy or role-play world per video, unique across the series. Nexi wears a costume that fits (`wear()`). Plan:
   - 8–13 caption lines, about 50–75 s in total;
   - one viewer quiz with a countdown;
   - at least three hands-on moments (grab, toss, stamp, pull, paint, ride…);
   - one random charming element (a bird, a cow, a bee, a cursor with eyes);
   - a unique call-to-action object;
   - an intro badge, an outro badge and an outro spot (`outroSeq({ nexi })`) not used by the previous video. Pick the spot for the hat: tall hats (chef toque, knight plume) clip at `top` and poke into the CTA row at `below`; `below` suits low hats only.
2. **Script.** Write `web/films/<name>.js`. Every caption is `say()`, and every beat hangs off a caption: `at(line.w('word'), …)`. Keep lines speakable and truthful. Do not start a line with "..." (the voice pauses on dots).
3. **Build and probe.** `python build_film.py <name>`, then `render.py probe`. Fix any load error before going further.
   - `build_film.py` refuses to build a film that redeclares an engine top-level name (a film's `var` re-assigns the engine's variable; `var FLY` once froze every flight). Rename and rebuild.
   - The probe prints the caption timeline (lines start with spaces, so don't filter them out with `grep -v '^ '`).
4. **Contact sheet.** Render a sheet at every beat and at every transition (mid-flight, mid-camera-move frames too). Audit each frame against `reference/qa-checklist.md`. Fix, re-sheet the changed beats, and repeat until clean.
5. **Render.** `render.py mp4`. You can run several films at once with different ports.
6. **Audio QA.** Run `qa_av.py` and `qa/_buslevel.py`. Targets:
   - about −17 LUFS;
   - true peak ≤ −2 dBFS;
   - voice ratio ≥ 3.5×;
   - music 10–12 dB under the voice and about 5 dB under it in the gaps.
   Fix by re-muxing the audio only.
7. **Final frame check.** `deliver.py sheet <name>` pulls 12 frames from the encoded MP4. Look at them.
8. **Deliver.** Copy the MP4 to the shared drive (md5-checked) and send it to the user straight away.
   - Run `deliver.py copy <name>`; it copies to the shared drive and verifies the md5.
   - Then send the file to the user (SendUserFile, status proactive) the moment it is ready. Do not batch.
   - Captions say what the video shows and how long it runs.
9. **Report.** Give a status table across the batch: video, length, state.
10. **Keep this skill alive.** Log the lessons, promote new rules and republish the hub skills page (see below). This is not optional.

## Non-negotiables (from user feedback)

- **Nothing in a corner.** Nexi, cards and props sit in balanced compositions. Nexi never sits behind a card, a quiz or the caption, and never hugs a frame edge. In the end card she uses one of the outro spots, a different one per video.
- **Text must be readable.**
  - On screen, important text is at least 22 px and labels at least 18 px, measured after camera zoom: world size × `CAM.zoom`.
  - Never let text overlap other text, Nexi, or another prop's text.
  - Fit labels inside their boxes, or wrap them.
- **Lively but clean.**
  - Nexi roams the whole set: `fly`, `hop`, ride things, carry things.
  - Reactions are exaggerated (`RX.*`, `E.*`).
  - The camera moves (push-ins, whip pans, tracking, crane, dutch tilt) and is still while text is being read.
- **Logos and branding.**
  - The intro and end-card logo is centred.
  - "with Nexi" sits as in the walkthrough.
  - Use the plain Odoo logo, never "Odoo Ready Partner".
  - Marketing videos use the marketing end card: Websites · Social · Brand, no Odoo logo.
- **Music:** upbeat, one style per topic, never loud.
- **Format:** 16:9 only for now. The user postponed 9:16.
- **Tell the user as each video finishes.** Finish each video's QA and delivery the moment its render completes.

## Keep this skill alive

After every video job, whether new videos, fixes or audits:

1. **Log what you learned.** Append dated entries to `reference/lessons.md`: what went wrong, why, and the fix or rule. Include user feedback verbatim when it set a rule.
2. **Promote rules.** If a lesson is a new rule, add it to `reference/design-rules.md` or to the non-negotiables above.
3. **Document new APIs.** If you added engine features (a new helper, quiz layout or outro spot), document them in `reference/engine.md`.
4. **Republish the hub page.** Run `python ~/ClaudeWork/technext-marketing-hub/tools/build_skills.py`, then commit and push only `skills.html`, `assets/skills/` and `tools/build_skills.py`. The hub clone is shared with other chats, so use explicit `git add`, never `-A`. Check that https://technextsg.github.io/technext-marketing-hub/skills.html returns 200.
5. **Update memory.** Update `project_nexi_odoo_walkthrough.md` with what was delivered.
